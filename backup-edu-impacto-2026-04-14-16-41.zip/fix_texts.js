const fs = require('fs');
let txt = fs.readFileSync('app/(app)/academico/responsaveis/page.tsx', 'utf8');

txt = txt.split('(alunos || []).length === 0').join('responsaveis.length === 0');
txt = txt.split('Nenhum aluno cadastrado').join('Nenhum respons�vel cadastrado');
txt = txt.split('Os respons�veis s�o derivados dos dados dos alunos.').join('Cadastre um respons�vel ou verifique a conex�o.');
txt = txt.split('Cadastrar Alunos').join('Recarregar');
txt = txt.split('href="/academico/alunos"').join('href="/academico/responsaveis"');
txt = txt.split(" � {mounted ? (alunos || []).length : '�'} aluno(s) vinculado(s)").join("");
txt = txt.split("e {(alunos || []).length} aluno{(alunos || []).length !== 1 ? 's' : ''} cadastrado{(alunos || []).length !== 1 ? 's' : ''}").join("no sistema");

fs.writeFileSync('app/(app)/academico/responsaveis/page.tsx', txt, 'utf8');
console.log('Done');
