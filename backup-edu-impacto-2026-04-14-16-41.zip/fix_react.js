const fs = require('fs');
let lines = fs.readFileSync('app/(app)/academico/responsaveis/page.tsx', 'utf8').split('\n');

const memoStart = lines.findIndex(l => l.includes('// -- Agrupar alunos por respons�vel'));
const memoEnd = lines.findIndex((l, i) => i > memoStart && l.includes('}, [alunos])'));

const apiStr =   const { data: apiResponse, isLoading } = useApiQuery<{data: any[]}>(
    ['responsaveis-global-list'],
    '/api/responsaveis?limit=1000',
    { staleTime: 300000 }
  );

  const responsaveis = useMemo<Responsavel[]>(() => {
    return (apiResponse?.data || []).sort((a, b) => (a.nome || '').localeCompare(b.nome || ''));
  }, [apiResponse]);;

if (memoStart !== -1 && memoEnd !== -1) {
    const apiIndex = lines.findIndex(l => l.includes('const { data: apiResponse } = useApiQuery'));
    if (apiIndex !== -1) {
       lines.splice(apiIndex, 2); // remove old useApiQuery and const alunos =
    }
    
    // find memoStart again because indices shifted
    const nMemoStart = lines.findIndex(l => l.includes('// -- Agrupar alunos'));
    const nMemoEnd = lines.findIndex((l, i) => i > nMemoStart && l.includes('}, [alunos])'));
    
    if (nMemoStart !== -1 && nMemoEnd !== -1) {
       lines.splice(nMemoStart, nMemoEnd - nMemoStart + 1, ...apiStr.split('\n'));
    }
}

// ensure we replace properly texts that still mention alunos
fs.writeFileSync('app/(app)/academico/responsaveis/page.tsx', lines.join('\n'));
console.log('Fixed');
