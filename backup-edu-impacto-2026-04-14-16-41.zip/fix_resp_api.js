const fs = require('fs');
let text = fs.readFileSync('app/api/responsaveis/route.ts', 'utf8');

const oldQ = \"let query = supabase.from('responsaveis').select('*', { count: 'exact' }).order('nome')\";
const newQ = \"let query = supabase.from('responsaveis').select('*, aluno_responsavel(alunos(id, nome, turma, serie, frequencia, inadimplente, risco_evasao))', { count: 'exact' }).order('nome')\";
text = text.replace(oldQ, newQ);

const oldReturn = \"return NextResponse.json({\\n      data: data || [],\\n      meta: { total: count || 0, page, limit }\\n    })\";
const newReturn = \const mappedData = (data || []).map(r => {
      const filhos = (r.aluno_responsavel || []).map((ar) => ar.alunos).filter(Boolean);
      const totalFilhos = filhos.length;
      let inadimplente = false;
      filhos.forEach(f => { if (f.inadimplente) inadimplente = true; });
      return { ...r, filhos, totalFilhos, inadimplente, aluno_responsavel: undefined };
    });

    return NextResponse.json({
      data: mappedData,
      meta: { total: count || 0, page, limit }
    })\;
text = text.replace(oldReturn, newReturn);
fs.writeFileSync('app/api/responsaveis/route.ts', text);
console.log('API fixed');
