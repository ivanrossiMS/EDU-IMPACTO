// Verificação completa do fator de vencimento FEBRABAN
// Data base: 07/10/1997

const BASE = new Date('1997-10-07T12:00:00.000Z')

function diasDesdeBase(dataISO) {
  const d = new Date(dataISO + 'T12:00:00.000Z')
  return Math.round((d.getTime() - BASE.getTime()) / 86400000)
}

function fatorParaData(f) {
  // Para f <= 9999, direto. Para f > 9999, fator cicla em 10000 - 1000 = 9000 dias
  // Mas na prática: fator = dias + 1000; quando > 9999, subtrai 9000 (ciclo de 9000)
  // PORÉM: o Itaú na prática usa o fator real (sem ciclo), pois o fator 9999 expirou em 21/02/2025
  // Após 21/02/2025, os boletos usam fator com "reinício" = dias - (9999-1000) + 1000
  const dias = parseInt(f) - 1000
  const d = new Date(BASE.getTime() + dias * 86400000)
  return d.toISOString().slice(0,10)
}

// Data de teste: 08/04/2026
const d = diasDesdeBase('2026-04-08')
console.log('Dias desde 1997-10-07 até 2026-04-08:', d)
console.log('Fator bruto (dias+1000):', d + 1000)

// A FEBRABAN especifica: após 9999, subtrai 9000 (não 10000)
// Fator máximo: 9999 = 21/02/2025
// Fator 9999 em dias: 9999 - 1000 = 8999 dias desde 07/10/1997
// Data do fator 9999:
const dataFator9999 = fatorParaData('9999')
console.log('Data do fator 9999:', dataFator9999)

// Após o fator 9999, o ciclo recomeça:
// Segundo o manual Itaú, após 9999 voltamos para 1000
// Mas a diferença real é: 2026-04-08 - 1997-10-07 = 10410 dias
// Fator = 10410 + 1000 = 11410
// Após -9000 = 2410 (o que o nosso código faz)
// O banco registrou: 1410

// Verificação: se fator é 1410, quando acaba de ciclar para 1000:
// 1410 - 1000 = 410 dias desde o início do NOVO ciclo
// Início do novo ciclo = dia após fator 9999 = 22/02/2025
const dataInicioCiclo = new Date('2025-02-22T12:00:00.000Z')
const dataVerificada = new Date(dataInicioCiclo.getTime() + 410 * 86400000)
console.log('\nSe fator 1410 = 1000 + 410 dias após 22/02/2025:')
console.log('Data resultante:', dataVerificada.toISOString().slice(0,10))

// Então o CICLO do Itaú recomeça em 1000 após o fator 9999
// O reset correto é: f_novo = f_bruto - 9000 QUANDO f_bruto > 9999? 
// 11410 - 9000 = 2410 ← nosso código
// OU:
// f_novo = f_bruto - (9999 - 999) = f_bruto - 9000 ... mas isso dá 2410 não 1410
// 
// TALVEZ o Itaú use: f_novo = (f_bruto - 1000) % 9000 + 1000
// (11410-1000) % 9000 + 1000 = 10410 % 9000 + 1000 = 1410 + 1000 = 2410 ainda não bate
//
// OU: o reinício começa em 1000, não em 2000
// Fator 9999 = dia 8999 (desde base)
// Dia 9000 = fator 1000 (início do ciclo)
// Dia 10410 = 10410 - 9000 + 1000 - 1000 = 1410? 

// TENTATIVA: os 9 primeiros ciclos de 1000 dias cada = 9000 dias
// Depois: dia X no segundo ciclo (onde X = dias - 9000)
// fator novo = X + 1000
// Para dia 10410: X = 10410 - 9000 = 1410, fator = 1410 + 0 = 1410 ← SIM!
// Ou seja: fator = dias (sem somar 1000) quando no segundo ciclo??

// Na verdade: a fórmula que dá 1410 é:
// dias_no_ciclo = (total_dias - 8999_dias_do_primeiro_ciclo)
// = 10410 - 8999 = 1411... 

// Vamos tentar outra abordagem:
// O fator correto confirmado pelo banco é 1410 para 08/04/2026
// dias desde base = 10410
// 10410 - 1000 = 9410... nao
// 10410 % 9000 = 1410 ← ISSO! Módulo 9000 sem o +1000 !

console.log('\nCálculo correto: dias % 9000 =', d % 9000, '← FATOR DO BANCO?')
console.log('Tentativa: (dias % 9000) + 1000 =', (d % 9000) + 1000)
console.log('Tentativa: ((dias - 1) % 9000) + 1 =', ((d-1)%9000)+1)

// Verificação: se fator = 1410, então:
// 1410 - 1000 = 410 dias desde o reinício
// E o dia no novo ciclo: o ciclo começa quando dias=9000
// 9000 + 410 = 9410 dias, não 10410

// CONCLUSÃO: vou checar o que o banco usa exatamente
// Imagem 1 criou o boleto: 01/04/2026, venc 08/04/2026

// Fator do SISTEMA: 2410 → data: 
const dataFator2410 = fatorParaData('2410')
console.log('\nFator 2410 → data:', dataFator2410, '(o que o SISTEMA gera, errado)')
// Fator do BANCO: 1410 → data:
const dataFator1410 = fatorParaData('1410')
console.log('Fator 1410 → data:', dataFator1410, '(o que o BANCO registrou)')

// O banco tem 08/04/2026 como vencimento (confirmado na imagem 2)
// Então fator 1410 → 08/04/2026 usando a fórmula do banco

// NOVA TEORIA: O banco usa reinício em 1000 após 9999 dias
// Ou seja, a fórmula é: fator = (dias_desde_base - 1) % 9000 + 1
// Para d = 10410:
console.log('\nNOVA FÓRMULA: (d-1)%9000 + 1 =', (d-1) % 9000 + 1)
// Ou: fator = ((d + offset) % 9000) + 1000
// where offset makes it cycle from 9000 days

// O mais simples que dá 1410:
// 1410 = 10410 - 9000
console.log('10410 - 9000 =', d - 9000)

// CONFIRMADO: fator = dias_desde_base - 9000 quando dias > 9000
// Isso é equivalente a: subtrai 9000, NÃO adiciona 1000
// Nossa fórmula errada: fator = dias + 1000, depois subtrai 9000
// = dias + 1000 - 9000 = dias - 8000
// 10410 - 8000 = 2410 ← nosso erro!

// Fórmula correta:
// fase 1 (dias 0..8999): fator = dias + 1000 (1000 a 9999)
// fase 2 (dias 9000+): fator = dias - 9000 + 1000 = dias - 8000... ainda 2410

// ESPERA: vamos inverter a direção
// Se dias=10410 no banco resulta em fator=1410:
// 1410 = 10410 - X → X = 9000
// Mas na fase 1: fator = dias + 1000
// dias=0 → fator=1000; dias=8999 → fator=9999
// Na fase 2: fator = dias - 9000 
// dias=9000 → fator=0 (inválido!) 
// dias=9001 → fator=1
// dias=10410 → fator=1410 ← BANCO ESTÁ USANDO ISSO!

console.log('\n🎯 RESULTADO FINAL:')
console.log('O banco usa fórmula: fator = dias_desde_base - 9000 (quando dias > 9000)')
console.log(`Para 08/04/2026: fator = ${d} - 9000 = ${d - 9000}`)
console.log('O banco confirmou fator = 1410 ✓')
console.log('\nO código atual faz: fator = dias + 1000 - 9000 = dias - 8000 (ERRADO)')
console.log('Correção: quando dias > 8999: fator = dias - 9000 (NÃO + 1000)')
