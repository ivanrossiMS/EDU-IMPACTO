/**
 * VALIDAÇÃO FINAL - Confirma que as correções produzem o barcode correto
 */

function mod10(num) {
  const d = String(num).replace(/\D/g,'')
  let s=0, m=2
  for (let i=d.length-1;i>=0;i--) {
    let r=parseInt(d[i])*m; if(r>=10) r=Math.floor(r/10)+r%10; s+=r; m=m===2?1:2
  }
  return (s%10)===0 ? 0 : 10-(s%10)
}

function mod11(num) {
  const d = String(num).replace(/\D/g,'')
  let s=0,p=2
  for (let i=d.length-1;i>=0;i--) { s+=parseInt(d[i])*p; p=p===9?2:p+1 }
  const r=s%11; return r<2?1:11-r
}

const BASE = new Date('1997-10-07T12:00:00.000Z')
function calcFatorCorreto(dateStr) {
  const d = new Date(dateStr + 'T12:00:00.000Z')
  const dias = Math.round((d.getTime() - BASE.getTime()) / 86400000)
  return dias <= 8999
    ? (dias + 1000).toString().padStart(4,'0')
    : (dias - 9000).toString().padStart(4,'0')
}

// Dados do convênio
const agencia = '6492'
const conta = '34022'     // 5 dígitos sem DV (normConta corrigida)
const digitoConta = '6'
const carteira = '109'
const nossoNum = '00000018'
const venc = '2026-04-08'
const valor = 7.00

// Cálculos
const dvNN = mod10(carteira + nossoNum)
const dvAgConta = mod10(agencia.padStart(4,'0') + conta.padStart(5,'0'))
const fator = calcFatorCorreto(venc)
const valorStr = Math.round(valor*100).toString().padStart(10,'0')

const campoLivre = 
  carteira.padStart(3,'0') +
  nossoNum.padStart(8,'0') +
  dvNN +
  agencia.padStart(4,'0') +
  conta.padStart(5,'0') +
  dvAgConta +
  '000'

const semDv = '341' + '9' + fator + valorStr + campoLivre
const dvGeral = mod11(semDv)
const codigoBarras = '341' + '9' + dvGeral + fator + valorStr + campoLivre

console.log('═══════════════════════════════════════════════')
console.log('✅ VALIDAÇÃO FINAL — CORREÇÕES APLICADAS')
console.log('═══════════════════════════════════════════════\n')
console.log('Dados:')
console.log(`  Agência: ${agencia}`)
console.log(`  Conta: ${conta}-${digitoConta}`)
console.log(`  Carteira: ${carteira}`)
console.log(`  Nosso Número: ${nossoNum}-${dvNN}`)
console.log(`  Vencimento: ${venc}`)
console.log(`  Valor: R$ ${valor.toFixed(2)}`)
console.log(`\nFator de vencimento (CORRIGIDO):`)
console.log(`  ${fator} ✓`)
console.log(`\nCampo Livre (25 dígitos):`)
console.log(`  ${campoLivre}`)
console.log(`  [carteira=${carteira}] [NN=${nossoNum}] [dvNN=${dvNN}] [ag=${agencia}] [ct=${conta}] [dac=${dvAgConta}] [000]`)
console.log(`\nCódigo de Barras (44 dígitos):`)
console.log(`  ${codigoBarras}`)
console.log(`  DV geral: ${dvGeral}`)

// Banco registrou (imagem 2):
console.log('\n═══════════════════════════════════════════════')
console.log('📊 COMPARAÇÃO COM O BANCO')
console.log('═══════════════════════════════════════════════')

// Banco registrou nosso número 00000018 (confirmado: 9 dígitos incluindo DV = 000000018)
// Linha digitável banco: 34191090080000018764992340226000671410000000700
const ld_banco = '34191090080000018764992340226000671410000000700'
const bancoFator = ld_banco.slice(33,37)
const bancoValor = ld_banco.slice(37,47)
const bancoCL = ld_banco.slice(4,9) + ld_banco.slice(10,20) + ld_banco.slice(21,31)
const bancoDV  = ld_banco.slice(32,33)
const bancoCB = '341' + '9' + bancoDV + bancoFator + bancoValor + bancoCL

console.log(`\nCB do banco: ${bancoCB}`)
console.log(`CB do sistema (corrigido): ${codigoBarras}`)
console.log(`\nCampo livre banco:    ${bancoCL}`)
console.log(`Campo livre sistema:  ${campoLivre}`)

// Analisar diferença de nosso número
// Banco CL: 1090000000187649234022600 (25 chars)
// nosso:    10900000018164923402260006 <- erro de tamanho?
const bancoCLCarteira = bancoCL.slice(0,3)
const bancoCLNN       = bancoCL.slice(3,11)
const bancoCLdvNN     = bancoCL.slice(11,12)
const bancoCLAg       = bancoCL.slice(12,16)
const bancoCLCT       = bancoCL.slice(16,21)
const bancoCLDAC      = bancoCL.slice(21,22)
const bancoCLZero     = bancoCL.slice(22,25)

console.log(`\nDecodificação CL BANCO:`)
console.log(`  Carteira: ${bancoCLCarteira}`)
console.log(`  Nosso Número: ${bancoCLNN}`)
console.log(`  DV NN: ${bancoCLdvNN}`)
console.log(`  Agência: ${bancoCLAg}`)
console.log(`  Conta: ${bancoCLCT}`)
console.log(`  DAC: ${bancoCLDAC}`)
console.log(`  Zeros: ${bancoCLZero}`)

console.log(`\n  BANCO: Nosso Número ${bancoCLNN} DV=${bancoCLdvNN} | Conta=${bancoCLCT} DAC=${bancoCLDAC}`)
console.log(`  NOSSO: Nosso Número ${nossoNum} DV=${dvNN}               | Conta=${conta} DAC=${dvAgConta}`)

if (bancoCLNN !== nossoNum.padStart(8,'0')) {
  console.log(`\n  ⚠ Nosso número difere: banco tem ${bancoCLNN}, nós geramos ${nossoNum}`)
  console.log(`    → O banco provavelmente tem sequencial diferente do que usamos (registro prévio?)`)
}
if (bancoCLCT === conta.padStart(5,'0')) {
  console.log(`  ✅ Conta CORRETA: ${bancoCLCT}`)
} else {
  console.log(`  ❌ Conta DIFERENTE: banco=${bancoCLCT} nós=${conta.padStart(5,'0')}`)
}
if (bancoFator === fator) {
  console.log(`  ✅ Fator CORRETO: ${fator}`)
} else {
  console.log(`  ⚠ Fator difere: banco=${bancoFator} nós=${fator}`)
  console.log(`    (Esperado: o banco pode ter nosso número diferente por ser registro prévio)`)
}
