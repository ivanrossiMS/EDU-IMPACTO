const fs = require('fs');
const path = require('path');

const walkSync = (dir, filelist = []) => {
  fs.readdirSync(dir).forEach(file => {
    const dirFile = path.join(dir, file);
    if (fs.statSync(dirFile).isDirectory()) {
      filelist = walkSync(dirFile, filelist);
    } else {
      if (file.endsWith('.tsx') || file.endsWith('.ts')) {
        filelist.push(dirFile);
      }
    }
  });
  return filelist;
};

const files = walkSync('./app');
let modifiedFiles = 0;

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  const initialContent = content;
  
  // Renders inside jsx like <div>{a.data}</div> 
  const regex = />\s*\{((?:[a-zA-Z0-9_]+\.)?(?:dataNascimento|vencimento|dataMatricula))\}\s*</g;
  
  if (regex.test(content) && !file.includes('perfil/page.tsx')) {
    content = content.replace(regex, '>{$1 ? formatDate($1) : \'—\'}<');
    
    // add import if not there
    if (!content.includes('formatDate')) {
       if (content.includes('getInitials')) {
          content = content.replace('getInitials', 'getInitials, formatDate');
       } else {
          content = "import { formatDate } from '@/lib/utils'\n" + content;
       }
    }
  }

  if (content !== initialContent) {
    fs.writeFileSync(file, content, 'utf8');
    modifiedFiles++;
    console.log('Modified', file);
  }
});
console.log('Total modified:', modifiedFiles);
