const fs = require('fs');
const path = require('path');

const walkSync = (dir, filelist = []) => {
  fs.readdirSync(dir).forEach(file => {
    const dirFile = path.join(dir, file);
    if (fs.statSync(dirFile).isDirectory()) {
      filelist = walkSync(dirFile, filelist);
    } else {
      if (file.endsWith('.tsx') || file.endsWith('.ts')) {
        filelist.push(dirFile);
      }
    }
  });
  return filelist;
};

const files = walkSync('./app');
let modifiedFiles = 0;

const replacements = [
  '{aluno.dataNascimento}',
  '{p.vencimento}',
  '{t.vencimento}',
  '{titulo.vencimento}',
];

files.forEach(file => {
  if (file.includes('perfil/page.tsx') || file.includes('ficha/page.tsx')) return;

  let content = fs.readFileSync(file, 'utf8');
  const initialContent = content;
  
  let needsImport = false;
  replacements.forEach(t => {
     // match only if not preceded by `value=` or `defaultValue=`
     const r = new RegExp(`(?<!value=)(?<!defaultValue=)(${t.replace(/\\}/g,'\\}').replace(/\\{/g,'\\{')})`, 'g');
     if (content.includes(t)) {
        const inner = t.replace('{', '').replace('}', '');
        content = content.replace(r, `\{${inner} ? formatDate(${inner}) : '—'\}`);
        needsImport = true;
     }
  });
  
  if (needsImport && !content.includes('formatDate')) {
     if (content.match(/import\s+\{.*\}\s+from\s+['"]@\/lib\/utils['"]/)) {
        content = content.replace(/import\s+\{(.*?)\}\s+from\s+['"]@\/lib\/utils['"]/, 'import {$1, formatDate} from \'@/lib/utils\'');
     } else {
        content = "import { formatDate } from '@/lib/utils'\n" + content;
     }
  }

  if (content !== initialContent) {
    fs.writeFileSync(file, content, 'utf8');
    modifiedFiles++;
    console.log('Modified', file);
  }
});
console.log('Total modified:', modifiedFiles);
