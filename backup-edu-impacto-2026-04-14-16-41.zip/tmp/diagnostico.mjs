/**
 * DIAGNÓSTICO PRECISO — Bugs no campo livre e fator de vencimento
 */

// ── Constantes
const BASE_DATE = new Date('1997-10-07T12:00:00.000Z')

// ── Mod10
function mod10(num) {
  const d = String(num).replace(/\D/g,'')
  let s = 0, m = 2
  for (let i = d.length-1; i>=0; i--) {
    let r = parseInt(d[i]) * m
    if (r>=10) r = Math.floor(r/10) + r%10
    s += r; m = m===2?1:2
  }
  const r = s%10; return r===0?0:10-r
}

// ── Mod11 barras
function mod11(num) {
  const d = String(num).replace(/\D/g,'')
  let s=0, p=2
  for (let i=d.length-1;i>=0;i--) {
    s += parseInt(d[i])*p
    p = p===9?2:p+1
  }
  const r = s%11; return r<2?1:11-r
}

// ── Fator
function calcFator(dateStr) {
  const venc = new Date(dateStr + 'T12:00:00.000Z')
  const diffMs = venc.getTime() - BASE_DATE.getTime()
  const diffDias = Math.round(diffMs / (1000*60*60*24))
  let f = diffDias + 1000
  if (f > 9999) f = f - 9000
  return f.toString().padStart(4,'0')
}

function fatorParaData(fator) {
  const f = parseInt(fator)
  const dias = f - 1000
  const d = new Date(BASE_DATE.getTime() + dias*86400000)
  return d.toISOString().slice(0,10)
}

// ── Dados reais do boleto
const agencia   = '6492'      // 4 dígitos, sem DV
const digitoAg  = '0'
const conta     = '340226'    // como salvo no convênio (com DV = 6)
const digitoCt  = '6'
const carteira  = '109'
const nossoNum  = '00000018'  // 8 dígitos, sequencial 18
const venc      = '2026-04-08'
const valor     = 7.00

// ── normConta como na API (5 dígitos) — o que o sistema faz
function normConta5(cc) { return cc.replace(/\D/g,'').padStart(5,'0').slice(-5) }
// ── conta sem DV (5 dígitos, removendo o último que é DV)
// A conta "340226" → os 5 primeiros sem DV = "34022", DV = "6"
// MAS o Itaú usa 5 dígitos de conta NO CAMPO LIVRE, sem DV
// Portanto: contaSemDV = conta.slice(0,-1) se tem 6, ou a conta toda se tem 5

console.log('\n═══════════════════════════════════════════════════')
console.log('🔍 DIAGNÓSTICO BOLETO — CAUSA RAIZ')
console.log('═══════════════════════════════════════════════════\n')

// ── 1. Fator de vencimento
const fator = calcFator(venc)
console.log(`1. FATOR DE VENCIMENTO:`)
console.log(`   Data vencimento: ${venc}`)
console.log(`   Fator gerado: ${fator}`)
console.log(`   Verificação inversa: ${fatorParaData(fator)}`)
console.log(`   ⚠ ESPERADO pelo banco: 2410 mas banco registrou: 1410`)
console.log(`   ├─ Fator 2410 → data: ${fatorParaData('2410')}`)
console.log(`   └─ Fator 1410 → data: ${fatorParaData('1410')}`)

// Importante: onde está o 2410?
// 08/04/2026 = ?
const d1 = new Date('2026-04-08T12:00:00.000Z')
const diff = Math.round((d1.getTime() - BASE_DATE.getTime()) / 86400000)
console.log(`\n   Dias desde base (1997-10-07) até 2026-04-08: ${diff}`)
console.log(`   Fator bruto: ${diff + 1000}`)
console.log(`   Após reset (−9000): ${diff + 1000 - 9000}`)
console.log(`   Banco registrou fator: 1410 → data: ${fatorParaData('1410')} ← ESTÁ CORRETO!`)
console.log(`   PROBLEMA: O sistema NÃO faz o reset de −9000, gerando fator=${diff+1000}`)

// ── 2. Conta
console.log(`\n2. QUESTÃO DA CONTA NO CAMPO LIVRE:`)
console.log(`   conta no convênio: "${conta}" (${conta.length} dígitos)`)
const c5 = normConta5(conta)
console.log(`   normConta5(conta): "${c5}" → PEGA OS 5 ÚLTIMOS DÍGITOS`)
console.log(`   Mas conta="${conta}" → últimos 5 = "${conta.slice(-5)}"`)
console.log(`   Conta SEM DV = "${conta.slice(0,-1)}" (retiramos o DV "${conta.slice(-1)}")`)
console.log(`\n   ⚠ CAMPO LIVRE espera: conta sem DV (5 dígitos) = "${conta.slice(0,-1)}"`)
console.log(`   ⚠ Sistema está usando: normConta5("${conta}") = "${c5}" (INCORRETO — inclui o DV como parte da conta!)`)

// ── 3. DAC Agência+Conta
const dac_certo = mod10(agencia.padStart(4,'0') + conta.slice(0,-1).padStart(5,'0'))
const dac_errado = mod10(agencia.padStart(4,'0') + c5)
console.log(`\n3. DAC AGÊNCIA+CONTA:`)
console.log(`   DV do convenio.conta: "${digitoCt}"`)
console.log(`   Conta sem DV (34022): DAC = mod10("6492"+"34022") = ${dac_certo}`)
console.log(`   Conta errada (40226): DAC = mod10("6492"+"40226") = ${dac_errado}`)
console.log(`   O campo livre tem DAC=${dac_errado} → errado! Deveria ser ${dac_certo}`)

// ── 4. Reconstrução do campo livre correto
const nn_dv = mod10(carteira + nossoNum)
console.log(`\n4. DV NOSSO NÚMERO: mod10("${carteira}"+"${nossoNum}") = ${nn_dv}`)

const cl_sistema = carteira + nossoNum + nn_dv + agencia.padStart(4,'0') + c5 + dac_errado + '000'
const cl_correto = carteira + nossoNum + nn_dv + agencia.padStart(4,'0') + conta.slice(0,-1).padStart(5,'0') + dac_certo + '000'
console.log(`\n5. CAMPO LIVRE COMPARAÇÃO (25 dígitos):`)
console.log(`   Sistema:  "${cl_sistema}"`)
console.log(`   Correto:  "${cl_correto}"`)

// ── 5. Código de barras correto com fator certo e conta certa
const fatorCorreto = (diff + 1000 - 9000).toString().padStart(4,'0')
const valorStr = Math.round(valor*100).toString().padStart(10,'0')
const cb_sem_dv = '341' + '9' + fatorCorreto + valorStr + cl_correto
const dv_geral = mod11(cb_sem_dv)
const cb_correto = '341' + '9' + dv_geral + fatorCorreto + valorStr + cl_correto
console.log(`\n6. CÓDIGO DE BARRAS CORRETO (44d):`)
console.log(`   ${cb_correto}`)
console.log(`   DV geral: ${dv_geral}`)
console.log(`   Fator: ${fatorCorreto} → venc: ${fatorParaData(fatorCorreto)}`)

// Banco registrou (da imagem 2):
const ld_banco = '34191090080000018764992340226000671410000000700'
const cl_banco = ld_banco.slice(4,9) + ld_banco.slice(10,20) + ld_banco.slice(21,31)
const banco_fator = ld_banco.slice(33,37)
const banco_valor = ld_banco.slice(37,47)
const banco_dv = ld_banco.slice(32,33)
const cb_banco = '341' + '9' + banco_dv + banco_fator + banco_valor + cl_banco
console.log(`\n7. BANCO REGISTROU CB (44d):`)
console.log(`   ${cb_banco}`)
console.log(`   DV geral: ${banco_dv}`)
console.log(`   Fator: ${banco_fator} → venc: ${fatorParaData(banco_fator)}`)
console.log(`   Campo livre banco: ${cl_banco}`)
console.log(`\n   Campo livre correto calculado: ${cl_correto}`)
console.log(`   Iguais? ${cl_banco === cl_correto}`)
console.log(`\n8. RESUMO DOS BUGS ENCONTRADOS:`)
console.log(`   BUG 1: normConta5() pega os 5 últimos da conta COM DV.`)
console.log(`          → Conta "340226" vira "40226" (errado) em vez de "34022" (sem DV)`)
console.log(`   BUG 2: fatorVencimento não faz reset quando > 9999.`)
console.log(`          → 2026-04-08 gera fator ${diff+1000} mas deveria ser ${diff+1000-9000}`)
