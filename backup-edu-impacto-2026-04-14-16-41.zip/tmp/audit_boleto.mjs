/**
 * AUDITORIA DO BOLETO — comparação sistema vs. banco
 * 
 * Dados da imagem 1 (boleto gerado pelo sistema):
 *   Linha digitável: 34191.09008 00001.816495 23402.260006 8 24100000000700
 *   Cód. Barras exibido: 34198241000000700010900000181649523402260006
 *   Nosso Número: 00000018-1
 *   Agência/Conta: 6492 / 340226
 *   Carteira: 109
 *   Valor: R$ 7,00
 *   Vencimento: 08/04/2026
 * 
 * Dados da imagem 2 (boleto registrado no banco):
 *   Código boleto: 3419109008000001876499234022600067141000 00000700
 *   Nosso número banco: 649234022109000000018
 */

// ─── Dados do boleto conforme sistema ───────────────────────────────────────
const CB_SISTEMA = '34198241000000700010900000181649523402260006'
// Linha digitável banco (imagem 2): 34191090080000018764992340226000671410000000700
const LD_BANCO =   '34191090080000018764992340226000671410000000700'

// ─── Parse código de barras 44 dígitos ───────────────────────────────────────
function parseCB(cb44) {
  return {
    banco:      cb44.slice(0,3),
    moeda:      cb44[3],
    dvGeral:    cb44[4],
    fator:      cb44.slice(5,9),
    valor:      cb44.slice(9,19),
    campoLivre: cb44.slice(19),
  }
}

// ─── Parse linha digitável 47 dígitos ───────────────────────────────────────
function parseLD(ld47) {
  const c1 = ld47.slice(0,10)   // banco(3)+moeda(1)+cl[0..4]+dv
  const c2 = ld47.slice(10,21)  // cl[5..14]+dv
  const c3 = ld47.slice(21,32)  // cl[15..24]+dv
  const c4 = ld47.slice(32,33)  // dv geral
  const c5 = ld47.slice(33,47)  // fator(4)+valor(10)
  return {
    campo1: c1, campo2: c2, campo3: c3, campo4: c4, campo5: c5,
    banco: c1.slice(0,3),
    moeda: c1[3],
    cl1: c1.slice(4,9),   // cl[0..4] (sem dv)
    cl2: c2.slice(0,10),  // cl[5..14] (sem dv)
    cl3: c3.slice(0,10),  // cl[15..24] (sem dv)
    dvGeral: c4,
    fator: c5.slice(0,4),
    valor: c5.slice(4),
  }
}

// ─── Reconstruir campo livre de uma linha digitável ──────────────────────────
function clFromLD(ld47) {
  const p = parseLD(ld47)
  return p.cl1 + p.cl2 + p.cl3
}

// ─── Reconstruir código de barras 44 de uma linha digitável ─────────────────
function cb44FromLD(ld47) {
  const p = parseLD(ld47)
  const cl = clFromLD(ld47)
  return p.banco + p.moeda + p.dvGeral + p.fator + p.valor + cl
}

// ─── Parse campo livre Itaú ──────────────────────────────────────────────────
function parseCampoLivreItau(cl25) {
  // Estrutura documentada no codigoBarras.ts:
  // [1-3]   Carteira (3)
  // [4-11]  Nosso Número (8 sem DV)
  // [12]    DV Nosso Número
  // [13-16] Agência (4)
  // [17-21] Conta (5)
  // [22]    DAC Agência+Conta
  // [23-25] '000'
  return {
    carteira:    cl25.slice(0,3),
    nossoNumero: cl25.slice(3,11),
    dvNN:        cl25[11],
    agencia:     cl25.slice(12,16),
    conta:       cl25.slice(16,21),
    dacAgConta:  cl25[21],
    zeros:       cl25.slice(22,25),
  }
}

// ─── DV Módulo 10 ────────────────────────────────────────────────────────────
function mod10(num) {
  const digits = String(num).replace(/\D/g,'')
  let soma = 0, mult = 2
  for (let i = digits.length-1; i >= 0; i--) {
    let r = parseInt(digits[i]) * mult
    if (r >= 10) r = Math.floor(r/10) + r%10
    soma += r
    mult = mult === 2 ? 1 : 2
  }
  const resto = soma % 10
  return resto === 0 ? 0 : 10 - resto
}

// ─── DV Módulo 11 (barras) ───────────────────────────────────────────────────
function mod11Barras(num) {
  const digits = String(num).replace(/\D/g,'')
  let soma = 0, peso = 2
  for (let i = digits.length-1; i >= 0; i--) {
    soma += parseInt(digits[i]) * peso
    peso = peso === 9 ? 2 : peso+1
  }
  const resto = soma % 11
  return resto < 2 ? 1 : 11 - resto
}

// ─── Fator de vencimento ─────────────────────────────────────────────────────
const BASE = new Date('1997-10-07T12:00:00Z')
function fatorParaData(fator) {
  const f = parseInt(fator)
  const dias = f - 1000
  const d = new Date(BASE.getTime() + dias * 86400000)
  return d.toISOString().slice(0,10)
}

// ═══════════════════════════════════════════════════════════════════════════
// ANÁLISE
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════')
console.log('🔍 AUDITORIA BOLETO ITAÚ — SISTEMA vs. BANCO')
console.log('═══════════════════════════════════════════════════\n')

// ─── 1. Parse do CB do sistema ───────────────────────────────────────────────
const cbSistema = parseCB(CB_SISTEMA)
const clSistema = parseCampoLivreItau(cbSistema.campoLivre)

console.log('📄 BOLETO SISTEMA (código de barras gerado):')
console.log(`   CB 44:       ${CB_SISTEMA}`)
console.log(`   Banco:       ${cbSistema.banco}`)
console.log(`   Fator:       ${cbSistema.fator} → Venc: ${fatorParaData(cbSistema.fator)}`)
console.log(`   Valor:       R$ ${parseInt(cbSistema.valor)/100}`)
console.log(`   DV Geral:    ${cbSistema.dvGeral}`)
console.log(`   Campo Livre: ${cbSistema.campoLivre}`)
console.log(`   ├─ Carteira:    ${clSistema.carteira}`)
console.log(`   ├─ NossoNumero: ${clSistema.nossoNumero}`)
console.log(`   ├─ DV NN:       ${clSistema.dvNN}`)
console.log(`   ├─ Agência:     ${clSistema.agencia}`)
console.log(`   ├─ Conta:       ${clSistema.conta}`)
console.log(`   ├─ DAC Ag+Ct:   ${clSistema.dacAgConta}`)
console.log(`   └─ Zeros:       ${clSistema.zeros}`)

// ─── 2. Reconstrução do CB do banco via linha digitável ──────────────────────
const cb44Banco = cb44FromLD(LD_BANCO)
const ldBancoP = parseLD(LD_BANCO)
const clBancoStr = clFromLD(LD_BANCO)
const clBanco = parseCampoLivreItau(clBancoStr)

console.log('\n🏦 BOLETO BANCO (linha digitável registrada):')
console.log(`   LD 47:       ${LD_BANCO}`)
console.log(`   CB reconstruído: ${cb44Banco}`)
console.log(`   Fator:       ${ldBancoP.fator} → Venc: ${fatorParaData(ldBancoP.fator)}`)
console.log(`   Valor:       R$ ${parseInt(ldBancoP.valor)/100}`)
console.log(`   DV Geral:    ${ldBancoP.dvGeral}`)
console.log(`   Campo Livre: ${clBancoStr}`)
console.log(`   ├─ Carteira:    ${clBanco.carteira}`)
console.log(`   ├─ NossoNumero: ${clBanco.nossoNumero}`)
console.log(`   ├─ DV NN:       ${clBanco.dvNN}`)
console.log(`   ├─ Agência:     ${clBanco.agencia}`)
console.log(`   ├─ Conta:       ${clBanco.conta}`)
console.log(`   ├─ DAC Ag+Ct:   ${clBanco.dacAgConta}`)
console.log(`   └─ Zeros:       ${clBanco.zeros}`)

// ─── 3. Verificação de DVs ───────────────────────────────────────────────────
console.log('\n📊 VERIFICAÇÃO DE DVs:')

const dvNNSistema = mod10('109' + clSistema.nossoNumero)
console.log(`   DV NossoNum sistema: informado=${clSistema.dvNN}, calculado=${dvNNSistema}, OK=${String(dvNNSistema) === clSistema.dvNN}`)

const dvNNBanco = mod10('109' + clBanco.nossoNumero)
console.log(`   DV NossoNum banco:   informado=${clBanco.dvNN}, calculado=${dvNNBanco}, OK=${String(dvNNBanco) === clBanco.dvNN}`)

const dacSistema = mod10(clSistema.agencia + clSistema.conta)
console.log(`   DAC Ag+Ct sistema:   informado=${clSistema.dacAgConta}, calculado=${dacSistema}`)

const dacBanco = mod10(clBanco.agencia + clBanco.conta)
console.log(`   DAC Ag+Ct banco:     informado=${clBanco.dacAgConta}, calculado=${dacBanco}`)

// Verifica DV geral do sistema
const cbSemDv = CB_SISTEMA.slice(0,4) + CB_SISTEMA.slice(5)
const dvGeralCalc = mod11Barras(cbSemDv)
console.log(`\n   DV Geral sistema: informado=${cbSistema.dvGeral}, calculado=${dvGeralCalc}, OK=${dvGeralCalc === parseInt(cbSistema.dvGeral)}`)

// Verifica DV geral do banco
const cbBancoSemDv = cb44Banco.slice(0,4) + cb44Banco.slice(5)
const dvGeralBancoCalc = mod11Barras(cbBancoSemDv)
console.log(`   DV Geral banco:   informado=${ldBancoP.dvGeral}, calculado=${dvGeralBancoCalc}, OK=${dvGeralBancoCalc === parseInt(ldBancoP.dvGeral)}`)

// ─── 4. Diferenças ────────────────────────────────────────────────────────────
console.log('\n🔴 DIFERENÇAS ENCONTRADAS:')

if (clSistema.conta !== clBanco.conta) {
  console.log(`   CONTA: sistema="${clSistema.conta}" vs. banco="${clBanco.conta}"`)
}
if (clSistema.agencia !== clBanco.agencia) {
  console.log(`   AGÊNCIA: sistema="${clSistema.agencia}" vs. banco="${clBanco.agencia}"`)
}
if (clSistema.nossoNumero !== clBanco.nossoNumero) {
  console.log(`   NOSSO NÚMERO: sistema="${clSistema.nossoNumero}" vs. banco="${clBanco.nossoNumero}"`)
}
if (clSistema.dvNN !== clBanco.dvNN) {
  console.log(`   DV NN: sistema="${clSistema.dvNN}" vs. banco="${clBanco.dvNN}"`)
}
if (ldBancoP.fator !== cbSistema.fator) {
  console.log(`   FATOR: sistema="${cbSistema.fator}" (${fatorParaData(cbSistema.fator)}) vs. banco="${ldBancoP.fator}" (${fatorParaData(ldBancoP.fator)})`)
}
if (CB_SISTEMA === cb44Banco) {
  console.log('   ✅ Códigos de barras IDÊNTICOS.')
} else {
  console.log(`\n   SISTEMA: ${CB_SISTEMA}`)
  console.log(`   BANCO:   ${cb44Banco}`)
  // Find diff position
  for (let i=0; i<44; i++) {
    if (CB_SISTEMA[i] !== cb44Banco[i]) {
      console.log(`   Primeira diferença na posição ${i+1}: sistema='${CB_SISTEMA[i]}' banco='${cb44Banco[i]}'`)
      break
    }
  }
}

// ─── 5. Análise do campo livre correto para esses dados ─────────────────────
console.log('\n🔬 ANÁLISE: O que o banco registrou vs. o que geramos')
console.log(`   Agência do boleto (imagem 1): 6492`)
console.log(`   Conta do boleto (imagem 1):   340226 → sem DV = 34022, DV=6`)
console.log(`   Sistema usa conta PADSTART(5): "${clSistema.conta}" (5 dígitos)`)
console.log(`   Banco tem conta: "${clBanco.conta}" (5 dígitos)`)
console.log(`\n   Nota banco - Nosso Número: 6492340221090000000018`)
console.log(`   Isso sugere formato: agencia(4) + conta(6) + carteira(3) + nossoNumero(9)`)
console.log(`\n   HIPÓTESE: conta enviada no CNAB com 6 dígitos vs. campo livre com 5 dígitos`)
