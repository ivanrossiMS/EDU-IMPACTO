const fs = require('fs');
let lines = fs.readFileSync('app/(app)/academico/responsaveis/page.tsx', 'utf8').split('\n');

const s1 = lines.findIndex(l => l.includes('if (!activeKpi || !mounted) return []'));
if (s1 !== -1) {
    const s_start = s1 - 4; // covers const kpiFiltered
    lines.splice(s_start, 6);
}

const s2 = lines.findIndex(l => l.includes('const activeKpiData = KPIS.find(k => k.id === activeKpi)'));
if (s2 !== -1) lines.splice(s2, 6);

const s3 = lines.findIndex(l => l.includes('<div className="resp-kpi-panel"'));
if (s3 !== -1) {
    const e3 = lines.findIndex((l, i) => i > s3 && l.includes('</table>'));
    if (e3 !== -1) lines.splice(s3 - 2, e3 - s3 + 8); 
}

const s4 = lines.findIndex(l => l.includes('const [activeKpi, setActiveKpi]'));
if (s4 !== -1) lines.splice(s4, 1);

const s5 = lines.findIndex(l => l.includes('includes(activeKpi||'));
if (s5 !== -1) lines.splice(s5 - 2, 5);

fs.writeFileSync('app/(app)/academico/responsaveis/page.tsx', lines.join('\n'));
console.log('Success');
