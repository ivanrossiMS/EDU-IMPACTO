const fs = require('fs');
let lines = fs.readFileSync('app/(app)/academico/responsaveis/page.tsx', 'utf8').split('\n');

const apiStr =   const { data: apiResponse, isLoading } = useApiQuery<{data: any[]}>(
    ['responsaveis-search', search.trim().length >= 3 ? search : ''],
    \/api/responsaveis?limit=500\\,
    { staleTime: 300000 }
  );
  const responsaveis = useMemo<Responsavel[]>(() => {
    return (apiResponse?.data || []).sort((a, b) => (a.nome || '').localeCompare(b.nome || ''));
  }, [apiResponse]);;

lines[61] = apiStr;

fs.writeFileSync('app/(app)/academico/responsaveis/page.tsx', lines.join('\n'));
