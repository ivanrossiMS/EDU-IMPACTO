require('dotenv').config({ path: '.env.local' });
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

const client = createClient(supabaseUrl, supabaseServiceKey || supabaseAnonKey);

async function run() {
  const { data, error } = await client.from('comunicados').select('*').eq('id', 'AD-COM-NEW-1779551732873').single();
  if (error) {
    console.error(error);
  } else {
    console.log("TITULO:", data.titulo);
    console.log("TEXTO LENGTH:", data.texto ? data.texto.length : 0);
    console.log("TEXTO STARTS WITH:", data.texto ? data.texto.substring(0, 100) : "");
    console.log("TEXTO CONTAINS 'Ivan Rossi':", data.texto ? data.texto.includes('Ivan Rossi') : false);
    console.log("TURMAS:", data.turmas);
    console.log("DADOS.TURMAS:", data.dados?.turmas);
    console.log("DADOS.ALUNOSIDS:", data.dados?.alunosIds);
  }
}

run();
