const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  const { data, error } = await supabase
    .from('comunicados')
    .select('*');

  if (error) {
    console.error(error);
    return;
  }

  console.log(`Found ${data.length} rows in total.`);
  data.forEach((row, i) => {
    console.log(`\nRow ${i + 1}:`);
    console.log("ID:", row.id);
    console.log("Titulo:", row.titulo);
    console.log("Autor:", row.autor);
    
    const rowStr = JSON.stringify(row);
    const find = "Ivan Rossi";
    let idx = -1;
    while ((idx = rowStr.indexOf(find, idx + 1)) !== -1) {
      console.log(`  Found "${find}" at index ${idx}. Context:`, rowStr.substring(Math.max(0, idx - 20), idx + 200));
    }
  });
}
run();
