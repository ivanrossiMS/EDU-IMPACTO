import { createClient } from '@supabase/supabase-js'
import fs from 'fs'
import path from 'path'

// Read env variables manually
const envPath = path.resolve(process.cwd(), '.env.local')
const envContent = fs.readFileSync(envPath, 'utf8')
const env = {}
envContent.split('\n').forEach(line => {
  if (line && !line.startsWith('#') && line.includes('=')) {
    const [key, ...value] = line.split('=')
    env[key.trim()] = value.join('=').trim()
  }
})

const supabaseUrl = env.NEXT_PUBLIC_SUPABASE_URL
const supabaseServiceKey = env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Credentials not found in .env.local')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseServiceKey)

async function listAllFilesInBucket(bucketName, folder = '') {
  let allFiles = []
  const { data, error } = await supabase.storage.from(bucketName).list(folder, {
    limit: 100,
    offset: 0,
    sortBy: { column: 'name', order: 'asc' }
  })

  if (error) {
    console.error(`Error listing folder "${folder}" in bucket "${bucketName}":`, error)
    return []
  }

  for (const item of data) {
    const fullPath = folder ? `${folder}/${item.name}` : item.name
    if (item.id === null) {
      // It's a folder/directory placeholder in Supabase Storage list api
      const subFiles = await listAllFilesInBucket(bucketName, fullPath)
      allFiles = allFiles.concat(subFiles)
    } else {
      allFiles.push({
        bucket: bucketName,
        name: item.name,
        path: fullPath,
        size: item.metadata?.size,
        mimetype: item.metadata?.mimetype,
        created_at: item.created_at
      })
    }
  }

  return allFiles
}

async function main() {
  const { data: buckets, error: bucketError } = await supabase.storage.listBuckets()
  if (bucketError) {
    console.error('Error listing buckets:', bucketError)
    process.exit(1)
  }

  console.log(`Found ${buckets.length} bucket(s).`)
  for (const bucket of buckets) {
    console.log(`\nBucket: "${bucket.name}"`)
    const files = await listAllFilesInBucket(bucket.name)
    if (files.length === 0) {
      console.log('  No files found.')
    } else {
      console.log(`  Found ${files.length} file(s):`)
      files.forEach(f => {
        const sizeMb = f.size ? (f.size / (1024 * 1024)).toFixed(2) + ' MB' : 'unknown size'
        console.log(`  - [${f.mimetype || 'unknown type'}] ${f.path} (${sizeMb}) - Created: ${f.created_at}`)
      })
    }
  }
}

main()
