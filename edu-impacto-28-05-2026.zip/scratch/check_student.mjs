import { createClient } from '@supabase/supabase-js'
import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Carregar variáveis de ambiente
const envPath = path.resolve(__dirname, '../.env.local')
if (fs.existsSync(envPath)) {
  const content = fs.readFileSync(envPath, 'utf8')
  content.split('\n').forEach(line => {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) return
    const index = trimmed.indexOf('=')
    if (index > 0) {
      const key = trimmed.slice(0, index).trim()
      const val = trimmed.slice(index + 1).trim().replace(/^['"]|['"]$/g, '')
      process.env[key] = val
    }
  })
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

const supabase = createClient(supabaseUrl, supabaseKey)

async function checkStudentSchema() {
  console.log("⚡ Buscando um registro de aluno para obter o esquema de colunas...")
  const { data, error } = await supabase
    .from('alunos')
    .select('*')
    .limit(1)

  if (error) {
    console.error("❌ Erro ao buscar aluno:", error.message)
  } else {
    console.log("📋 Colunas do Aluno:", Object.keys(data[0] || {}))
    console.log("📋 Registro exemplo:", JSON.stringify(data[0] || {}, null, 2))
  }
}

checkStudentSchema()
