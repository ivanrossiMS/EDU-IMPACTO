const fs = require('fs');

const diff = fs.readFileSync('scratch/page_diff.diff', 'utf-8');
const lines = diff.split('\n');

let print = false;
let count = 0;

lines.forEach((line) => {
  if (line.startsWith('@@') && (line.includes('360') || line.includes('370') || line.includes('350') || line.includes('380') || line.includes('390'))) {
    print = true;
    count = 0;
  }
  if (print) {
    console.log(line);
    count++;
    if (count > 30) print = false;
  }
});
