import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';
const supabase = createClient(supabaseUrl, supabaseKey);

async function syncLogs() {
  try {
    console.log('--- STARTING TURNSTILE ACCESS LOGS SYNCHRONIZATION ---');

    // 1. Fetch active students to map matricula -> aluno_id/nome
    const { data: students, error: studentErr } = await supabase
      .from('alunos')
      .select('id, nome, matricula')
      .in('status', ['matriculado', 'cursando', 'ativo', 'Cursando', 'Matriculado', 'Ativo']);
    
    if (studentErr) throw studentErr;
    console.log(`Loaded ${students.length} active students for mapping.`);

    // Map matricula to student object
    const studentMap = {};
    students.forEach(s => {
      if (s.matricula) {
        // Clean matricula to number
        const cleanMat = s.matricula.replace(/\D/g, '');
        if (cleanMat) {
          studentMap[cleanMat] = s;
        }
      }
    });

    // 2. Fetch devices
    const { data: devices, error: devErr } = await supabase
      .from('portaria_dispositivos')
      .select('*');
    if (devErr) throw devErr;
    console.log(`Found ${devices.length} devices in database.`);

    let totalImported = 0;

    for (const d of devices) {
      if (!d.ip) continue;
      console.log(`\nConnecting to device: ${d.nome} (${d.ip}:${d.porta})...`);
      
      const loginUrl = `http://${d.ip}:${d.porta}/login.fcgi`;
      const login = d.configuracao?.login || 'admin';
      const password = d.configuracao?.password || 'admin';

      try {
        const loginRes = await fetch(loginUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ login, password })
        });
        const loginJson = await loginRes.json();
        const session = loginJson.session;
        if (!session) throw new Error('No session');

        // Fetch last 300 logs from the device
        const logsRes = await fetch(`http://${d.ip}:${d.porta}/load_objects.fcgi?session=${session}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            object: 'access_logs',
            limit: 300,
            order: ["time", "descending"]
          })
        });
        const logsJson = await logsRes.json();
        if (!logsJson.access_logs || logsJson.access_logs.length === 0) {
          console.log(`No logs found on device ${d.nome}.`);
          continue;
        }

        console.log(`Retrieved ${logsJson.access_logs.length} logs from device ${d.nome}. Processing...`);

        // Filter logs for today (May 19, 2026)
        const todayStr = '2026-05-19';
        const todayLogs = logsJson.access_logs.filter(l => {
          const logDate = new Date(l.time * 1000).toISOString().slice(0, 10);
          return logDate === todayStr;
        });

        console.log(`Found ${todayLogs.length} logs for today (${todayStr}) on device ${d.nome}.`);

        for (const log of todayLogs) {
          const logTime = new Date(log.time * 1000).toISOString();
          
          // Check if this event already exists in Supabase
          const { data: existing, error: existErr } = await supabase
            .from('portaria_eventos')
            .select('id')
            .eq('dispositivo_id', d.id)
            .eq('data_hora', logTime)
            .eq('user_id_equipamento', String(log.user_id))
            .limit(1)
            .maybeSingle();

          if (existErr) {
            console.error('Error checking existence of log:', existErr.message);
            continue;
          }

          if (existing) {
            // Already imported
            continue;
          }

          // Resolve student
          const cleanUserId = String(log.user_id).replace(/\D/g, '');
          const matchedStudent = studentMap[cleanUserId];

          const alunoId = matchedStudent ? matchedStudent.id : null;
          const alunoNome = matchedStudent ? matchedStudent.nome : '';
          const status = alunoId ? 'sucesso' : (log.user_id ? 'inconsistencia' : 'falha');

          console.log(`Importing log ID ${log.id} - Time: ${logTime} - User: ${log.user_id} (${alunoNome || 'Not matched'}) - Status: ${status}`);

          const { error: insertErr } = await supabase.from('portaria_eventos').insert({
            id: crypto.randomUUID(),
            aluno_id: alunoId,
            aluno_nome: alunoNome,
            dispositivo_id: d.id,
            dispositivo_nome: d.nome,
            tipo: 'entrada',
            status: status,
            data_hora: logTime,
            user_id_equipamento: String(log.user_id),
            confianca: log.confidence || 90,
            payload_raw: log,
            unidade: d.unidade || ''
          });

          if (insertErr) {
            console.error('Insert error:', insertErr.message);
          } else {
            totalImported++;
          }
        }

      } catch (err) {
        console.error(`Failed to sync from device ${d.nome}:`, err.message);
      }
    }

    console.log(`\nSynchronization finished. Total new events imported: ${totalImported}`);

  } catch (err) {
    console.error(err);
  }
}

syncLogs();
