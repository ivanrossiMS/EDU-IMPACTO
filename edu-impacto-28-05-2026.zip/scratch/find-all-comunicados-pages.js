const fs = require('fs');
const path = require('path');

function searchDir(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      searchDir(fullPath);
    } else if (file === 'page.tsx' && fullPath.includes('comunicados')) {
      console.log("Found page.tsx:", fullPath);
    }
  }
}

searchDir(path.resolve(__dirname, '../app'));
