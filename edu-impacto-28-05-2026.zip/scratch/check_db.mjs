import { createClient } from '@supabase/supabase-js'
import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Carregar variáveis de ambiente
const envPath = path.resolve(__dirname, '../.env.local')
if (fs.existsSync(envPath)) {
  const content = fs.readFileSync(envPath, 'utf8')
  content.split('\n').forEach(line => {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) return
    const index = trimmed.indexOf('=')
    if (index > 0) {
      const key = trimmed.slice(0, index).trim()
      const val = trimmed.slice(index + 1).trim().replace(/^['"]|['"]$/g, '')
      process.env[key] = val
    }
  })
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

const supabase = createClient(supabaseUrl, supabaseKey)

async function getDevices() {
  console.log("⚡ Buscando dispositivos cadastrados na tabela 'portaria_dispositivos'...")
  const { data: devices, error } = await supabase
    .from('portaria_dispositivos')
    .select('*')

  if (error) {
    console.error("❌ Erro ao buscar dispositivos:", error.message)
  } else {
    console.log(`✅ Sucesso! Encontrados ${devices.length} dispositivos.`)
    console.log(JSON.stringify(devices, null, 2))
  }
}

getDevices()
