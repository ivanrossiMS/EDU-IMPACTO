const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  const { data, error } = await supabase
    .from('alunos')
    .select('id, nome, created_at, status, matricula')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching students:', error);
    return;
  }

  console.log(`Total students: ${data.length}`);

  // Test filter dateStart = "2026-05-26", dateEnd = "2026-05-27"
  const testRanges = [
    { dateStart: '2026-05-26', dateEnd: '2026-05-27' },
    { dateStart: '2026-05-26', dateEnd: '2026-05-26' },
    { dateStart: '2026-05-27', dateEnd: '2026-05-27' },
    { dateStart: '', dateEnd: '' }
  ];

  testRanges.forEach(range => {
    let filtered = [...data];
    if (range.dateStart) {
      const start = new Date(range.dateStart + 'T00:00:00');
      filtered = filtered.filter(item => {
        if (!item.created_at) return false;
        return new Date(item.created_at) >= start;
      });
    }
    if (range.dateEnd) {
      const end = new Date(range.dateEnd + 'T23:59:59');
      filtered = filtered.filter(item => {
        if (!item.created_at) return false;
        return new Date(item.created_at) <= end;
      });
    }
    console.log(`\nRange: ${range.dateStart || 'any'} to ${range.dateEnd || 'any'}`);
    console.log(`Matched: ${filtered.length} students`);
    filtered.forEach(item => {
      console.log(`  - ${item.nome} (${item.created_at})`);
    });
  });
}

run();
