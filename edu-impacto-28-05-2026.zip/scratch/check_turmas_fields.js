const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  const { data: turmas } = await supabase.from('turmas').select('*').limit(5);
  console.log('Sample turmas:');
  turmas.forEach(t => {
    console.log('------------------');
    console.log('ID:', t.id);
    console.log('Nome:', t.nome);
    console.log('Serie:', t.serie);
    console.log('Turno:', t.turno);
    console.log('Ano Letivo:', t.ano_letivo);
    console.log('Dados:', t.dados);
  });
}
run();
