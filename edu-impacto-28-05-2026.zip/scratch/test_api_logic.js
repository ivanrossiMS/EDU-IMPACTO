const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://lrpwerkkqrjkcauofhph.supabase.co', 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl');
async function run() {
  const { data: students } = await supabase.from('alunos').select('*').ilike('nome', '%Alana Sarah%');
  
  const allStudentRefs = students.flatMap((s) => [
      s.id, 
      s.matricula, 
      s.dados?.codigo, 
      s.matricula ? String(s.matricula) : null, 
      s.dados?.codigo ? String(s.dados?.codigo) : null
  ]).filter(Boolean)

  const { data: links } = await supabase.from('aluno_responsavel').select('*').in('aluno_id', allStudentRefs)
  
  const respIds = links?.map((l) => l.responsavel_id).filter(Boolean) || []
  const { data: responsaveis } = await supabase.from('responsaveis').select('*').in('id', respIds)
  
  const formattedData = students.map((student) => {
      const studentRefs = [
        student.id, 
        student.matricula, 
        student.dados?.codigo, 
        student.matricula ? String(student.matricula) : null, 
        student.dados?.codigo ? String(student.dados?.codigo) : null
      ].filter(Boolean)
      
      const linkedResponsaveis = links?.filter((l) => studentRefs.includes(l.aluno_id))
        .map((l) => {
          const resp = responsaveis.find((r) => r.id === l.responsavel_id) || {}
          return {
            ...resp,
            parentesco: l.parentesco,
            isFinanceiro: l.resp_financeiro,
            isPedagogico: l.resp_pedagogico,
          }
        }).filter((r) => r.id) || []

      return {
        ...student,
        responsaveis: linkedResponsaveis.length > 0 ? linkedResponsaveis : []
      }
    })
    
  console.log(JSON.stringify(formattedData[0].responsaveis, null, 2));
}
run();
