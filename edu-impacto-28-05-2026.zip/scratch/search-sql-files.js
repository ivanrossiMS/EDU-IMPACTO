const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const files = fs.readdirSync(rootDir);

console.log("Searching SQL files for 'comunicados' definitions:");
files.forEach(file => {
  if (file.endsWith('.sql')) {
    const filePath = path.join(rootDir, file);
    const content = fs.readFileSync(filePath, 'utf8');
    if (content.includes('comunicados')) {
      console.log(`\n--- Found in ${file} ---`);
      const lines = content.split('\n');
      lines.forEach((line, idx) => {
        if (line.includes('comunicados') || line.includes('trigger') || line.includes('autor')) {
          if (line.toLowerCase().includes('comunicados') || line.toLowerCase().includes('trigger') || line.toLowerCase().includes('autor')) {
            console.log(`${idx + 1}: ${line.trim()}`);
          }
        }
      });
    }
  }
});
