const url = 'https://lrpwerkkqrjkcauofhph.supabase.co/rest/v1/alunos?select=id,nome,turma,status';
const anonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxycHdlcmtrcXJqa2NhdW9maHBoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU0MDAzMjYsImV4cCI6MjA5MDk3NjMyNn0.1-_0vMiLn0Y9piS90150Ur7qx8ic1Kz64RuhiaVGLhg';

async function check() {
  try {
    const res = await fetch(url, {
      headers: {
        'apikey': anonKey,
        'Authorization': `Bearer ${anonKey}`
      }
    });
    const data = await res.json();
    console.log(`Found ${data.length} students.`);
    const matched = data.filter(a => a.nome?.toLowerCase().includes('ivan') || a.nome?.toLowerCase().includes('rossi'));
    console.log('Matched students:', matched);
  } catch (err) {
    console.error('Error:', err);
  }
}

check();
