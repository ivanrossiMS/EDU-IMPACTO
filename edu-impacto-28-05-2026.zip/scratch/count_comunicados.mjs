import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing environment variables!");
  console.log("URL:", supabaseUrl, "Key length:", supabaseKey?.length);
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function check() {
  const { data, error } = await supabase.from('comunicados').select('*');
  if (error) {
    console.error("Error fetching:", error);
  } else {
    console.log(`Found ${data.length} records in 'comunicados' table.`);
    if (data.length > 0) {
      console.log("Sample records:");
      console.log(JSON.stringify(data.slice(0, 5), null, 2));
    }
  }
}

check();
