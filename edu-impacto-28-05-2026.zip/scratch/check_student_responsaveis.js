const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  const { data: students, error } = await supabase
    .from('alunos')
    .select('id, nome, matricula, responsavel, responsavel_financeiro, responsavel_pedagogico, dados')
    .order('created_at', { ascending: false })
    .limit(10);

  if (error) {
    console.error(error);
    return;
  }

  for (const s of students) {
    const studentRefs = [
      s.id, 
      s.matricula, 
      s.dados?.codigo, 
      s.matricula ? String(s.matricula) : null, 
      s.dados?.codigo ? String(s.dados?.codigo) : null
    ].filter(Boolean);

    const { data: links, error: linksError } = await supabase
      .from('aluno_responsavel')
      .select('*')
      .in('aluno_id', studentRefs);

    console.log('====================================');
    console.log(`Student: ${s.nome} (ID: ${s.id}, Matricula: ${s.matricula})`);
    console.log(`Legacy fields -> responsavel:`, s.responsavel, `, responsavel_financeiro:`, s.responsavel_financeiro, `, responsavel_pedagogico:`, s.responsavel_pedagogico);
    console.log(`Links count:`, links?.length);
    if (links && links.length > 0) {
      for (const link of links) {
        const { data: resp } = await supabase.from('responsaveis').select('*').eq('id', link.responsavel_id).maybeSingle();
        console.log(`  Link: parentesco=${link.parentesco}, fin=${link.resp_financeiro}, ped=${link.resp_pedagogico}, outro=${link.resp_outro}`);
        console.log(`  Responsible: id=${resp?.id}, nome=${resp?.nome}, rfid=${resp?.rfid}, dias_acesso=${resp?.dias_acesso}, dados=`, resp?.dados);
      }
    } else {
      console.log(`  Fallback responsaveis from dados:`, s.dados?.responsaveis);
    }
  }
}

run();
