const fs = require('fs');
let content = fs.readFileSync('app/agenda-digital/colaborador/momentos/page.tsx', 'utf8');

// remove the chevron div
const chevronRegex = /<div style=\{\{ position: 'absolute', right: 14, top: '50%', transform: 'translateY\(-50%\)', pointerEvents: 'none', color: 'hsl\(var\(--text-muted\)\)' \}\}>\s*<svg[\s\S]*?<\/svg>\s*<\/div>/;
content = content.replace(chevronRegex, '');
fs.writeFileSync('app/agenda-digital/colaborador/momentos/page.tsx', content);
console.log('Fixed chevron in momentos');
