const fs = require('fs');

const pages = [
  'app/agenda-digital/colaborador/calendario/page.tsx',
  'app/agenda-digital/colaborador/conversas/page.tsx',
  'app/agenda-digital/colaborador/frequencia/page.tsx',
  'app/agenda-digital/colaborador/momentos/page.tsx',
  'app/agenda-digital/colaborador/notas/page.tsx',
  'app/agenda-digital/colaborador/ocorrencias/page.tsx'
];

for (const file of pages) {
  let content = fs.readFileSync(file, 'utf8');

  // Fix turmaOptions
  const regexOptions = /const turmaOptions = (React\.)?useMemo\(\(\) => \{[\s\S]*?\}, \[turmas, chatGroups, currentUser\]\)/;
  if (regexOptions.test(content)) {
    content = content.replace(regexOptions, `const turmaOptions = React.useMemo(() => {
    const userGroups = (chatGroups || []).filter(g => g.colaboradoresIds?.includes(currentUser?.id || ''))
    const accessibleTurmas = turmas.filter(t => {
       return userGroups.some(g => String(g.id) === \`sync-\${t.id}\` || g.nome === t.nome)
    })
    return [{ id: 'all', nome: 'Minhas Turmas' }, ...accessibleTurmas]
  }, [turmas, chatGroups, currentUser])`);
  }

  // Fix selectedTurmaName
  const regexName = /const selectedTurmaName = (React\.)?useMemo\(\(\) => \{[\s\S]*?\}, \[selectedTurmaId, turmas\]\)/;
  if (regexName.test(content)) {
    content = content.replace(regexName, `const selectedTurmaName = React.useMemo(() => {
    if (selectedTurmaId === 'all') return 'Minhas Turmas'
    const t = turmas.find(x => String(x.id) === String(selectedTurmaId) || String(x.codigo) === String(selectedTurmaId))
    return t ? t.nome : 'Turma Selecionada'
  }, [selectedTurmaId, turmas])`);
  }

  fs.writeFileSync(file, content);
  console.log('Fixed ' + file);
}
