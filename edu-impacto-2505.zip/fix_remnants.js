const fs = require('fs');

let ctx = fs.readFileSync('lib/dataContext.tsx', 'utf8');
ctx = ctx.replace(/setAgendamentos\(\[\]\)/g, '');
ctx = ctx.replace(/setFornecedoresCad\(\[\]\)/g, '');
ctx = ctx.replace(/setAgendamentos: \[\]/g, ''); // just in case
ctx = ctx.replace(/, setAgendamentos: \[\]/g, ''); 
ctx = ctx.replace(/setAgendamentos/g, '(() => {})');
ctx = ctx.replace(/setFornecedoresCad/g, '(() => {})');
fs.writeFileSync('lib/dataContext.tsx', ctx);

let backup = fs.readFileSync('components/configuracoes/BackupSection.tsx', 'utf8');
backup = backup.replace(/fornecedores,/g, '');
backup = backup.replace(/agendamentos,/g, '');
fs.writeFileSync('components/configuracoes/BackupSection.tsx', backup);

let testData = fs.readFileSync('components/configuracoes/TestDataSection.tsx', 'utf8');
testData = testData.replace(/.*fornecedoresCad.*/g, '');
testData = testData.replace(/.*setFornecedoresCad.*/g, '');
fs.writeFileSync('components/configuracoes/TestDataSection.tsx', testData);

// Remove next cache
const { execSync } = require('child_process');
execSync('rm -rf .next');
