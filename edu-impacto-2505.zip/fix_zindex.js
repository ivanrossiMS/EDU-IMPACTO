const fs = require('fs');

const files = [
  { file: 'app/agenda-digital/colaborador/ocorrencias/page.tsx', search: /marginBottom: 16, position: 'relative', zIndex: 10 \}\}>/, replace: "marginBottom: 16, position: 'relative', zIndex: 50 }}>" },
  { file: 'app/agenda-digital/colaborador/frequencia/page.tsx', search: /marginBottom: 24, position: 'relative', zIndex: 10 \}\}>/, replace: "marginBottom: 24, position: 'relative', zIndex: 50 }}>" },
  { file: 'app/agenda-digital/colaborador/notas/page.tsx', search: /marginBottom: 24, position: 'relative', zIndex: 10 \}\}>/, replace: "marginBottom: 24, position: 'relative', zIndex: 50 }}>" },
  { file: 'app/agenda-digital/colaborador/momentos/page.tsx', search: /marginTop: 8, position: 'relative', maxWidth: 300 \}\}>/, replace: "marginTop: 8, position: 'relative', maxWidth: 300, zIndex: 50 }}>" },
  { file: 'app/agenda-digital/colaborador/calendario/page.tsx', search: /className="ad-calendar-badge" style=\{\{ display: 'flex', alignItems: 'center' \}\}>/, replace: 'className="ad-calendar-badge" style={{ display: \'flex\', alignItems: \'center\', position: \'relative\', zIndex: 50 }}>' },
  { file: 'app/agenda-digital/colaborador/conversas/page.tsx', search: /<div style=\{\{ position: 'relative' \}\}>/, replace: "<div style={{ position: 'relative', zIndex: 50 }}>" }
];

files.forEach(({ file, search, replace }) => {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(search, replace);
  fs.writeFileSync(file, content);
  console.log('Fixed zIndex in ' + file);
});
