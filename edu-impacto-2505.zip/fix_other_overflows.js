const fs = require('fs');

const frequencia = 'app/agenda-digital/colaborador/frequencia/page.tsx';
let content = fs.readFileSync(frequencia, 'utf8');
// Fix frequencia header overflow
content = content.replace(/boxShadow: '0 15px 35px rgba\(0,0,0,0\.02\)', overflow: 'hidden'/g, "boxShadow: '0 15px 35px rgba(0,0,0,0.02)', overflow: 'visible'");
fs.writeFileSync(frequencia, content);
console.log('Fixed frequencia');

const notas = 'app/agenda-digital/colaborador/notas/page.tsx';
let content2 = fs.readFileSync(notas, 'utf8');
// Replace overflow hidden on header if exists
content2 = content2.replace(/boxShadow: '0 15px 35px rgba\(0,0,0,0\.02\)', overflow: 'hidden'/g, "boxShadow: '0 15px 35px rgba(0,0,0,0.02)', overflow: 'visible'");
fs.writeFileSync(notas, content2);
console.log('Fixed notas');

