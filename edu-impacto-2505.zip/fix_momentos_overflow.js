const fs = require('fs');
let content = fs.readFileSync('app/agenda-digital/colaborador/momentos/page.tsx', 'utf8');

// Replace overflow: 'hidden' with overflow: 'visible' in the header style
content = content.replace(/position: 'relative',\s*overflow: 'hidden'\s*\}\}>\s*\{\/\* Subtle animated gradient overlay inside the header \*\/\}/, `position: 'relative',
          overflow: 'visible'
        }}>
          {/* Background Gradients Layer */}
          <div style={{ position: 'absolute', inset: 0, borderRadius: 'inherit', overflow: 'hidden', pointerEvents: 'none' }}>
            {/* Subtle animated gradient overlay inside the header */}`);

// We also need to close the background gradients layer div after the two inner gradient divs
content = content.replace(/backgroundSize: '100% 200%', animation: 'gradientMove 3s ease infinite' \}\} \/>/, `backgroundSize: '100% 200%', animation: 'gradientMove 3s ease infinite' }} />
          </div>`);

fs.writeFileSync('app/agenda-digital/colaborador/momentos/page.tsx', content);
console.log('Fixed overflow in momentos');
