const fs = require('fs');

const frequencia = 'app/agenda-digital/colaborador/frequencia/page.tsx';
const notas = 'app/agenda-digital/colaborador/notas/page.tsx';
const ocorrencias = 'app/agenda-digital/colaborador/ocorrencias/page.tsx';

// Fix alunosFiltrados
for (const file of [frequencia, notas, ocorrencias]) {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/\s*if \(currentUser\?\.perfil === 'Administrador' \|\| currentUser\?\.perfil === 'Direção'\) return alunos;\n/g, '\n');
  fs.writeFileSync(file, content);
  console.log('Fixed alunosFiltrados security bypass in ' + file);
}

// Fix ocorrenciasFiltradas
let ocorrenciasContent = fs.readFileSync(ocorrencias, 'utf8');
ocorrenciasContent = ocorrenciasContent.replace(/if \(selectedTurmaId === 'all'\) return true;\n\s*\/\/ Verifica se o aluno da ocorrência pertence à turma selecionada\n/g, '// Verifica se o aluno da ocorrência pertence à turma selecionada\n        ');
fs.writeFileSync(ocorrencias, ocorrenciasContent);
console.log('Fixed ocorrenciasFiltradas security bypass in ' + ocorrencias);

