import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';
const supabase = createClient(supabaseUrl, supabaseKey);

async function checkDevice() {
  try {
    const { data: devices } = await supabase.from('portaria_dispositivos').select('*');
    for (const d of devices) {
      if (!d.ip) continue;
      console.log(`\nConnecting to device: ${d.nome} (${d.ip}:${d.porta})...`);
      
      const loginUrl = `http://${d.ip}:${d.porta}/login.fcgi`;
      const login = d.configuracao?.login || 'admin';
      const password = d.configuracao?.password || 'admin';

      try {
        const loginRes = await fetch(loginUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ login, password })
        });
        const loginJson = await loginRes.json();
        const session = loginJson.session;
        if (!session) throw new Error('No session');

        // Fetch general configuration keys
        const configRes = await fetch(`http://${d.ip}:${d.porta}/get_configuration.fcgi?session=${session}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ general: ["online"] })
        });
        const configJson = await configRes.json();
        console.log('General Config from device:', JSON.stringify(configJson, null, 2));

      } catch (err) {
        console.error(`Failed to communicate with device ${d.nome}:`, err.message);
      }
    }
  } catch (err) {
    console.error(err);
  }
}

checkDevice();
