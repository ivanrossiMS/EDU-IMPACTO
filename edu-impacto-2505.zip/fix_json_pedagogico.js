require('dotenv').config({ path: '.env.local' })
const { createClient } = require('@supabase/supabase-js')

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing keys!")
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseKey)

async function run() {
  try {
    const { data: students, error: fetchErr } = await supabase
      .from('alunos')
      .select('id, dados')

    if (fetchErr) {
      console.error('Error fetching students:', fetchErr)
      return
    }

    if (!students || students.length === 0) {
      console.log('No students found.')
      return
    }

    let updatedCount = 0;
    
    for (const student of students) {
      if (student.dados && Array.isArray(student.dados.responsaveis)) {
        let changed = false;
        
        const newResponsaveis = student.dados.responsaveis.map(resp => {
          const parentesco = String(resp.parentesco || resp.tipo || '').toLowerCase().trim();
          
          if (parentesco === 'pai' || parentesco === 'mãe' || parentesco === 'mae') {
            const isFin = resp.isFinanceiro || resp.respFinanceiro;
            const isPed = resp.isPedagogico || resp.respPedagogico;
            const isOutro = resp.isOutro;
            
            if (!isFin && !isPed && !isOutro) {
              changed = true;
              return { ...resp, isPedagogico: true, respPedagogico: true };
            }
          }
          return resp;
        });

        if (changed) {
          updatedCount++;
          const newDados = { ...student.dados, responsaveis: newResponsaveis };
          
          const { error: updateErr } = await supabase
            .from('alunos')
            .update({ dados: newDados })
            .eq('id', student.id);
            
          if (updateErr) {
            console.error(`Error updating student ${student.id}:`, updateErr);
          }
        }
      }
    }

    // ALSO fix aluno_responsavel just in case
    const { data: links } = await supabase.from('aluno_responsavel').select('*');
    let linkUpdates = 0;
    
    if (links) {
      for (const link of links) {
        const par = String(link.parentesco || '').toLowerCase().trim();
        if (par === 'pai' || par === 'mãe' || par === 'mae') {
           if (!link.resp_financeiro && !link.resp_pedagogico && !link.resp_outro) {
              linkUpdates++;
              await supabase.from('aluno_responsavel')
                .update({ resp_pedagogico: true })
                .eq('aluno_id', link.aluno_id)
                .eq('responsavel_id', link.responsavel_id);
           }
        }
      }
    }

    console.log(`Analyzed ${students.length} students.`)
    console.log(`Updated JSON responsaveis for ${updatedCount} students.`)
    console.log(`Updated relational links for ${linkUpdates} links.`)

  } catch (err) {
    console.error("Script exception:", err)
  }
}

run()
