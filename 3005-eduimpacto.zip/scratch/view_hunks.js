const fs = require('fs');

const diff = fs.readFileSync('scratch/page_diff.diff', 'utf-8');
const lines = diff.split('\n');

let insideHunk = false;
let hunkContent = [];

lines.forEach((line) => {
  if (line.startsWith('@@')) {
    if (insideHunk) {
      const text = hunkContent.join('\n');
      if (text.includes('filtered.map') || text.includes('motion.div') || text.includes('Content Column')) {
        console.log(text);
        console.log('=========================================');
      }
    }
    hunkContent = [line];
    insideHunk = true;
  } else if (insideHunk) {
    hunkContent.push(line);
  }
});

// Print the last one
if (insideHunk) {
  const text = hunkContent.join('\n');
  if (text.includes('filtered.map') || text.includes('motion.div') || text.includes('Content Column')) {
    console.log(text);
  }
}
