import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Load environment variables
const envPath = path.resolve(__dirname, '../.env.local')
if (fs.existsSync(envPath)) {
  const content = fs.readFileSync(envPath, 'utf8')
  content.split('\n').forEach(line => {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) return
    const index = trimmed.indexOf('=')
    if (index > 0) {
      const key = trimmed.slice(0, index).trim()
      const val = trimmed.slice(index + 1).trim().replace(/^['"]|['"]$/g, '')
      process.env[key] = val
    }
  })
}

async function test() {
  const port = 3002
  const studentId = '4051'
  const className = encodeURIComponent('1ª SÉRIE - ENSINO MÉDIO')
  const url = `http://localhost:${port}/api/comunicados?aluno_id=${studentId}&turma_id=${className}`

  console.log("Fetching URL:", url)
  try {
    const res = await fetch(url)
    console.log("Status:", res.status)
    const data = await res.json()
    console.log("Returned data length:", data.length)
    console.log(JSON.stringify(data, null, 2))
  } catch (err) {
    console.error("Fetch failed:", err)
  }
}

test()
