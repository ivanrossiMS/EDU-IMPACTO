const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  // Let's get Rafael
  const { data: students } = await supabase.from('alunos').select('*').eq('nome', 'Rafael Rufino Kichler');
  const student = students[0];
  console.log('Student ID:', student.id, 'type:', typeof student.id);
  console.log('Student Matricula:', student.matricula, 'type:', typeof student.matricula);

  const studentRefs = [
    student.id,
    student.matricula,
    student.dados?.codigo,
    student.matricula ? String(student.matricula) : null,
    student.dados?.codigo ? String(student.dados?.codigo) : null
  ].filter(Boolean);
  console.log('studentRefs:', studentRefs, 'types:', studentRefs.map(x => typeof x));

  const { data: links } = await supabase.from('aluno_responsavel').select('*').in('aluno_id', studentRefs);
  console.log('Links count:', links?.length);
  if (links) {
    links.forEach(l => {
      console.log(`Link: id=${l.id}, aluno_id=${l.aluno_id}, type=${typeof l.aluno_id}`);
      console.log(`Is aluno_id in studentRefs?`, studentRefs.includes(l.aluno_id));
      console.log(`Is String(aluno_id) in studentRefs?`, studentRefs.map(String).includes(String(l.aluno_id)));
    });
  }
}
run();
