const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');

const envFile = fs.readFileSync('.env.local', 'utf-8');
const env = {};
envFile.split('\n').forEach(line => {
  if (line && !line.startsWith('#')) {
    const parts = line.split('=');
    if (parts.length >= 2) {
      env[parts[0].trim()] = parts.slice(1).join('=').trim();
    }
  }
});

const supabaseUrl = env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = env.SUPABASE_SERVICE_ROLE_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

async function main() {
  const turmaId = '1º ANO A - MATUTINO';
  
  let query = supabase.from('comunicados').select('*');
  const conditions = [`destino.eq."todos"`];
  conditions.push(`dados->turmas.cs.["${turmaId}"]`);
  
  query = query.or(conditions.join(','));
  const { data, error } = await query;
  
  if (error) {
    console.error('Error:', error);
  } else {
    console.log('Results for turma:', turmaId);
    console.log('Count:', data.length);
    data.forEach(c => {
      console.log('- ', c.id, ':', c.titulo);
    });
  }
}
main();
