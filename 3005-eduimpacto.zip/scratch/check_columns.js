const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function check() {
  const tables = ['comunicados', 'momentos', 'eventos', 'ocorrencias', 'boletins'];
  for (const table of tables) {
    const { data, error } = await supabase
      .from(table)
      .select('*')
      .limit(1);

    if (error) {
      console.log(`Table ${table} error:`, error.message);
    } else if (data && data.length > 0) {
      const row = data[0];
      const hasLeituras = 'leituras' in row;
      console.log(`Table ${table}: has 'leituras' column? ${hasLeituras}. Columns:`, Object.keys(row));
    } else {
      console.log(`Table ${table}: Empty table.`);
    }
  }
}

check();
