const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  const url = new URL('http://localhost:3000/api/alunos?all=true');
  
  // Directly run the SQL query from GET handler
  let query = supabase
    .from('alunos')
    .select('id, nome, matricula, turma, serie, turno, status, email, data_nascimento, responsavel, responsavel_financeiro, responsavel_pedagogico, telefone, inadimplente, risco_evasao, media, frequencia, obs, unidade, foto, dados, updated_at, created_at', { count: 'exact' });

  let queryExec = query.order('created_at', { ascending: false });
  const { data: students, error: studentsError } = await queryExec;

  if (studentsError) {
    console.error(studentsError);
    return;
  }

  const allStudentRefs = students.flatMap((s) => [
    s.id, 
    s.matricula, 
    s.dados?.codigo, 
    s.matricula ? String(s.matricula) : null, 
    s.dados?.codigo ? String(s.dados?.codigo) : null
  ]).filter(Boolean);

  const { data: links, error: linksError } = await supabase
    .from('aluno_responsavel')
    .select('*')
    .in('aluno_id', allStudentRefs);

  const respIds = links?.map((l) => l.responsavel_id).filter(Boolean) || [];
  let responsaveis = [];
  
  if (respIds.length > 0) {
    const { data: respData } = await supabase
      .from('responsaveis')
      .select('*')
      .in('id', respIds);
    responsaveis = respData || [];
  }

  const formattedData = students.map((student) => {
    const studentRefs = [
      student.id, 
      student.matricula, 
      student.dados?.codigo, 
      student.matricula ? String(student.matricula) : null, 
      student.dados?.codigo ? String(student.dados?.codigo) : null
    ].filter(Boolean);
    
    const linkedResponsaveis = links?.filter((l) => studentRefs.includes(l.aluno_id))
      .map((l) => {
        const resp = responsaveis.find((r) => r.id === l.responsavel_id) || {};
        return {
          ...resp,
          parentesco: l.parentesco,
          isFinanceiro: l.resp_financeiro,
          isPedagogico: l.resp_pedagogico,
          isOutro: l.resp_outro,
          dataNasc: resp.data_nasc,
          diasAcesso: resp.dias_acesso
        };
      }).filter((r) => r.id) || [];

    const fallbackResponsaveis = student.dados?.responsaveis || [];

    return {
      ...student,
      ...(student.dados || {}),
      created_at: student.created_at,
      responsaveis: linkedResponsaveis.length > 0 ? linkedResponsaveis : fallbackResponsaveis
    };
  });

  const targetNames = ['ALUNO TESTE', 'Rafael Rufino Kichler', 'Theo Rufino', 'Miguel Rufino Francelino', 'Letícia Magalhães Ferreira'];
  const targets = formattedData.filter(s => targetNames.includes(s.nome));
  
  console.log(`Matched target count: ${targets.length}`);
  targets.forEach(s => {
    console.log('\n----------------------------------------');
    console.log(`Student: ${s.nome} (ID: ${s.id})`);
    console.log(`Responsaveis length: ${s.responsaveis?.length}`);
    s.responsaveis.forEach((r, idx) => {
      console.log(`  Resp #${idx+1}: name=${r.nome}, parentesco=${r.parentesco}, isFinanceiro=${r.isFinanceiro}, isPedagogico=${r.isPedagogico}`);
    });
  });
}

run();
