const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://lrpwerkkqrjkcauofhph.supabase.co', 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl');
async function run() {
  const { data: alunos } = await supabase.from('alunos').select('*').ilike('nome', '%Alana Reche%');
  if (!alunos || alunos.length === 0) { console.log('Aluno nao encontrado'); return; }
  const s = alunos[0];
  console.log('id:', s.id, typeof s.id);
  console.log('matricula:', s.matricula, typeof s.matricula);
  console.log('dados:', s.dados);
  console.log('responsavel:', s.responsavel);
  console.log('responsavel_financeiro:', s.responsavel_financeiro);
  console.log('responsavel_pedagogico:', s.responsavel_pedagogico);
  
  const refs = [s.id, s.matricula, s.dados?.codigo, String(s.matricula), String(s.dados?.codigo)].filter((v,i,a)=>Boolean(v)&&a.indexOf(v)===i);
  console.log('refs:', refs);
  
  const { data: links } = await supabase.from('aluno_responsavel').select('*').in('aluno_id', refs);
  console.log('links count:', links?.length, 'links:', links);
  
  // RLS check: try with anon key (what browser gets)
  const supabaseAnon = createClient('https://lrpwerkkqrjkcauofhph.supabase.co', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxycHdlcmtrcXJqa2NhdW9maHBoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU0MDAzMjYsImV4cCI6MjA5MDk3NjMyNn0.1-_0vMiLn0Y9piS90150Ur7qx8ic1Kz64RuhiaVGLhg');
  const { data: linksAnon, error: anonErr } = await supabaseAnon.from('aluno_responsavel').select('*').in('aluno_id', refs);
  console.log('ANON links count:', linksAnon?.length, 'error:', anonErr?.message);
  const { data: respAnon, error: respAnonErr } = await supabaseAnon.from('responsaveis').select('*').limit(1);
  console.log('ANON responsaveis access:', respAnon?.length, 'error:', respAnonErr?.message);
}
run();
