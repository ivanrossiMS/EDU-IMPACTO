import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

// Inline .env.local loader
try {
  const envPath = path.resolve('.env.local');
  if (fs.existsSync(envPath)) {
    const envConfig = fs.readFileSync(envPath, 'utf8');
    envConfig.split('\n').forEach(line => {
      const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
      if (match) {
        const key = match[1];
        let value = match[2] || '';
        if (value.startsWith('"') && value.endsWith('"')) {
          value = value.substring(1, value.length - 1);
        } else if (value.startsWith("'") && value.endsWith("'")) {
          value = value.substring(1, value.length - 1);
        }
        process.env[key] = value.trim();
      }
    });
  }
} catch (e) {
  console.error("Could not load env file:", e);
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

// Define today's import window based on the recorded logs (17:52:00 to 17:57:00 UTC)
const startWindow = '2026-05-18T17:52:00.000Z';
const endWindow = '2026-05-18T17:57:00.000Z';
const EXECUTE = process.argv.includes('--execute');

async function undo() {
  console.log(`--- LAST IMPORT UNDO UTILITY ---`);
  console.log(`Time window: ${startWindow} to ${endWindow}`);
  console.log(`Mode: ${EXECUTE ? 'EXECUTE (REAL DELETION)' : 'SIMULATION (DRY RUN)'}\n`);

  // 1. Fetch relationships (aluno_responsavel) created in this window
  const { data: links, error: errLinks } = await supabase
    .from('aluno_responsavel')
    .select('id, aluno_id, responsavel_id, parentesco, created_at')
    .gte('created_at', startWindow)
    .lte('created_at', endWindow);

  if (errLinks) {
    console.error("Error fetching relationships:", errLinks);
    return;
  }

  // 2. Fetch parents (responsaveis) created in this window
  const { data: parents, error: errParents } = await supabase
    .from('responsaveis')
    .select('id, nome, created_at')
    .gte('created_at', startWindow)
    .lte('created_at', endWindow);

  if (errParents) {
    console.error("Error fetching parents:", errParents);
    return;
  }

  console.log(`Found ${links.length} relationships to delete.`);
  console.log(`Found ${parents.length} parents to delete.\n`);

  if (parents.length > 0) {
    console.log("Parents to be deleted:");
    parents.forEach(p => console.log(`  - [ID: ${p.id}] ${p.nome} (Criado em: ${p.created_at})`));
  }

  if (links.length > 0) {
    console.log("\nRelationships to be deleted:");
    links.forEach(l => console.log(`  - Link ID: ${l.id} (Aluno: ${l.aluno_id} <-> Resp: ${l.responsavel_id}, Grau: ${l.parentesco})`));
  }

  if (!EXECUTE) {
    console.log(`\n[DRY RUN COMPLETED] To apply these deletions permanently, run this script with the --execute flag:`);
    console.log(`node scratch/undo_last_import.mjs --execute`);
    return;
  }

  console.log(`\nExecuting permanent deletion...`);

  // Delete relationships first to maintain referential integrity
  if (links.length > 0) {
    const linkIds = links.map(l => l.id);
    const { error: delLinksErr } = await supabase
      .from('aluno_responsavel')
      .delete()
      .in('id', linkIds);

    if (delLinksErr) {
      console.error("Failed to delete relationships:", delLinksErr);
      return;
    }
    console.log(`Successfully deleted ${links.length} relationship links from 'aluno_responsavel'.`);
  }

  // Delete parents
  if (parents.length > 0) {
    const parentIds = parents.map(p => p.id);
    const { error: delParentsErr } = await supabase
      .from('responsaveis')
      .delete()
      .in('id', parentIds);

    if (delParentsErr) {
      console.error("Failed to delete parents:", delParentsErr);
      return;
    }
    console.log(`Successfully deleted ${parents.length} parent records from 'responsaveis'.`);
  }

  console.log(`\n🎉 Undo operation completed successfully!`);
}

undo();
