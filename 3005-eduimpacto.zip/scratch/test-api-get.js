const { GET } = require('../app/api/comunicados/route');

async function run() {
  const req = new Request('http://localhost:3000/api/comunicados');
  const res = await GET(req);
  const json = await res.json();
  console.log("Returned row count:", json.length);
  if (json.length > 0) {
    const firstRow = json[0];
    console.log("Row 0 ID:", firstRow.id);
    console.log("Row 0 autor:", firstRow.autor);
    console.log("Row 0 turmas length:", firstRow.turmas?.length);
    console.log("Row 0 has nested dados?:", !!firstRow.dados?.dados);
  }
}
run();
