const { createClient } = require('@supabase/supabase-js');
// Simulate exactly what the new API route does (with service role key)
const supabase = createClient('https://lrpwerkkqrjkcauofhph.supabase.co', 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl');
async function run() {
  const tests = ['3882', '5281']; // Alana Reche (3882) e Alana Sarah (5281)
  for (const alunoId of tests) {
    const refs = [alunoId];
    const { data: student } = await supabase.from('alunos').select('id,matricula,dados').eq('id', alunoId).single();
    if (student) {
      [student.matricula, student.dados?.codigo, String(student.matricula), String(student.dados?.codigo)]
        .filter(Boolean).forEach(r => { if (!refs.includes(r)) refs.push(r) });
    }
    const { data: links } = await supabase.from('aluno_responsavel').select('*').in('aluno_id', refs);
    const respIds = (links || []).map(l => l.responsavel_id).filter(Boolean);
    const { data: respData } = await supabase.from('responsaveis').select('id,nome').in('id', respIds);
    const responsaveis = (links || []).filter(l => refs.includes(l.aluno_id)).map(l => {
      const resp = (respData || []).find(r => r.id === l.responsavel_id) || {};
      return { nome: resp.nome, isFinanceiro: l.resp_financeiro, isPedagogico: l.resp_pedagogico, parentesco: l.parentesco };
    }).filter(r => r.nome);
    console.log(`\n=== Aluno ${alunoId} ===`);
    responsaveis.forEach(r => console.log(`  ${r.nome} | Fin:${r.isFinanceiro} Ped:${r.isPedagogico} | ${r.parentesco}`));
  }
}
run();
