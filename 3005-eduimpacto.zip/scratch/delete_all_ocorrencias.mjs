import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

async function clear() {
  console.log('Connecting to:', process.env.NEXT_PUBLIC_SUPABASE_URL)
  const { data, error } = await supabase.from('ocorrencias').delete().neq('id', '')
  if (error) {
    console.error('Error:', error.message)
  } else {
    console.log('All occurrences deleted successfully.')
  }
}

clear()
