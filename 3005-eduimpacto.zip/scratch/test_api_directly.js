// This script imports the api/alunos GET handler and runs it with a mock request
const { GET } = require('../app/api/alunos/route.ts');

// We need to set up environment for next/server and ts-node
// Since we are running in node, we can use ts-node or just transpile.
// But wait, route.ts has typescript imports.
// Let's write a simple script that uses ts-node to run the GET handler.
