const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://lrpwerkkqrjkcauofhph.supabase.co', 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl');
async function run() {
  const { data: alunos } = await supabase.from('alunos').select('*').ilike('nome', '%Alana Sarah%');
  const s = alunos[0];
  console.log("student.id =", s.id, typeof s.id);
  console.log("student.matricula =", s.matricula, typeof s.matricula);
  console.log("student.dados.codigo =", s.dados?.codigo, typeof s.dados?.codigo);
  
  // Simulate EXACTLY what the route.ts does now
  const allStudentRefs = [
      s.id, 
      s.matricula, 
      s.dados?.codigo, 
      s.matricula ? String(s.matricula) : null, 
      s.dados?.codigo ? String(s.dados?.codigo) : null
  ].filter(Boolean);
  console.log("allStudentRefs =", allStudentRefs);
  
  // Now check the aluno_responsavel table - what TYPE is aluno_id?
  const { data: links } = await supabase.from('aluno_responsavel').select('*').in('aluno_id', allStudentRefs);
  console.log("Links found:", links?.length, links?.map(l => l.aluno_id));
  
  // Also check the alunos table columns type information - see if id is UUID or integer
  const { data: schemaInfo } = await supabase.rpc('version');
  console.log("DB version:", schemaInfo);
}
run();
