import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';
const supabase = createClient(supabaseUrl, supabaseKey);

async function check() {
  const { data, error } = await supabase
    .from('portaria_eventos')
    .select('id, data_hora, payload_raw, user_id_equipamento, aluno_nome')
    .order('data_hora', { ascending: false })
    .limit(5);

  if (error) {
    console.error(error);
    return;
  }

  data.forEach(e => {
    console.log('--- EVENT ---');
    console.log('ID:', e.id);
    console.log('aluno_nome:', e.aluno_nome);
    console.log('data_hora:', e.data_hora);
    console.log('raw payload time:', e.payload_raw?.time);
    if (e.payload_raw?.time) {
      console.log('Calculated date from payload:', new Date(e.payload_raw.time * 1000).toISOString());
    }
  });
}

check();
