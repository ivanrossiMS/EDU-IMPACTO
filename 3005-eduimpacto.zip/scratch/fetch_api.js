const fs = require('fs');

async function tryFetch(port) {
  const url = `http://localhost:${port}/api/comunicados`;
  try {
    const res = await fetch(url);
    if (res.ok) {
      const data = await res.json();
      console.log(`SUCCESS ON PORT ${port}. Total: ${data.length}`);
      data.forEach((c, idx) => {
        console.log(`[${idx}] ID:`, c.id);
        console.log('  titulo:', c.titulo);
        console.log('  autor:', JSON.stringify(c.autor));
        console.log('  turmas count:', c.turmas?.length);
        console.log('  turmas:', JSON.stringify(c.turmas));
        console.log('-----------------------------');
      });
      return true;
    }
  } catch (err) {
    // console.log(`Failed port ${port}`);
  }
  return false;
}

async function main() {
  for (const port of [3000, 3001, 3002, 3003]) {
    const ok = await tryFetch(port);
    if (ok) break;
  }
}
main();
