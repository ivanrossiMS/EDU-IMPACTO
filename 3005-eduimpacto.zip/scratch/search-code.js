const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, '../app/agenda-digital/admin/comunicados/page.tsx');
const content = fs.readFileSync(filePath, 'utf8');

const lines = content.split('\n');
lines.forEach((line, idx) => {
  if (line.includes('turmas') || line.includes('join') || line.includes('autor') || line.includes('alunosIds')) {
    console.log(`${idx + 1}: ${line.trim()}`);
  }
});
