import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

// Inline .env.local loader
try {
  const envPath = path.resolve('.env.local');
  if (fs.existsSync(envPath)) {
    const envConfig = fs.readFileSync(envPath, 'utf8');
    envConfig.split('\n').forEach(line => {
      const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
      if (match) {
        const key = match[1];
        let value = match[2] || '';
        if (value.startsWith('"') && value.endsWith('"')) {
          value = value.substring(1, value.length - 1);
        } else if (value.startsWith("'") && value.endsWith("'")) {
          value = value.substring(1, value.length - 1);
        }
        process.env[key] = value.trim();
      }
    });
  }
} catch (e) {
  console.error("Could not load env file:", e);
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

async function inspect() {
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
  console.log(`Checking updates since: ${oneHourAgo}`);

  // Fetch recent Alunos
  const { data: recentAlunos, error: errAlunos } = await supabase
    .from('alunos')
    .select('id, nome, created_at, updated_at')
    .gte('updated_at', oneHourAgo);

  if (errAlunos) {
    console.error("Error fetching alumnos:", errAlunos);
  } else {
    console.log(`Total 'alunos' records updated in the last hour: ${recentAlunos?.length || 0}`);
    if (recentAlunos && recentAlunos.length > 0) {
      console.log("Sample recent alumnos:", recentAlunos.slice(0, 5));
    }
  }

  // Fetch recent Responsaveis
  const { data: recentResponsaveis, error: errResp } = await supabase
    .from('responsaveis')
    .select('id, nome, created_at')
    .gte('created_at', oneHourAgo);

  if (errResp) {
    console.error("Error fetching responsaveis:", errResp);
  } else {
    console.log(`Total 'responsaveis' records created in the last hour: ${recentResponsaveis?.length || 0}`);
    if (recentResponsaveis && recentResponsaveis.length > 0) {
      console.log("Sample recent responsaveis:", recentResponsaveis.slice(0, 5));
    }
  }
}

inspect();
