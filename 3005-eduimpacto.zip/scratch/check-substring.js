const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  const { data, error } = await supabase
    .from('comunicados')
    .select('*')
    .eq('id', 'AD-COM-NEW-1779551732873')
    .single();

  if (error) {
    console.error(error);
    return;
  }

  const json = JSON.stringify(data);
  const find = "Ivan Rossi +";
  const index = json.indexOf(find);
  if (index !== -1) {
    console.log(`Found "${find}" at index ${index}. Around it:`, json.substring(Math.max(0, index - 50), index + 500));
  } else {
    console.log(`Could not find "${find}" anywhere in the JSON representation of the row.`);
  }
}
run();
