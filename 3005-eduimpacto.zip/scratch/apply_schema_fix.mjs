import { createClient } from '@supabase/supabase-js';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Carregar variáveis de ambiente
const envPath = path.resolve(__dirname, '../.env.local');
if (fs.existsSync(envPath)) {
  const content = fs.readFileSync(envPath, 'utf8');
  content.split('\n').forEach(line => {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) return;
    const index = trimmed.indexOf('=');
    if (index > 0) {
      const key = trimmed.slice(0, index).trim();
      const val = trimmed.slice(index + 1).trim().replace(/^['"]|['"]$/g, '');
      process.env[key] = val;
    }
  });
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing service role env variables!");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function applyFix() {
  console.log("⚡ Executing SQL to restore missing columns...");
  
  const sql = `
    -- 1. Restore columns in responsaveis table
    ALTER TABLE public.responsaveis ADD COLUMN IF NOT EXISTS cpf TEXT;
    ALTER TABLE public.responsaveis ADD COLUMN IF NOT EXISTS rg TEXT;

    -- 2. Restore columns in alunos table
    ALTER TABLE public.alunos ADD COLUMN IF NOT EXISTS cpf TEXT;
    
    -- 3. Populate responsaveis.cpf from dados->>'cpf' if present
    UPDATE public.responsaveis 
    SET cpf = dados->>'cpf' 
    WHERE cpf IS NULL AND dados->>'cpf' IS NOT NULL;
    
    -- 4. Populate alunos.cpf from dados->>'cpf' if present
    UPDATE public.alunos 
    SET cpf = dados->>'cpf' 
    WHERE cpf IS NULL AND dados->>'cpf' IS NOT NULL;
  `;
  
  const { data, error } = await supabase.rpc('execute_sql_query', {
    sql_string: sql
  });
  
  if (error) {
    console.error("❌ Error executing migration SQL:", error.message);
  } else {
    console.log("✅ Successfully executed SQL migration!", data);
  }
}

applyFix();
