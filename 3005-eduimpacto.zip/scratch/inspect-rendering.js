const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, '../app/agenda-digital/admin/comunicados/page.tsx');
const content = fs.readFileSync(filePath, 'utf8');

const lines = content.split('\n');
for (let i = 340; i <= 430; i++) {
  console.log(`${i + 1}: ${lines[i]}`);
}
