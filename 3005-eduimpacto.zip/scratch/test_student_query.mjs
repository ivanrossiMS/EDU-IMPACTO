import { createClient } from '@supabase/supabase-js'
import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Load environment variables
const envPath = path.resolve(__dirname, '../.env.local')
if (fs.existsSync(envPath)) {
  const content = fs.readFileSync(envPath, 'utf8')
  content.split('\n').forEach(line => {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) return
    const index = trimmed.indexOf('=')
    if (index > 0) {
      const key = trimmed.slice(0, index).trim()
      const val = trimmed.slice(index + 1).trim().replace(/^['"]|['"]$/g, '')
      process.env[key] = val
    }
  })
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

const supabase = createClient(supabaseUrl, supabaseKey)

async function test() {
  const alunoId = '4051'
  const turmaId = '1ª SÉRIE - ENSINO MÉDIO' // Miguel Campos Jorge's class name
  
  console.log(`Checking for student ${alunoId} in class: ${turmaId}`)
  
  const conditions = [`destino.eq."todos"`];
  conditions.push(`dados->turmas.cs.["${turmaId}"]`);
  conditions.push(`dados->alunosIds.cs.["${alunoId}"]`);
  conditions.push(`dados->alunosIds.cs.["a_${alunoId}"]`);
  conditions.push(`dados->alunosIds.cs.["_ALU${alunoId}"]`);
  
  const queryStr = conditions.join(',')
  console.log("Query string:", queryStr)

  const { data, error } = await supabase
    .from('comunicados')
    .select('*')
    .or(queryStr)
    .order('data', { ascending: false });

  if (error) {
    console.error("Error querying:", error)
  } else {
    console.log("Records found:", data.length)
    console.log(data.map(d => ({ id: d.id, titulo: d.titulo, destino: d.destino })))
  }
}

test()
