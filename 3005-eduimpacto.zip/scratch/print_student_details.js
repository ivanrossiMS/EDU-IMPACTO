const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  const { data: students, error } = await supabase
    .from('alunos')
    .select('*')
    .in('nome', ['ALUNO TESTE', 'Rafael Rufino Kichler', 'Theo Rufino', 'Miguel Rufino Francelino', 'Letícia Magalhães Ferreira']);

  if (error) {
    console.error(error);
    return;
  }

  students.forEach(student => {
    console.log('-----------------------------');
    console.log('ID:', student.id);
    console.log('Name:', student.nome);
    console.log('Created At:', student.created_at);
    console.log('Status:', student.status);
    console.log('Data keys:', Object.keys(student.dados || {}));
    console.log('Full data field:', JSON.stringify(student.dados, null, 2));
  });
}

run();
