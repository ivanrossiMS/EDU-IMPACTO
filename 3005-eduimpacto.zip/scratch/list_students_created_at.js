const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });
if (!process.env.NEXT_PUBLIC_SUPABASE_URL) {
  require('dotenv').config({ path: '.env' });
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

async function listAllStudents() {
  const { data, error } = await supabase.from('alunos').select('id, nome, created_at, status');
  if (error) {
    console.error('Error fetching students:', error);
  } else {
    console.log(`Total students in DB: ${data.length}`);
    data.forEach((student, index) => {
      console.log(`${index + 1}. [${student.id}] ${student.nome} - Status: ${student.status} - Created: ${student.created_at}`);
    });
  }
}

listAllStudents();
