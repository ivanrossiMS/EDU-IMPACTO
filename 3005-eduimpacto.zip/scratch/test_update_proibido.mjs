import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co'
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl' // Service Role Key!

const supabase = createClient(supabaseUrl, supabaseKey)

async function run() {
  console.log('Updating responsavel 12321 (ivan35) to prohibited: false...')
  
  const { data, error } = await supabase
    .from('responsaveis')
    .update({ proibido: false })
    .eq('id', '12321')
    .select()
    
  if (error) {
    console.error('Error:', error)
    return
  }
  
  console.log('Successfully updated record!')
  console.log('New data:', JSON.stringify(data[0], null, 2))
}

run()
