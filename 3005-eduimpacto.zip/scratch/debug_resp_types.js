const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  const { data: links } = await supabase.from('aluno_responsavel').select('*').eq('aluno_id', '5358');
  if (links && links.length > 0) {
    const l = links[0];
    console.log('l.responsavel_id:', l.responsavel_id, 'type:', typeof l.responsavel_id);

    const { data: resp } = await supabase.from('responsaveis').select('id').eq('id', l.responsavel_id).maybeSingle();
    if (resp) {
      console.log('resp.id:', resp.id, 'type:', typeof resp.id);
      console.log('Strict comparison (resp.id === l.responsavel_id):', resp.id === l.responsavel_id);
      console.log('Coerced comparison (String(resp.id) === String(l.responsavel_id)):', String(resp.id) === String(l.responsavel_id));
    }
  }
}
run();
