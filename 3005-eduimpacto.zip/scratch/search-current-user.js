const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, '../lib/context.tsx');
const content = fs.readFileSync(filePath, 'utf8');

const lines = content.split('\n');
lines.forEach((line, idx) => {
  if (line.includes('currentUser')) {
    console.log(`${idx + 1}: ${line.trim()}`);
  }
});
