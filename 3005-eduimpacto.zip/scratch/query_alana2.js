const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://lrpwerkkqrjkcauofhph.supabase.co', 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl');
async function run() {
  const { data: alunos } = await supabase.from('alunos').select('*').ilike('nome', '%Alana Sarah%');
  console.log("Alunos:", alunos);
  if(alunos && alunos.length > 0) {
    const student = alunos[0];
    const refs = [student.id, student.matricula, student.dados?.codigo, String(student.matricula), String(student.dados?.codigo)].filter(Boolean);
    console.log("Looking up refs:", refs);
    
    // Check if there's any link matching these refs
    const { data: links1 } = await supabase.from('aluno_responsavel').select('*').in('aluno_id', refs);
    console.log("Links with current refs:", links1);
    
    // Also try a wildcard search on aluno_responsavel if we can't find anything
    // (If the DB has a completely different identifier for her)
    if(links1.length === 0) {
       console.log("No links found using standard refs. Searching by parentesco etc? No, let's see if she has legacy fields.");
       console.log("Legacy responsavel:", student.responsavel);
       console.log("Legacy resp_financeiro:", student.responsavel_financeiro);
       console.log("Legacy resp_pedagogico:", student.responsavel_pedagogico);
       
       // Try to find if she exists in aluno_responsavel with some other ID that looks like her matricula?
       const { data: allLinks } = await supabase.from('aluno_responsavel').select('aluno_id').limit(10);
       console.log("Sample of other links to see format:", allLinks);
    }
  }
}
run();
