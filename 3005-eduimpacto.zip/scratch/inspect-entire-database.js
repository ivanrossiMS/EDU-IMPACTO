const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  console.log("Searching database for '+ 1º'...");
  
  const tables = ['comunicados', 'configuracoes', 'alunos', 'turmas', 'agenda/grupos', 'agenda/mensagens', 'agenda/momentos', 'agenda/enquetes'];
  for (const table of tables) {
    try {
      const { data, error } = await supabase.from(table).select('*');
      if (error) continue;
      const json = JSON.stringify(data);
      if (json.includes('+ 1º') || json.includes('+ 1&ordm;')) {
        console.log(`FOUND in table ${table}!`);
        data.forEach(row => {
          const rowStr = JSON.stringify(row);
          if (rowStr.includes('+ 1º') || rowStr.includes('+ 1&ordm;')) {
            console.log("Matching row:", JSON.stringify(row, null, 2));
          }
        });
      }
    } catch(e) {
      console.log(`Error checking table ${table}:`, e.message);
    }
  }
  console.log("Search finished.");
}
run();
