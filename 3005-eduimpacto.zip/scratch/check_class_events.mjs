import fs from 'fs'

const envLocal = fs.readFileSync('.env.local', 'utf8')
const env = envLocal.split('\n').reduce((acc, line) => {
  const [k, ...v] = line.split('=')
  if (k && v.length > 0) acc[k.trim()] = v.join('=').trim().replace(/'/g, '').replace(/"/g, '')
  return acc
}, {})

const supabaseUrl = env['NEXT_PUBLIC_SUPABASE_URL']
const supabaseKey = env['SUPABASE_SERVICE_ROLE_KEY']

async function querySupabase(endpoint) {
  const url = `${supabaseUrl}/rest/v1/${endpoint}`
  const headers = {
    'apikey': supabaseKey,
    'Authorization': `Bearer ${supabaseKey}`,
    'Content-Type': 'application/json'
  }
  const res = await fetch(url, { headers })
  return res.json()
}

async function main() {
  // 1. Fetch class students
  const students = await querySupabase('alunos?select=id,nome,turma&turma=eq.5948')
  console.log(`Class 5948 Alunos count: ${students.length}`)
  const studentIds = students.map(s => s.id)

  // 2. Fetch events for these students on 2026-05-19
  const events = await querySupabase('portaria_eventos?select=aluno_id,aluno_nome,data_hora,status&tipo=eq.entrada&data_hora=gte.2026-05-19T00:00:00')
  const classEvents = events.filter(e => studentIds.includes(e.aluno_id))
  console.log(`Events on 2026-05-19 for class students:`, classEvents)

  // 3. Fetch frequency records for these students on 2026-05-19
  const freqs = await querySupabase('frequencias?select=*&turma_id=eq.5948&data=eq.2026-05-19')
  console.log('Frequencias in DB for class on 2026-05-19:', freqs)
}

main()
