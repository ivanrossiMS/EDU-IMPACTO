import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co'
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl' // Service Role Key!

const supabase = createClient(supabaseUrl, supabaseKey)

async function run() {
  console.log('Deleting student with ID 4834 (alun test4)...')
  
  const { error } = await supabase
    .from('alunos')
    .delete()
    .eq('id', '4834')
    
  if (error) {
    console.error('Error:', error)
    return
  }
  
  console.log('Successfully deleted record 4834!')
}

run()
