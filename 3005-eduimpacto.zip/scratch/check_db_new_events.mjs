import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';
const supabase = createClient(supabaseUrl, supabaseKey);

async function checkNewEvents() {
  try {
    const today = new Date().toISOString().slice(0, 10);
    const { data: events } = await supabase
      .from('portaria_eventos')
      .select('*')
      .gte('data_hora', `${today}T00:00:00`)
      .order('data_hora', { ascending: false });

    console.log(`Total events in DB for today (${today}):`, events.length);
    if (events.length > 0) {
      console.log('Latest 5 events:');
      console.log(JSON.stringify(events.slice(0, 5).map(e => ({
        id: e.id,
        time: e.data_hora,
        aluno: e.aluno_nome,
        dispositivo: e.dispositivo_nome,
        status: e.status
      })), null, 2));
    }
  } catch (err) {
    console.error(err);
  }
}

checkNewEvents();
