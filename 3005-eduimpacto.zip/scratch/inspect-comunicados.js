const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !serviceRoleKey) {
  console.error("Missing environment variables in .env.local!");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, serviceRoleKey);

async function run() {
  console.log("Fetching last 5 rows from 'comunicados' table...");
  const { data, error } = await supabase
    .from('comunicados')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(5);

  if (error) {
    console.error("Error fetching data:", error);
    return;
  }

  console.log(`Successfully fetched ${data.length} rows.`);
  data.forEach((row, i) => {
    console.log(`\n--- Row ${i + 1} ---`);
    console.log("ID:", row.id);
    console.log("Titulo:", row.titulo);
    console.log("Autor:", row.autor);
    console.log("Destino:", row.destino);
    console.log("Fixado:", row.fixado);
    console.log("Created At:", row.created_at);
    
    // Check if dados has nested dados
    console.log("Has 'dados.dados'?:", !!(row.dados && row.dados.dados));
    if (row.dados) {
      console.log("Keys in 'dados':", Object.keys(row.dados));
      if (row.dados.dados) {
        console.log("Keys in 'dados.dados':", Object.keys(row.dados.dados));
        console.log("Nested 'turmas' length:", row.dados.dados.turmas?.length);
        console.log("Nested 'anexos':", row.dados.dados.anexos);
      } else {
        console.log("Turmas length:", row.dados.turmas?.length);
        console.log("Anexos:", row.dados.anexos);
      }
    }
  });
}

run();
