import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co'
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl' // Service Role Key!

const supabase = createClient(supabaseUrl, supabaseKey)

async function check() {
  console.log('Querying student ivan25 and its links...')
  
  const { data: students, error: studentError } = await supabase
    .from('alunos')
    .select('*')
    .ilike('nome', '%ivan25%')
    
  if (studentError) {
    console.error('Student Error:', studentError)
    return
  }
  
  if (students.length === 0) {
    console.log('Student ivan25 not found!')
    return
  }
  
  const student = students[0]
  console.log(`- Student ID: ${student.id}, Nome: ${student.nome}`)
  
  // Fetch links
  const { data: links, error: linkError } = await supabase
    .from('aluno_responsavel')
    .select('*')
    .eq('aluno_id', student.id)
    
  if (linkError) {
    console.error('Link Error:', linkError)
    return
  }
  
  console.log('Found', links.length, 'links.')
  
  const respIds = links.map(l => l.responsavel_id)
  
  if (respIds.length > 0) {
    const { data: resps, error: respError } = await supabase
      .from('responsaveis')
      .select('*')
      .in('id', respIds)
      
    if (respError) {
      console.error('Resp Error:', respError)
      return
    }
    
    console.log('Found', resps.length, 'responsibles.')
    resps.forEach(r => {
      console.log(`- Resp ID: ${r.id}, Nome: ${r.nome}, Proibido: ${r.proibido}`)
    })
  } else {
    console.log('No links found for this student.')
  }
}

check()
