async function simulate() {
  const url = 'http://localhost:3000/api/portaria/webhook'
  
  // Payload simulando o envio oficial do iDFace em tempo real
  const payload = {
    object_changes: [
      {
        object: 'access_logs',
        type: 'inserted',
        values: {
          user_id: '5328', // ID do Matheus Pereira Barbosa Ramalho
          time: String(Math.floor(Date.now() / 1000)), // Epoch UNIX segundos atual
          device_id: '4408801109369742'
        }
      }
    ]
  }

  console.log("🚀 Enviando payload de simulação para o webhook local...")
  console.log(JSON.stringify(payload, null, 2))

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    })

    const data = await res.json()
    console.log(`📡 Resposta do Servidor Next.js (Status: ${res.status}):`)
    console.log(JSON.stringify(data, null, 2))
  } catch (err) {
    console.error("❌ Falha ao enviar requisição:", err.message)
  }
}

simulate()
