import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing service role variables!");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function check() {
  const { data, error } = await supabase.from('comunicados').select('*');
  if (error) {
    console.error("Error fetching:", error);
    return;
  }
  
  console.log(`Checking all ${data.length} records...`);
  
  data.forEach((row, index) => {
    const merged = { ...row, ...(row.dados || {}) };
    console.log(`\n--- Record ${index + 1} (ID: ${merged.id}) ---`);
    console.log("titulo:", merged.titulo);
    console.log("status:", merged.status);
    console.log("leituras:", merged.leituras, "Type:", typeof merged.leituras);
    console.log("ciencias:", merged.ciencias, "Type:", typeof merged.ciencias);
    console.log("turmas:", merged.turmas);
    console.log("alunosIds:", merged.alunosIds);
    
    if (!merged.leituras || typeof merged.leituras !== 'object') {
      console.warn("⚠️ CRITICAL: 'leituras' is NOT an object!");
    }
    if (!merged.ciencias || typeof merged.ciencias !== 'object') {
      console.warn("⚠️ CRITICAL: 'ciencias' is NOT an object!");
    }
  });
}

check();
