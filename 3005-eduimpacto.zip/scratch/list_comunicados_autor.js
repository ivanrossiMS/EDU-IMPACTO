const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');

const envFile = fs.readFileSync('.env.local', 'utf-8');
const env = {};
envFile.split('\n').forEach(line => {
  if (line && !line.startsWith('#')) {
    const parts = line.split('=');
    if (parts.length >= 2) {
      env[parts[0].trim()] = parts.slice(1).join('=').trim();
    }
  }
});

const supabase = createClient(env.NEXT_PUBLIC_SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

async function main() {
  const { data, error } = await supabase.from('comunicados').select('id, autor, texto, destino');
  if (error) {
    console.error(error);
  } else {
    data.forEach(c => {
      console.log('ID:', c.id);
      console.log('  autor:', JSON.stringify(c.autor));
      console.log('  destino:', JSON.stringify(c.destino));
      console.log('  texto length:', c.texto?.length);
      console.log('-------------------------');
    });
  }
}
main();
