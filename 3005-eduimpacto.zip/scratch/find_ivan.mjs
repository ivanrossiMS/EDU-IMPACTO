import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

const envPath = path.resolve('.env.local');
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf8');
  envContent.split('\n').forEach(line => {
    const parts = line.split('=');
    if (parts.length >= 2) {
      const key = parts[0].trim();
      const val = parts.slice(1).join('=').trim().replace(/^['"]|['"]$/g, '');
      process.env[key] = val;
    }
  });
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing environment variables!");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function find() {
  console.log("Searching for responsavel ID 8899...");
  
  // 1. Fetch responsavel with ID 8899
  const { data: resp, error: respErr } = await supabase
    .from('responsaveis')
    .select('*')
    .eq('id', '8899')
    .maybeSingle();
    
  if (respErr) {
    console.error("Error fetching responsavel:", respErr);
  } else {
    console.log("Responsavel with ID 8899:", JSON.stringify(resp, null, 2));
  }
  
  // 2. Fetch links in aluno_responsavel for ID 8899
  const { data: links, error: linksErr } = await supabase
    .from('aluno_responsavel')
    .select('*, aluno:alunos(id, nome)')
    .eq('responsavel_id', '8899');
    
  if (linksErr) {
    console.error("Error fetching links:", linksErr);
  } else {
    console.log(`Links for ID 8899: found ${links?.length || 0} links.`);
    console.log(JSON.stringify(links, null, 2));
  }
}

find();
