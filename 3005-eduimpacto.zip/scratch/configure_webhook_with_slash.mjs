import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';
const supabase = createClient(supabaseUrl, supabaseKey);

async function testConfig() {
  try {
    const ip = '192.168.1.98';
    const porta = 80;
    const login = 'admin';
    const password = 'Pass1081$';

    console.log(`Connecting to device at ${ip}:${porta}...`);
    const loginRes = await fetch(`http://${ip}:${porta}/login.fcgi`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ login, password })
    });
    const loginJson = await loginRes.json();
    const session = loginJson.session;
    if (!session) throw new Error('No session');

    console.log('1. Setting monitor path to: /api/portaria/webhook');
    const setRes = await fetch(`http://${ip}:${porta}/set_configuration.fcgi?session=${session}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        monitor: {
          request_timeout: '5000',
          hostname: '192.168.1.151',
          port: '3000',
          path: '/api/portaria/webhook'
        }
      })
    });
    console.log('Set Config status:', setRes.status);
    const setJson = await setRes.json();
    console.log('Set Config response:', setJson);

    console.log('2. Querying config back...');
    const getRes = await fetch(`http://${ip}:${porta}/get_configuration.fcgi?session=${session}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ monitor: ["path", "hostname"] })
    });
    const getJson = await getRes.json();
    console.log('Returned config:', JSON.stringify(getJson, null, 2));

  } catch (err) {
    console.error(err);
  }
}

testConfig();
