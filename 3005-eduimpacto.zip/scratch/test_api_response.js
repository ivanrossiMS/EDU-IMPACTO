async function run() {
  try {
    const res = await fetch('http://localhost:3000/api/alunos?all=true');
    const text = await res.text();
    console.log('Status code:', res.status);
    try {
      const json = JSON.parse(text);
      console.log('Total students in response:', json.data.length);
    } catch(err) {
      console.log('Response text (first 500 chars):', text.substring(0, 500));
    }
  } catch (e) {
    console.error('Fetch error:', e);
  }
}
run();
