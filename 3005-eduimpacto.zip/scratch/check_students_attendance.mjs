import fs from 'fs'

const envLocal = fs.readFileSync('.env.local', 'utf8')
const env = envLocal.split('\n').reduce((acc, line) => {
  const [k, ...v] = line.split('=')
  if (k && v.length > 0) acc[k.trim()] = v.join('=').trim().replace(/'/g, '').replace(/"/g, '')
  return acc
}, {})

const supabaseUrl = env['NEXT_PUBLIC_SUPABASE_URL']
const supabaseKey = env['SUPABASE_SERVICE_ROLE_KEY']

async function querySupabase(endpoint) {
  const url = `${supabaseUrl}/rest/v1/${endpoint}`
  const headers = {
    'apikey': supabaseKey,
    'Authorization': `Bearer ${supabaseKey}`,
    'Content-Type': 'application/json'
  }
  const res = await fetch(url, { headers })
  return res.json()
}

async function main() {
  const freqs = await querySupabase('frequencias?select=aluno_id,data,presente,dados&turma_id=eq.5948&data=eq.2026-05-19')
  console.log(`Frequencias on 2026-05-19 for class 5948: ${freqs.length} records.`)
  
  const present = freqs.filter(f => f.presente)
  const absent = freqs.filter(f => !f.presente)

  console.log(`Present count: ${present.length}`)
  console.log(`Absent count: ${absent.length}`)
  
  console.log('Sample absent records (first 3):', JSON.stringify(absent.slice(0, 3), null, 2))
  console.log('Sample present records (first 3):', JSON.stringify(present.slice(0, 3), null, 2))
}

main()
