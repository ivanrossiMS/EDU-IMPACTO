import { createClient } from '@supabase/supabase-js'
import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Load environment variables
const envPath = path.resolve(__dirname, '../.env.local')
if (fs.existsSync(envPath)) {
  const content = fs.readFileSync(envPath, 'utf8')
  content.split('\n').forEach(line => {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) return
    const index = trimmed.indexOf('=')
    if (index > 0) {
      const key = trimmed.slice(0, index).trim()
      const val = trimmed.slice(index + 1).trim().replace(/^['"]|['"]$/g, '')
      process.env[key] = val
    }
  })
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

const supabase = createClient(supabaseUrl, supabaseKey)

async function test() {
  const { data: students, error } = await supabase.from('alunos').select('id, nome, turma').limit(5)
  if (error) {
    console.error("Error:", error)
  } else {
    console.log("Sample students in DB:")
    console.log(JSON.stringify(students, null, 2))
  }

  const { data: turmas, error: tError } = await supabase.from('turmas').select('id, codigo, nome').limit(5)
  if (tError) {
    console.error("Turmas Error:", tError)
  } else {
    console.log("Sample turmas in DB:")
    console.log(JSON.stringify(turmas, null, 2))
  }
}

test()
