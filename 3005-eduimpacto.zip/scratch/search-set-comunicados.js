const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, '../app/agenda-digital/admin/comunicados/page.tsx');
const content = fs.readFileSync(filePath, 'utf8');

const lines = content.split('\n');
lines.forEach((line, idx) => {
  if (line.includes('setComunicados')) {
    console.log(`Line ${idx + 1}: ${line.trim()}`);
    // Print 5 lines after
    for (let i = 1; i <= 5; i++) {
      console.log(`  +${i}: ${lines[idx + i]}`);
    }
  }
});
