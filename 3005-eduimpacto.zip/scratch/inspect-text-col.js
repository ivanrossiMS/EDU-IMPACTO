const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  const { data, error } = await supabase
    .from('comunicados')
    .select('id, autor, texto, dados')
    .eq('id', 'AD-COM-NEW-1779551732873')
    .single();

  if (error) {
    console.error(error);
  } else {
    console.log("Top-level ID:", data.id);
    console.log("Top-level autor:", data.autor);
    console.log("Top-level texto length:", data.texto?.length);
    console.log("Top-level texto (first 500 chars):", data.texto?.substring(0, 500));
    console.log("Top-level dados.conteudo (first 500 chars):", data.dados?.conteudo?.substring(0, 500));
    console.log("Top-level dados.texto (first 500 chars):", data.dados?.texto?.substring(0, 500));
  }
}
run();
