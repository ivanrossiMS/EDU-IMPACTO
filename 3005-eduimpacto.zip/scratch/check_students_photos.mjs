import fs from 'fs';
import path from 'path';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';

async function queryStudents() {
  try {
    const res = await fetch(`${supabaseUrl}/rest/v1/alunos?select=id,nome,matricula,foto,status&limit=10`, {
      method: 'GET',
      headers: {
        'apikey': supabaseKey,
        'Authorization': `Bearer ${supabaseKey}`,
        'Content-Type': 'application/json'
      }
    });
    console.log('Status:', res.status);
    if (!res.ok) {
      console.log('Error body:', await res.text());
      return;
    }
    const data = await res.json();
    console.log('Total returned:', data.length);
    for (const student of data) {
      console.log(`Student: ${student.nome} | Matricula: ${student.matricula} | Status: ${student.status} | Has Photo: ${student.foto ? 'YES' : 'NO'} (${student.foto ? student.foto.length : 0} chars)`);
      if (student.foto) {
        console.log('  Photo prefix:', student.foto.substring(0, 100));
      }
    }
  } catch (err) {
    console.error('Error:', err);
  }
}

queryStudents();
