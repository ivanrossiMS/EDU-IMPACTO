const fs = require('fs');

const diff = fs.readFileSync('scratch/page_diff.diff', 'utf-8');
const lines = diff.split('\n');

lines.forEach((line, idx) => {
  if (line.includes('turmas') || line.includes('join')) {
    console.log(`${idx + 1}: ${line}`);
  }
});
