const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  const { data, error } = await supabase
    .from('comunicados')
    .select('id, autor, titulo, destino, created_at, dados')
    .eq('id', 'AD-COM-NEW-1779551732873')
    .single();

  if (error) {
    console.error(error);
  } else {
    console.log("Top-level autor:", data.autor);
    console.log("Top-level destino:", data.destino);
    console.log("Top-level dados.autor:", data.dados?.autor);
    console.log("Top-level dados.dados.autor:", data.dados?.dados?.autor);
    console.log("Top-level dados.turmas length:", data.dados?.turmas?.length);
    console.log("Top-level dados.dados.turmas length:", data.dados?.dados?.turmas?.length);
  }
}
run();
