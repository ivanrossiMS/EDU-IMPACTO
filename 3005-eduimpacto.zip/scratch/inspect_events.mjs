import { createClient } from '@supabase/supabase-js'
import dotenv from 'dotenv'
import path from 'path'

dotenv.config()

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

async function inspect() {
  const { data, error } = await supabase
    .from('portaria_eventos')
    .select('id, data_hora, payload_raw, user_id_equipamento, aluno_nome')
    .order('data_hora', { ascending: false })
    .limit(5)

  if (error) {
    console.error('Error fetching events:', error)
    return
  }

  console.log('Last 5 events:')
  data.forEach(e => {
    console.log(`ID: ${e.id}`)
    console.log(`data_hora (string in DB): ${e.data_hora}`)
    console.log(`user_id_equipamento: ${e.user_id_equipamento}`)
    console.log(`aluno_nome: ${e.aluno_nome}`)
    if (e.payload_raw) {
      const parsed = typeof e.payload_raw === 'string' ? JSON.parse(e.payload_raw) : e.payload_raw
      console.log(`payload_raw time/time_utc:`, parsed.time, parsed.time_utc)
    }
    console.log('---')
  })
}

inspect()
