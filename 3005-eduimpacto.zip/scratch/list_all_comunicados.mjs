import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

const envPath = path.resolve('.env.local');
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf8');
  envContent.split('\n').forEach(line => {
    const parts = line.split('=');
    if (parts.length >= 2) {
      const key = parts[0].trim();
      const val = parts.slice(1).join('=').trim().replace(/^['"]|['"]$/g, '');
      process.env[key] = val;
    }
  });
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

async function run() {
  const { data, error } = await supabase.from('comunicados').select('id, titulo, autor, destino, dados');
  if (error) {
    console.error("Error:", error);
  } else {
    console.log("Found", data.length, "comunicados:");
    data.forEach(c => {
      console.log(`- ID: ${c.id}`);
      console.log(`  Titulo: ${c.titulo}`);
      console.log(`  Autor: ${c.autor}`);
      console.log(`  Destino: ${c.destino}`);
      console.log(`  Length of autor: ${c.autor?.length}`);
    });
  }
}

run();
