const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://lrpwerkkqrjkcauofhph.supabase.co', 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl');
async function run() {
  const { data: alunos } = await supabase.from('alunos').select('*').ilike('nome', '%Alana Lemos%');
  console.log("Alunos:", alunos);
  if(alunos && alunos.length > 0) {
    const { data: links } = await supabase.from('aluno_responsavel').select('*').eq('aluno_id', alunos[0].id);
    console.log("Links:", links);
    const respIds = links.map(l => l.responsavel_id);
    const { data: resp } = await supabase.from('responsaveis').select('*').in('id', respIds);
    console.log("Responsaveis:", resp);
  }
}
run();
