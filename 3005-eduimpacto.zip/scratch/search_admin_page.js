const fs = require('fs');

const content = fs.readFileSync('app/agenda-digital/admin/comunicados/page.tsx', 'utf-8');
const lines = content.split('\n');

lines.forEach((line, idx) => {
  if (line.includes('turmas') || line.includes('join') || line.includes('selectedDest') || line.includes('destinatarios')) {
    console.log(`${idx + 1}: ${line.trim()}`);
  }
});
