const { execSync } = require('child_process');
const fs = require('fs');

try {
  const diff = execSync('git diff app/agenda-digital/admin/comunicados/page.tsx', { encoding: 'utf8' });
  console.log('Diff length:', diff.length);
  fs.writeFileSync('scratch/page_diff.diff', diff);
  console.log('Saved to scratch/page_diff.diff');
} catch (err) {
  console.error(err);
}
