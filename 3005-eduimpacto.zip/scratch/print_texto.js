require('dotenv').config({ path: '.env.local' });
const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

const client = createClient(supabaseUrl, supabaseServiceKey || supabaseAnonKey);

async function run() {
  const { data, error } = await client.from('comunicados').select('*').eq('id', 'AD-COM-NEW-1779551732873').single();
  if (error) {
    console.error(error);
  } else {
    fs.writeFileSync('scratch/texto_comunicado.html', data.texto || '');
    console.log("Written scratch/texto_comunicado.html");
  }
}

run();
