import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

// Inline .env.local loader
try {
  const envPath = path.resolve('.env.local');
  if (fs.existsSync(envPath)) {
    const envConfig = fs.readFileSync(envPath, 'utf8');
    envConfig.split('\n').forEach(line => {
      const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
      if (match) {
        const key = match[1];
        let value = match[2] || '';
        if (value.startsWith('"') && value.endsWith('"')) {
          value = value.substring(1, value.length - 1);
        } else if (value.startsWith("'") && value.endsWith("'")) {
          value = value.substring(1, value.length - 1);
        }
        process.env[key] = value.trim();
      }
    });
  }
} catch (e) {
  console.error("Could not load env file:", e);
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

async function inspect() {
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
  console.log(`Checking relationships updated since: ${oneHourAgo}`);

  const { data: recentLinks, error } = await supabase
    .from('aluno_responsavel')
    .select('id, aluno_id, responsavel_id, parentesco, updated_at, created_at')
    .gte('updated_at', oneHourAgo)
    .order('updated_at', { ascending: false });

  if (error) {
    console.error("Error fetching recent links:", error);
    return;
  }

  console.log(`Total relationships updated in the last hour: ${recentLinks?.length || 0}`);
  if (recentLinks && recentLinks.length > 0) {
    console.log("Timestamps present range:", recentLinks[recentLinks.length - 1].updated_at, "to", recentLinks[0].updated_at);
    console.log("Sample records:");
    console.log(JSON.stringify(recentLinks.slice(0, 10), null, 2));
  }
}

inspect();
