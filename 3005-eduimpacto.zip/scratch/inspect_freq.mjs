import fs from 'fs'

const envLocal = fs.readFileSync('.env.local', 'utf8')
const env = envLocal.split('\n').reduce((acc, line) => {
  const [k, ...v] = line.split('=')
  if (k && v.length > 0) acc[k.trim()] = v.join('=').trim().replace(/'/g, '').replace(/"/g, '')
  return acc
}, {})

const supabaseUrl = env['NEXT_PUBLIC_SUPABASE_URL']
const supabaseKey = env['SUPABASE_SERVICE_ROLE_KEY']

async function querySupabase(endpoint) {
  const url = `${supabaseUrl}/rest/v1/${endpoint}`
  const headers = {
    'apikey': supabaseKey,
    'Authorization': `Bearer ${supabaseKey}`,
    'Content-Type': 'application/json'
  }
  const res = await fetch(url, { headers })
  return res.json()
}

async function main() {
  const freqs = await querySupabase('frequencias?select=*&limit=10')
  console.log('Sample frequencias:', JSON.stringify(freqs, null, 2))
}

main()
