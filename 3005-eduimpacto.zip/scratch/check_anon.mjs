import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing anonymous env variables!");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function check() {
  const { data, error } = await supabase.from('comunicados').select('*');
  if (error) {
    console.error("Anonymous fetch failed with error:", error);
  } else {
    console.log(`Anonymous fetch succeeded: found ${data.length} records.`);
    console.log("Records:", data);
  }
}

check();
