const fs = require('fs');

const content = fs.readFileSync('app/agenda-digital/admin/comunicados/page.tsx', 'utf-8');
const lines = content.split('\n');

let insideMap = false;
let mapStart = 0;

lines.forEach((line, idx) => {
  if (line.includes('filtered.map(')) {
    insideMap = true;
    mapStart = idx;
  }
  if (insideMap) {
    if (idx - mapStart < 150) {
      console.log(`${idx + 1}: ${line}`);
    } else {
      insideMap = false;
    }
  }
});
