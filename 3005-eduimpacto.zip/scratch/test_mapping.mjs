const mapping = {
  "Parentesco 1": "resp_parentesco",
  "Parentesco 2": "resp_parentesco"
};

const headers = ["ID ALUNO", "Parentesco 1", "Parentesco 2"];
const row = ["5351", "Pai", ""];

const respData = {};

Object.entries(mapping).forEach(([column, target]) => {
  const colIdx = headers.indexOf(column);
  let value;
  if (colIdx !== -1) value = row[colIdx];

  if (value === undefined || value === null || value === '') return;

  if (target.startsWith('resp_')) {
    const field = target.replace('resp_', '');
    respData[field] = value;
  }
});

console.log("Resulting respData:", respData);
