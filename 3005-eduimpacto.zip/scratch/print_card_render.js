const fs = require('fs');
const content = fs.readFileSync('app/agenda-digital/admin/comunicados/page.tsx', 'utf-8');
const lines = content.split('\n');
for (let i = 310; i < 430; i++) {
  console.log(`${i + 1}: ${lines[i]}`);
}
