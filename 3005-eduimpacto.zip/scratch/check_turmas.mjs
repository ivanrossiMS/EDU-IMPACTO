import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';
const supabase = createClient(supabaseUrl, supabaseKey);

async function check() {
  const { data, error } = await supabase
    .from('turmas')
    .select('*')
    .limit(10);

  if (error) {
    console.error(error);
    return;
  }

  data.forEach(t => {
    console.log(`Turma ID: ${t.id}, Nome: ${t.nome}, Nivel: ${t.nivel_ensino}, Dados:`, t.dados);
  });
}

check();
