const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, '../app/agenda-digital/admin/comunicados/page.tsx');
const content = fs.readFileSync(filePath, 'utf8');

const lines = content.split('\n');
console.log("Lines with '+' or '.join' or template literals containing turmas/autor:");
lines.forEach((line, idx) => {
  const tr = line.trim();
  if (tr.includes('+') || tr.includes('.join') || (tr.includes('`') && (tr.includes('turma') || tr.includes('autor')))) {
    console.log(`${idx + 1}: ${tr}`);
  }
});
