

console.log('🚀 [Teste Webhook Template Sync] Simulando cadastro de face direta no iDFace...')

// Simular um evento push de inserção de template biométrico (face) na catraca
const payload = {
  object_changes: [
    {
      object: 'templates',
      type: 'inserted',
      values: {
        user_id: 5328,
        id: 9999
      }
    }
  ],
  device_id: '4408801109369742'
}

async function run() {
  try {
    const res = await fetch('http://localhost:3000/api/portaria/webhook', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    })

    console.log(`📡 Resposta do Webhook (Status: ${res.status}):`)
    const data = await res.json()
    console.log(JSON.stringify(data, null, 2))
    console.log('\n✅ Simulação enviada! O webhook deve processar o download da foto da catraca em background.')
  } catch (err) {
    console.error('❌ Falha ao simular webhook:', err.message)
  }
}

run()
