import { createClient } from '@supabase/supabase-js'
import * as fs from 'fs'
import * as path from 'path'

// Função simples para carregar .env.local sem depender de 'dotenv'
function loadEnv() {
  const envPath = path.resolve(process.cwd(), '.env.local')
  if (!fs.existsSync(envPath)) return
  
  const content = fs.readFileSync(envPath, 'utf8')
  content.split('\n').forEach(line => {
    const [key, ...valueParts] = line.split('=')
    if (key && valueParts.length > 0) {
      const value = valueParts.join('=').trim().replace(/^["']|["']$/g, '')
      process.env[key.trim()] = value
    }
  })
}

loadEnv()

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function clear() {
  console.log('Iniciando exclusão de todas as turmas...')
  
  const { count, error: countError } = await supabase
    .from('turmas')
    .select('*', { count: 'exact', head: true })

  if (countError) {
    console.error('Erro ao contar turmas:', countError.message)
    return
  }

  if (count === 0) {
    console.log('Nenhuma turma encontrada para excluir.')
    return
  }

  console.log(`Encontradas ${count} turmas. Tentando excluir...`)

  const { error } = await supabase.from('turmas').delete().neq('id', '')
  
  if (error) {
    if (error.code === '23503') {
      console.error('ERRO DE INTEGRIDADE: Existem registros vinculados (ex: alunos) que impedem a exclusão das turmas.')
      console.error('Detalhes:', error.message)
    } else {
      console.error('Erro ao excluir:', error.message)
    }
  } else {
    console.log('Todas as turmas foram excluídas com sucesso!')
  }
}

clear()
