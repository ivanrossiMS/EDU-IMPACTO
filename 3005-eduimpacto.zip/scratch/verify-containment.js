const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !serviceRoleKey) {
  console.error("Missing environment variables!");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, serviceRoleKey);

async function run() {
  const turmaId = '6º ANO B - VESPERTINO';
  
  const conditions = [`destino.eq."todos"`];
  conditions.push(`dados->turmas.cs.["${turmaId}"]`);
  
  console.log("Querying Supabase with conditions:", conditions);
  const { data, error } = await supabase
    .from('comunicados')
    .select('*')
    .or(conditions.join(','));

  if (error) {
    console.error("Query error:", error);
    return;
  }

  console.log(`Found ${data.length} matching announcements.`);
  data.forEach(c => {
    console.log(`- [${c.id}] ${c.titulo}`);
  });
}
run();
