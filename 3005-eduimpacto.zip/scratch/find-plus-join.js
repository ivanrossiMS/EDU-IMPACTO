const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, '../app/agenda-digital/admin/comunicados/page.tsx');
const content = fs.readFileSync(filePath, 'utf8');

const lines = content.split('\n');
lines.forEach((line, idx) => {
  if (line.includes('+') && line.includes('c.')) {
    console.log(`${idx + 1}: ${line.trim()}`);
  }
});
