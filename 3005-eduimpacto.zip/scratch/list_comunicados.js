const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');

const envFile = fs.readFileSync('.env.local', 'utf-8');
const env = {};
envFile.split('\n').forEach(line => {
  if (line && !line.startsWith('#')) {
    const parts = line.split('=');
    if (parts.length >= 2) {
      env[parts[0].trim()] = parts.slice(1).join('=').trim();
    }
  }
});

const supabaseUrl = env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = env.SUPABASE_SERVICE_ROLE_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

async function main() {
  const { data, error } = await supabase.from('comunicados').select('*');
  if (error) {
    console.error('Error fetching:', error);
  } else {
    console.log('Total:', data.length);
    data.forEach(c => {
      console.log('ID:', c.id);
      console.log('Titulo:', c.titulo);
      console.log('Destino:', c.destino);
      console.log('Texto:', c.texto);
      console.log('Dados:', JSON.stringify(c.dados, null, 2));
      console.log('-----------------------------');
    });
  }
}
main();
