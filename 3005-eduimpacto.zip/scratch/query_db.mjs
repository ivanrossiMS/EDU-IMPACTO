// Script de consulta temporário limpo com sucesso.
console.log("Cleanup complete.");
