import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';
const supabase = createClient(supabaseUrl, supabaseKey);

async function configureAll() {
  try {
    const { data: devices } = await supabase.from('portaria_dispositivos').select('*');
    console.log('Devices in DB:', devices.map(d => ({ id: d.id, nome: d.nome, ip: d.ip, porta: d.porta })));

    for (const d of devices) {
      if (!d.ip) continue;
      console.log(`\n--- Configuring Device: ${d.nome} (${d.ip}:${d.porta}) ---`);
      
      const loginUrl = `http://${d.ip}:${d.porta}/login.fcgi`;
      const login = d.configuracao?.login || 'admin';
      const password = d.configuracao?.password || 'admin';

      try {
        // 1. Login
        const loginRes = await fetch(loginUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ login, password })
        });
        const loginJson = await loginRes.json();
        const session = loginJson.session;
        if (!session) throw new Error('Failed to login and get session');

        // 2. Set Monitor Config
        const monitorParams = {
          hostname: '192.168.1.151',
          port: '3000',
          path: '/api/portaria/webhook',
          request_timeout: '5000'
        };
        console.log('Setting monitor configuration:', monitorParams);

        const setRes = await fetch(`http://${d.ip}:${d.porta}/set_configuration.fcgi?session=${session}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ monitor: monitorParams })
        });
        const setJson = await setRes.json();
        console.log('Set monitor status:', setRes.status, 'Response:', setJson);

        // 3. Let's query config back to confirm
        const getRes = await fetch(`http://${d.ip}:${d.porta}/get_configuration.fcgi?session=${session}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ monitor: ["path", "hostname", "port"] })
        });
        const getJson = await getRes.json();
        console.log('Confirmed monitor configuration on device:', JSON.stringify(getJson.monitor, null, 2));

      } catch (err) {
        console.error(`Failed to configure device ${d.nome}:`, err.message);
      }
    }
    console.log('\nAll devices configuration completed.');
  } catch (err) {
    console.error(err);
  }
}

configureAll();
