import fs from 'fs';
import path from 'path';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';

async function queryEventos() {
  try {
    const res = await fetch(`${supabaseUrl}/rest/v1/portaria_eventos?select=*`, {
      method: 'GET',
      headers: {
        'apikey': supabaseKey,
        'Authorization': `Bearer ${supabaseKey}`,
        'Content-Type': 'application/json'
      }
    });
    console.log(`\n--- PORTARIA EVENTOS ---`);
    console.log('Status:', res.status);
    if (!res.ok) {
      console.log('Error body:', await res.text());
      return;
    }
    const data = await res.json();
    console.log('Data:', JSON.stringify(data, null, 2));
  } catch (err) {
    console.error(`Error querying portaria_eventos:`, err);
  }
}

async function run() {
  await queryEventos();
}

run();
