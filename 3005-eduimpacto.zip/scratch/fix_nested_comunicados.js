const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !serviceRoleKey) {
  console.error("Missing environment variables!");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, serviceRoleKey);

function flattenDados(obj) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return obj;
  let result = { ...obj };
  while (result.dados && typeof result.dados === 'object' && !Array.isArray(result.dados)) {
    const inner = result.dados;
    delete result.dados;
    result = { ...result, ...inner };
  }
  return result;
}

async function run() {
  console.log("Fetching all rows from 'comunicados' table...");
  const { data, error } = await supabase.from('comunicados').select('*');
  if (error) {
    console.error("Error fetching rows:", error);
    return;
  }

  console.log(`Found ${data.length} rows.`);

  for (const row of data) {
    console.log(`Processing row ID: ${row.id}...`);
    
    // Flatten the dados column
    const flatDados = flattenDados(row.dados || {});
    
    // Update the row in the database
    const { error: updateError } = await supabase
      .from('comunicados')
      .update({ dados: flatDados, updated_at: new Date().toISOString() })
      .eq('id', row.id);
      
    if (updateError) {
      console.error(`Error updating row ${row.id}:`, updateError);
    } else {
      console.log(`Successfully flattened and updated row ${row.id}.`);
    }
  }
  
  console.log("Migration complete!");
}

run();
