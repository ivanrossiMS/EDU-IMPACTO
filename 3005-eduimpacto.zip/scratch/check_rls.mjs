import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing service role env variables!");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function checkRLS() {
  const { data, error } = await supabase.rpc('execute_sql_query', {
    sql_string: "SELECT * FROM pg_policies WHERE tablename = 'comunicados'"
  });
  
  if (error) {
    // If execute_sql_query function doesn't exist, we'll run a select query instead
    console.log("Could not run PG policies query directly via RPC:", error.message);
    console.log("Let's try standard direct query to check RLS status of table");
  } else {
    console.log("RLS Policies for 'comunicados' table:");
    console.log(JSON.stringify(data, null, 2));
  }
  
  // Let's also check table structure and check if RLS is enabled on 'comunicados'
  const { data: tableInfo, error: tableError } = await supabase.rpc('execute_sql_query', {
    sql_string: "SELECT relname, relrowsecurity FROM pg_class WHERE relname = 'comunicados'"
  });
  if (!tableError && tableInfo) {
    console.log("Table RLS Info:", tableInfo);
  }
}

checkRLS();
