const fs = require('fs');

const envFile = fs.readFileSync('.env.local', 'utf-8');
const env = {};
envFile.split('\n').forEach(line => {
  if (line && !line.startsWith('#')) {
    const parts = line.split('=');
    if (parts.length >= 2) {
      env[parts[0].trim()] = parts.slice(1).join('=').trim();
    }
  }
});

const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(env.NEXT_PUBLIC_SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

async function main() {
  const { data: c, error } = await supabase.from('comunicados').select('*').eq('id', 'AD-COM-NEW-1779551732873').single();
  if (error) {
    console.error(error);
  } else {
    console.log('Contains "Ivan Rossi":', c.texto.includes('Ivan Rossi'));
    console.log('Contains "MATUTINO":', c.texto.includes('MATUTINO'));
    console.log('Contains "1º ANO D":', c.texto.includes('1º ANO D'));
    console.log('Contains "Cartagena":', c.texto.includes('Cartagena'));
    console.log('Contains "Montevidéu":', c.texto.includes('Montevidéu'));
    console.log('--- Full c.texto length:', c.texto.length);
    console.log(c.texto);
  }
}
main();
