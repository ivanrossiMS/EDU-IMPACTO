const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  const { data, error } = await supabase
    .from('comunicados')
    .select('*')
    .eq('id', 'AD-COM-NEW-1779551732873')
    .single();

  if (error) {
    console.error(error);
    return;
  }

  // Print all top-level keys and values (except long content)
  console.log("--- Top-level columns ---");
  for (const [key, value] of Object.entries(data)) {
    if (key === 'texto') {
      console.log(`${key}: (length ${value?.length}) ${value?.substring(0, 100)}...`);
    } else if (key === 'dados') {
      console.log(`${key}: JSON object with keys [${Object.keys(value || {})}]`);
    } else {
      console.log(`${key}:`, value);
    }
  }

  // Print keys and values of the outer 'dados' object
  console.log("\n--- dados columns ---");
  const dados = data.dados || {};
  for (const [key, value] of Object.entries(dados)) {
    if (key === 'conteudo') {
      console.log(`${key}: (length ${value?.length}) ${value?.substring(0, 100)}...`);
    } else if (key === 'dados') {
      console.log(`${key}: JSON object with keys [${Object.keys(value || {})}]`);
    } else if (key === 'turmas' || key === 'alunosIds' || key === 'anexos') {
      console.log(`${key}: Array length ${value?.length}`);
    } else {
      console.log(`${key}:`, value);
    }
  }

  // Print keys and values of the inner 'dados.dados' object if it exists
  if (dados.dados) {
    console.log("\n--- dados.dados columns ---");
    const innerDados = dados.dados;
    for (const [key, value] of Object.entries(innerDados)) {
      if (key === 'conteudo') {
        console.log(`${key}: (length ${value?.length}) ${value?.substring(0, 100)}...`);
      } else if (key === 'turmas' || key === 'alunosIds' || key === 'anexos') {
        console.log(`${key}: Array length ${value?.length}`, value);
      } else {
        console.log(`${key}:`, value);
      }
    }
  }
}
run();
