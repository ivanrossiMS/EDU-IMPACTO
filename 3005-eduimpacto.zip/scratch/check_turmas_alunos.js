const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');

const envFile = fs.readFileSync('.env.local', 'utf-8');
const env = {};
envFile.split('\n').forEach(line => {
  if (line && !line.startsWith('#')) {
    const parts = line.split('=');
    if (parts.length >= 2) {
      env[parts[0].trim()] = parts.slice(1).join('=').trim();
    }
  }
});

const supabaseUrl = env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = env.SUPABASE_SERVICE_ROLE_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

async function main() {
  const { data: turmas, error: tErr } = await supabase.from('turmas').select('*');
  const { data: alunos, error: aErr } = await supabase.from('alunos').select('*').limit(5);
  
  if (tErr) console.error('Turmas error:', tErr);
  else {
    console.log('Turmas (first 5):');
    turmas.slice(0, 5).forEach(t => console.log(`- ID: ${t.id}, Codigo: ${t.codigo}, Nome: ${t.nome}`));
  }
  
  if (aErr) console.error('Alunos error:', aErr);
  else {
    console.log('Alunos (first 5):');
    alunos.forEach(a => console.log(`- ID: ${a.id}, Nome: ${a.nome}, Turma: ${a.turma}`));
  }
}
main();
