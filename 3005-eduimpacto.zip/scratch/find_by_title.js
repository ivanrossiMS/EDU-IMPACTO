const fs = require('fs');

const envFile = fs.readFileSync('.env.local', 'utf-8');
const env = {};
envFile.split('\n').forEach(line => {
  if (line && !line.startsWith('#')) {
    const parts = line.split('=');
    if (parts.length >= 2) {
      env[parts[0].trim()] = parts.slice(1).join('=').trim();
    }
  }
});

const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(env.NEXT_PUBLIC_SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

async function main() {
  const { data, error } = await supabase.from('comunicados').select('*').ilike('titulo', '%Cartagena%');
  if (error) {
    console.error(error);
  } else {
    console.log('Found:', data.length);
    data.forEach(c => {
      console.log('ID:', c.id);
      console.log('Title:', c.titulo);
      console.log('Texto:', c.texto);
      console.log('Dados:', JSON.stringify(c.dados, null, 2));
      console.log('------------------------');
    });
  }
}
main();
