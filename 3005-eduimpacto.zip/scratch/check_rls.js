const { createClient } = require('@supabase/supabase-js');
const anonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxycHdlcmtrcXJqa2NhdW9maHBoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU0MDAzMjYsImV4cCI6MjA5MDk3NjMyNn0.1-_0vMiLn0Y9piS90150Ur7qx8ic1Kz64RuhiaVGLhg';
const supabase = createClient('https://lrpwerkkqrjkcauofhph.supabase.co', anonKey);
async function run() {
  // Check what policies exist for aluno_responsavel
  const { data: a, error: e1 } = await supabase.from('aluno_responsavel').select('count').limit(0);
  console.log('aluno_responsavel count:', a, 'err:', e1?.message);
  const { data: b, error: e2 } = await supabase.from('responsaveis').select('count').limit(0);
  console.log('responsaveis count:', b, 'err:', e2?.message);
  const { data: c, error: e3 } = await supabase.from('alunos').select('count').limit(0);
  console.log('alunos count:', c, 'err:', e3?.message);
}
run();
