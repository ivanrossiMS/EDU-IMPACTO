const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  const { data, error } = await supabase.rpc('get_tables');
  if (error) {
    // Fallback: query from pg_catalog if rpc doesn't exist
    const { data: data2, error: error2 } = await supabase.from('pg_tables').select('tablename').eq('schemaname', 'public');
    if (error2) {
      // Let's run a query to information_schema via a standard query or select from a known table
      const { data: data3, error: error3 } = await supabase.rpc('execute_sql', { sql_query: "SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public'" });
      if (error3) {
        console.error("Could not fetch tables:", error3);
      } else {
        console.log("Tables from execute_sql:", data3);
      }
    } else {
      console.log("Tables:", data2);
    }
  } else {
    console.log("Tables:", data);
  }
}
run();
