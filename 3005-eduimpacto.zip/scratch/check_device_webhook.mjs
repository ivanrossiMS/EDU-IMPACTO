import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';
const supabase = createClient(supabaseUrl, supabaseKey);

async function checkDevice() {
  try {
    const { data: devices } = await supabase.from('portaria_dispositivos').select('*');
    console.log('Devices in DB:', devices.map(d => ({ id: d.id, nome: d.nome, ip: d.ip, porta: d.porta })));

    for (const d of devices) {
      if (!d.ip) continue;
      console.log(`\nConnecting to device: ${d.nome} (${d.ip}:${d.porta})...`);
      
      const loginUrl = `http://${d.ip}:${d.porta}/login.fcgi`;
      const login = d.configuracao?.login || 'admin';
      const password = d.configuracao?.password || 'admin';

      try {
        // 1. Login
        const loginRes = await fetch(loginUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ login, password })
        });
        
        if (!loginRes.ok) {
          throw new Error(`Login failed with status ${loginRes.status}`);
        }
        
        const loginJson = await loginRes.json();
        const session = loginJson.session;
        if (!session) {
          throw new Error('No session token returned');
        }
        console.log('Session token acquired successfully.');

        // 2. Get device info
        const infoRes = await fetch(`http://${d.ip}:${d.porta}/system_information.fcgi?session=${session}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({})
        });
        const infoJson = await infoRes.json();
        console.log('System Information:', infoJson);

        // 3. Get monitor config
        const configRes = await fetch(`http://${d.ip}:${d.porta}/get_configuration.fcgi?session=${session}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ keys: ['monitor'] })
        });
        const configJson = await configRes.json();
        console.log('Monitor Config:', JSON.stringify(configJson, null, 2));

      } catch (err) {
        console.error(`Failed to communicate with device ${d.nome}:`, err.message);
      }
    }
  } catch (err) {
    console.error(err);
  }
}

checkDevice();
