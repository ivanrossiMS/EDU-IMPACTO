import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';
const supabase = createClient(supabaseUrl, supabaseKey);

async function check() {
  const { data, error } = await supabase
    .from('frequencias')
    .select('*')
    .limit(30);

  if (error) {
    console.error(error);
    return;
  }

  console.log('Total records:', data.length);
  data.forEach(f => {
    console.log('Record:', {
      id: f.id,
      aluno_id: f.aluno_id,
      turma_id: f.turma_id,
      data: f.data,
      presente: f.presente,
      justificativa: f.justificativa,
      dados: f.dados
    });
  });
}

check();
