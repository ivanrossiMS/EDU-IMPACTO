const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');

const envFile = fs.readFileSync('.env.local', 'utf-8');
const env = {};
envFile.split('\n').forEach(line => {
  if (line && !line.startsWith('#')) {
    const parts = line.split('=');
    if (parts.length >= 2) {
      env[parts[0].trim()] = parts.slice(1).join('=').trim();
    }
  }
});

const supabase = createClient(env.NEXT_PUBLIC_SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

async function main() {
  const { data: c, error } = await supabase.from('comunicados').select('*').eq('id', 'AD-COM-NEW-1779551732873').single();
  if (error) console.error(error);
  else {
    console.log('--- DB ROW ---');
    console.log('ID:', c.id);
    console.log('autor (top level):', JSON.stringify(c.autor));
    console.log('destino (top level):', JSON.stringify(c.destino));
    console.log('dados.autor:', JSON.stringify(c.dados?.autor));
    console.log('dados.destino:', JSON.stringify(c.dados?.destino));
    console.log('dados.turmas count:', c.dados?.turmas?.length);
    console.log('dados.turmas:', JSON.stringify(c.dados?.turmas));
  }
}
main();
