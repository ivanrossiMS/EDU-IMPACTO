const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://lrpwerkkqrjkcauofhph.supabase.co', 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl');
async function run() {
    const { data: resp } = await supabase.from('responsaveis').select('*').in('id', ['216673', '216672']);
    console.log("Responsaveis:", resp);
}
run();
