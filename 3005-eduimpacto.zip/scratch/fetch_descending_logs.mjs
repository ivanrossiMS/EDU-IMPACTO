import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';
const supabase = createClient(supabaseUrl, supabaseKey);

async function checkLogs() {
  try {
    const { data: devices } = await supabase.from('portaria_dispositivos').select('*');
    for (const d of devices) {
      if (!d.ip) continue;
      console.log(`\nConnecting to device: ${d.nome} (${d.ip}:${d.porta})...`);
      
      const loginUrl = `http://${d.ip}:${d.porta}/login.fcgi`;
      const login = d.configuracao?.login || 'admin';
      const password = d.configuracao?.password || 'admin';

      try {
        const loginRes = await fetch(loginUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ login, password })
        });
        const loginJson = await loginRes.json();
        const session = loginJson.session;
        if (!session) throw new Error('No session');

        // Load access logs from the device descending
        const logsRes = await fetch(`http://${d.ip}:${d.porta}/load_objects.fcgi?session=${session}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            object: 'access_logs',
            limit: 20,
            order: ["time", "descending"]
          })
        });
        const logsJson = await logsRes.json();
        console.log(`Latest 20 Access Logs (Sorted Descending) on ${d.nome}:`);
        if (logsJson.access_logs) {
          const logs = logsJson.access_logs.map(l => ({
            id: l.id,
            time: new Date(l.time * 1000).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }),
            user_id: l.user_id,
            event: l.event
          }));
          console.log(JSON.stringify(logs, null, 2));
        } else {
          console.log(JSON.stringify(logsJson, null, 2));
        }

      } catch (err) {
        console.error(`Failed to communicate with device ${d.nome}:`, err.message);
      }
    }
  } catch (err) {
    console.error(err);
  }
}

checkLogs();
