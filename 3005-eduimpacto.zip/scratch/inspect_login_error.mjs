import { createClient } from '@supabase/supabase-js'
import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Carregar variáveis de ambiente
const envPath = path.resolve(__dirname, '../.env.local')
if (fs.existsSync(envPath)) {
  const content = fs.readFileSync(envPath, 'utf8')
  content.split('\n').forEach(line => {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) return
    const index = trimmed.indexOf('=')
    if (index > 0) {
      const key = trimmed.slice(0, index).trim()
      const val = trimmed.slice(index + 1).trim().replace(/^['"]|['"]$/g, '')
      process.env[key] = val
    }
  })
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

const supabase = createClient(supabaseUrl, supabaseKey)

async function inspect() {
  console.log("⚡ Buscando um aluno de exemplo para ver as colunas...")
  const { data: alunos, error: errAlunos } = await supabase
    .from('alunos')
    .select('*')
    .limit(1)
  
  if (errAlunos) console.error("Erro alunos:", errAlunos)
  else {
     console.log("Aluno encontrado:", alunos)
     if (alunos && alunos.length > 0) {
        console.log("Colunas da tabela alunos:", Object.keys(alunos[0]))
     }
  }

  console.log("\n⚡ Buscando um responsável de exemplo para ver as colunas...")
  const { data: resps, error: errResps } = await supabase
    .from('responsaveis')
    .select('*')
    .limit(1)
  
  if (errResps) console.error("Erro responsáveis:", errResps)
  else {
     console.log("Responsável encontrado:", resps)
     if (resps && resps.length > 0) {
        console.log("Colunas da tabela responsaveis:", Object.keys(resps[0]))
     }
  }

  console.log("\n⚡ Buscando usuários do Supabase Auth...")
  const { data: authUsers, error: errAuth } = await supabase.auth.admin.listUsers({ page: 1, perPage: 1000 })
  if (errAuth) console.error("Erro auth:", errAuth)
  else {
    console.log(`Total de usuários Auth: ${authUsers?.users?.length || 0}`)
    console.log("Amostra de usuários Auth (e-mail, metadata):", authUsers?.users?.slice(0, 15).map(u => ({
      id: u.id,
      email: u.email,
      last_sign_in: u.last_sign_in_at,
      metadata: u.user_metadata
    })))
  }

  // Verificar se há responsáveis com permissão mas que não conseguem login
  if (resps && resps.length > 0) {
     const ids = resps.map(r => r.id)
     const { data: links } = await supabase
       .from('aluno_responsavel')
       .select('responsavel_id, resp_financeiro, resp_pedagogico')
       .in('responsavel_id', ids)
     
     console.log("\n⚡ Vínculos dos responsáveis recentes:", links)
  }
}

inspect()
