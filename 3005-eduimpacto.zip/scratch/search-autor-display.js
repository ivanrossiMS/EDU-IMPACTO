const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, '../app/agenda-digital/admin/comunicados/page.tsx');
const content = fs.readFileSync(filePath, 'utf8');

const lines = content.split('\n');
lines.forEach((line, idx) => {
  if (line.includes('autor') && line.includes('{')) {
    console.log(`Line ${idx + 1}: ${line.trim()}`);
    console.log("Context:");
    for (let i = -2; i <= 2; i++) {
      console.log(`  ${idx + 1 + i}: ${lines[idx + i]}`);
    }
    console.log("");
  }
});
