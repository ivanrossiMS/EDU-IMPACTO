const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  console.log("Checking profiles/users for 'Ivan Rossi'...");
  
  // Try querying from standard user tables
  const tables = ['usuarios', 'colaboradores', 'alunos', 'responsaveis'];
  for (const table of tables) {
    try {
      const { data, error } = await supabase
        .from(table)
        .select('*')
        .or('nome.ilike.%Ivan Rossi%');
      
      if (error) {
        console.log(`Table ${table} error:`, error.message);
      } else if (data && data.length > 0) {
        console.log(`\nFound ${data.length} matches in table "${table}":`);
        data.forEach(d => {
          console.log(`ID: ${d.id}, Nome: "${d.nome}", Perfil/Role: "${d.perfil || d.cargo || d.tipo}"`);
        });
      }
    } catch(e) {
      console.log(`Table ${table} catch error:`, e.message);
    }
  }
}
run();
