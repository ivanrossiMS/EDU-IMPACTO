const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  const { data: links } = await supabase.from('aluno_responsavel').select('*').eq('aluno_id', '5358');
  const respIds = links.map(l => l.responsavel_id);
  console.log('respIds:', respIds);

  // String array query
  const { data: res1, error: err1 } = await supabase.from('responsaveis').select('id').in('id', respIds);
  console.log('Query with strings:', res1, 'Error:', err1);

  // Number array query
  const { data: res2, error: err2 } = await supabase.from('responsaveis').select('id').in('id', respIds.map(Number));
  console.log('Query with numbers:', res2, 'Error:', err2);
}
run();
