async function testWebhook() {
  try {
    const payload = {
      event: 7, // Identified user
      user_id: 5324, // João Eduardo Casotti Queirós
      time: Math.floor(Date.now() / 1000),
      device_id: 4408801109369550, // Portaria PRINCIPAL -INF serial
    };

    console.log('Sending mock webhook payload to http://192.168.1.151:3000/api/portaria/webhook ...');
    const res = await fetch('http://192.168.1.151:3000/api/portaria/webhook', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-real-ip': '192.168.1.98' // Mock device IP
      },
      body: JSON.stringify(payload)
    });

    console.log('Response Status:', res.status);
    const json = await res.json();
    console.log('Response JSON:', json);
  } catch (err) {
    console.error(err);
  }
}

testWebhook();
