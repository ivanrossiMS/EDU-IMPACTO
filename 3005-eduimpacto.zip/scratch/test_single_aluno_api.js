const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://lrpwerkkqrjkcauofhph.supabase.co', 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl');
async function run() {
  // Simulate exactly what the new /api/alunos/[id] route will do
  const id = '5281'; // Alana Sarah's id
  const { data: student } = await supabase.from('alunos').select('*').eq('id', id).single();
  
  const studentRefs = [
    student.id,
    student.matricula,
    student.dados?.codigo,
    student.matricula ? String(student.matricula) : null,
    student.dados?.codigo ? String(student.dados?.codigo) : null,
  ].filter(Boolean);
  
  const { data: links } = await supabase.from('aluno_responsavel').select('*').in('aluno_id', studentRefs);
  const respIds = links.map(l => l.responsavel_id).filter(Boolean);
  const { data: respData } = await supabase.from('responsaveis').select('*').in('id', respIds);
  
  const linkedResponsaveis = links.filter(l => studentRefs.includes(l.aluno_id)).map(l => {
    const resp = respData.find(r => r.id === l.responsavel_id) || {};
    return { ...resp, parentesco: l.parentesco, isFinanceiro: l.resp_financeiro, isPedagogico: l.resp_pedagogico };
  }).filter(r => r.id);
  
  console.log("Final responsaveis for Alana Sarah:", JSON.stringify(linkedResponsaveis.map(r => ({ nome: r.nome, isFinanceiro: r.isFinanceiro, isPedagogico: r.isPedagogico, parentesco: r.parentesco })), null, 2));
}
run();
