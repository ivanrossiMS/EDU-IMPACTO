const fs = require('fs');

const envFile = fs.readFileSync('.env.local', 'utf-8');
const env = {};
envFile.split('\n').forEach(line => {
  if (line && !line.startsWith('#')) {
    const parts = line.split('=');
    if (parts.length >= 2) {
      env[parts[0].trim()] = parts.slice(1).join('=').trim();
    }
  }
});

const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(env.NEXT_PUBLIC_SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

async function main() {
  const { data, error } = await supabase.from('comunicados').select('*');
  if (error) {
    console.error(error);
  } else {
    data.forEach(c => {
      console.log(`ID: ${c.id}`);
      console.log(`Title: ${c.titulo}`);
      console.log(`Texto contains "Ivan Rossi":`, c.texto?.includes('Ivan Rossi'));
      console.log(`Texto contains "MATUTINO":`, c.texto?.includes('MATUTINO'));
      console.log(`Dados->conteudo contains "Ivan Rossi":`, c.dados?.conteudo?.includes('Ivan Rossi'));
      console.log(`Dados->conteudo contains "MATUTINO":`, c.dados?.conteudo?.includes('MATUTINO'));
      console.log('------------------------------------');
    });
  }
}
main();
