require('dotenv').config({ path: '.env.local' });
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

const client = createClient(supabaseUrl, supabaseServiceKey || supabaseAnonKey);

async function run() {
  const { data, error } = await client.from('comunicados').select('*');
  if (error) {
    console.error(error);
  } else {
    console.log("Total records:", data.length);
    for (const r of data) {
      console.log("--------------------------------");
      console.log("ID:", r.id);
      console.log("TITULO:", r.titulo);
      console.log("AUTOR:", r.autor);
      console.log("DESTINO:", r.destino);
      console.log("TURMAS IN DADOS:", r.dados?.turmas ? r.dados.turmas.length : 0);
      console.log("ALUNOS IN DADOS:", r.dados?.alunosIds ? r.dados.alunosIds.length : 0);
      console.log("TURMAS IN DADOS DETAIL:", r.dados?.turmas);
      console.log("ALUNOS IN DADOS DETAIL:", r.dados?.alunosIds);
    }
  }
}

run();
