const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://lrpwerkkqrjkcauofhph.supabase.co', 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl');
async function run() {
  const { data: links } = await supabase.from('aluno_responsavel').select('*').limit(5);
  console.log("Links:");
  links.forEach(l => console.log(l.aluno_id));
  
  const { data: alunos } = await supabase.from('alunos').select('id, matricula, dados').limit(5);
  console.log("Alunos:");
  alunos.forEach(a => console.log(a.id, a.matricula, a.dados?.codigo));
}
run();
