const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  console.log("Searching all tables for 'Ivan Rossi'...");
  
  // Let's query information_schema.tables to find all user-defined tables in public schema
  const { data: tablesData, error: tablesError } = await supabase.from('comunicados').select('id').limit(1); // just a test
  
  // Since we cannot run raw SQL directly without an RPC, let's try some common table names:
  const commonTables = [
    'perfis', 'profiles', 'usuarios', 'colaboradores', 'alunos', 'responsaveis', 
    'colaborador', 'usuario', 'funcionarios', 'funcionario', 'auth_users', 
    'user_profiles', 'configuracoes'
  ];
  
  for (const table of commonTables) {
    try {
      const { data, error } = await supabase.from(table).select('*').limit(10);
      if (error) {
        // Table doesn't exist or error
        continue;
      }
      
      // Search in data
      const jsonStr = JSON.stringify(data);
      if (jsonStr.toLowerCase().includes('rossi')) {
        console.log(`\nFound match in table "${table}":`);
        data.forEach(row => {
          if (JSON.stringify(row).toLowerCase().includes('rossi')) {
            console.log(JSON.stringify(row, null, 2));
          }
        });
      }
    } catch (e) {
      // Ignored
    }
  }
}
run();
