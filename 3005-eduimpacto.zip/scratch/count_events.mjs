import fs from 'fs';

const supabaseUrl = 'https://lrpwerkkqrjkcauofhph.supabase.co';
const supabaseKey = 'sb_secret_H_L4KmqOnjZRqCDPLg7cBw_lql_EEfl';

async function countEvents() {
  try {
    const res = await fetch(`${supabaseUrl}/rest/v1/portaria_eventos?select=id,data_hora,status,aluno_nome,dispositivo_nome`, {
      headers: {
        'apikey': supabaseKey,
        'Authorization': `Bearer ${supabaseKey}`
      }
    });
    const data = await res.json();
    console.log('Total events in database:', data.length);
    if (data.length > 0) {
      console.log('First 5 events:');
      console.log(JSON.stringify(data.slice(0, 5), null, 2));

      // Group by date
      const groups = {};
      data.forEach(e => {
        const date = e.data_hora.slice(0, 10);
        groups[date] = (groups[date] || 0) + 1;
      });
      console.log('Events by date:', groups);
    }
  } catch (err) {
    console.error(err);
  }
}

countEvents();
