import { createClient } from '@supabase/supabase-js'
import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Classe inline pura
class SimpleControliDClient {
  constructor(config) {
    const protocol = config.port === 80 ? 'http' : 'https'
    const cleanIp = config.ip.replace(/^https?:\/\//i, '')
    this.baseUrl = `${protocol}://${cleanIp}:${config.port}`
    this.login = config.login || 'admin'
    this.password = config.password || 'admin'
    this.session = null
  }

  async authenticate() {
    try {
      const res = await fetch(`${this.baseUrl}/login.fcgi`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ login: this.login, password: this.password }),
        signal: AbortSignal.timeout(8000),
      })
      if (!res.ok) throw new Error(`Login failed: ${res.status}`)
      const data = await res.json()
      this.session = data.session
      return data.session
    } catch (err) {
      throw new Error(`iDFace auth error: ${err.message}`)
    }
  }

  async request(endpoint, body = {}) {
    if (!this.session) await this.authenticate()

    const res = await fetch(`${this.baseUrl}/${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: `session=${this.session}`,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15000),
    })

    if (!res.ok) {
      if (res.status === 401) {
        await this.authenticate()
        const retry = await fetch(`${this.baseUrl}/${endpoint}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Cookie: `session=${this.session}`,
          },
          body: JSON.stringify(body),
          signal: AbortSignal.timeout(15000),
        })
        if (!retry.ok) throw new Error(`iDFace request failed: ${retry.status}`)
        return retry.json()
      }
      throw new Error(`iDFace request failed: ${res.status}`)
    }

    return res.json()
  }

  async getDeviceInfo() {
    try {
      const data = await this.request('system_information.fcgi', {})
      return {
        serial: data.serial || '',
        model: data.model || 'iDFace',
        firmware: data.firmware || '',
        online: true,
      }
    } catch (err) {
      return { serial: '', model: 'iDFace', firmware: '', online: false, error: err.message }
    }
  }

  async loadAccessLogs() {
    return this.request('load_objects.fcgi', {
      object: 'access_logs',
      limit: '10' // String limit!
    })
  }

  async loadUsers() {
    return this.request('load_objects.fcgi', {
      object: 'users',
    })
  }
}

async function checkDevice() {
  const ip = '192.168.1.75'
  const port = 80
  
  console.log(`🔌 Conectando ao iDFace em http://${ip}:${port}...`)
  
  const client = new SimpleControliDClient({
    ip,
    port,
    login: 'admin',
    password: 'Pass1081$'
  })

  try {
    const info = await client.getDeviceInfo()
    console.log("ℹ️ Informações do Dispositivo:", info)

    console.log("⚡ Buscando usuários cadastrados no hardware...")
    const usersRes = await client.loadUsers()
    console.log("✅ Usuários no Equipamento:")
    console.log(JSON.stringify(usersRes, null, 2))

    console.log("⚡ Buscando logs de acesso do hardware...")
    const logsRes = await client.loadAccessLogs()
    console.log("✅ Logs de Acesso no Equipamento (loadAccessLogs):")
    console.log(JSON.stringify(logsRes, null, 2))

  } catch (err) {
    console.error("❌ Falha na comunicação com o hardware iDFace:", err.message)
  }
}

checkDevice()
