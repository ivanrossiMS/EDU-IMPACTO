const fs = require('fs');

const diff = fs.readFileSync('scratch/page_diff.diff', 'utf-8');
const lines = diff.split('\n');

lines.forEach((line, idx) => {
  if (line.startsWith('-') && !line.startsWith('---') && (line.includes('turmas') || line.includes('join') || line.includes('autor') || line.includes('aluno'))) {
    console.log(`${idx + 1}: ${line}`);
  }
});
