const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  const { data, error } = await supabase
    .from('alunos')
    .select('id, nome, created_at, status, matricula')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching students:', error);
  } else {
    console.log(`Total students: ${data.length}`);
    console.log('Last 20 students created:');
    data.slice(0, 20).forEach(student => {
      console.log(`- ID/Matricula: ${student.matricula || student.id}, Name: ${student.nome}, CreatedAt: ${student.created_at}, Status: ${student.status}`);
    });
  }
}

run();
