const fs = require('fs');
const path = require('path');

function search(dir) {
  const list = fs.readdirSync(dir);
  for (const file of list) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      search(fullPath);
    } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
      const content = fs.readFileSync(fullPath, 'utf8');
      if (content.includes('.join') || content.includes('turmas') || content.includes('alunosIds')) {
        const lines = content.split('\n');
        lines.forEach((line, idx) => {
          if (line.includes('join') || line.includes('turmas') || line.includes('alunosIds')) {
            console.log(`${fullPath}:${idx + 1}: ${line.trim()}`);
          }
        });
      }
    }
  }
}

console.log("Searching in app/agenda-digital...");
search(path.resolve(__dirname, '../app/agenda-digital'));
console.log("Searching in components/agenda...");
search(path.resolve(__dirname, '../components/agenda'));
