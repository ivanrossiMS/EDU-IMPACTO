import fs from 'fs'
import path from 'path'

// Read env variables
const envLocal = fs.readFileSync('.env.local', 'utf8')
const env = envLocal.split('\n').reduce((acc, line) => {
  const [k, ...v] = line.split('=')
  if (k && v.length > 0) acc[k.trim()] = v.join('=').trim().replace(/'/g, '').replace(/"/g, '')
  return acc
}, {})

const supabaseUrl = env['NEXT_PUBLIC_SUPABASE_URL']
const supabaseKey = env['SUPABASE_SERVICE_ROLE_KEY']

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Supabase URL or Service Role Key missing in .env.local')
  process.exit(1)
}

function getTurmaSchedule(turma) {
  const seg = turma?.dados?.segmento || '';
  const nome = (turma?.nome || '').toLowerCase();
  
  if (seg === 'Ensino Médio' || nome.includes('médio') || nome.includes('série')) {
    return {
      segmento: 'Ensino Médio',
      tempos: [
        { id: '1', label: '1º tempo', horario: '7h - 7h50' },
        { id: '2', label: '2º tempo', horario: '7h50 - 8h40' },
        { id: '3', label: '3º tempo', horario: '8h55 - 9h45' },
        { id: '4', label: '4º tempo', horario: '9h45 - 10h35' },
        { id: '5', label: '5º tempo', horario: '10h50 - 11h40' },
        { id: '6', label: '6º tempo', horario: '11h40 - 12h30' },
      ]
    }
  }
  
  if (seg === 'Ensino Fundamental II' || nome.includes('fundamental ii') || nome.includes('fundamental 2') || /^[6-9]º/.test(nome)) {
    return {
      segmento: 'Ensino Fundamental II',
      tempos: [
        { id: '1', label: '1º tempo', horario: '7h - 7h50' },
        { id: '2', label: '2º tempo', horario: '7h50 - 8h40' },
        { id: '3', label: '3º tempo', horario: '8h40 - 9h30' },
        { id: '4', label: '4º tempo', horario: '9h50 - 10h40' },
        { id: '5', label: '5º tempo', horario: '10h40 - 11h30' },
      ]
    }
  }

  if (seg === 'Ensino Fundamental I' || nome.includes('fundamental i') || nome.includes('fundamental 1') || /^[1-5]º/.test(nome)) {
    return {
      segmento: 'Ensino Fundamental I',
      tempos: [
        { id: '1', label: '1º tempo', horario: '7h - 8h' },
        { id: '2', label: '2º tempo', horario: '8h - 9h' },
        { id: '3', label: '3º tempo', horario: '9h20 - 10h20' },
        { id: '4', label: '4º tempo', horario: '10h20 - 11h20' },
      ]
    }
  }

  if (seg === 'Educação Infantil' || nome.includes('infantil') || nome.includes('maternal') || nome.includes('jardim') || nome.includes('pre') || nome.includes('pré')) {
    return {
      segmento: 'Educação Infantil',
      tempos: [
        { id: '1', label: '1º tempo', horario: '7h - 8h' },
        { id: '2', label: '2º tempo', horario: '8h - 9h' },
        { id: '3', label: '3º tempo', horario: '9h - 10h' },
        { id: '4', label: '4º tempo', horario: '10h - 11h' },
      ]
    }
  }

  return {
    segmento: 'Ensino Fundamental I',
    tempos: [
      { id: '1', label: '1º tempo', horario: '7h - 8h' },
      { id: '2', label: '2º tempo', horario: '8h - 9h' },
      { id: '3', label: '3º tempo', horario: '9h20 - 10h20' },
      { id: '4', label: '4º tempo', horario: '10h20 - 11h20' },
    ]
  }
}

function calcularFrequenciaDia(tempos, segment) {
  const isInfantilOuFundI = segment === 'Educação Infantil' || segment === 'Ensino Fundamental I';
  const temposEfetivos = { ...tempos };
  
  if (isInfantilOuFundI) {
    if (tempos['1'] === 'F' && tempos['2'] === 'F') {
      Object.keys(temposEfetivos).forEach(k => {
        if (temposEfetivos[k] !== 'J') temposEfetivos[k] = 'F';
      });
    } else if (tempos['1'] === 'F') {
      const hasOtherF = Object.keys(tempos).some(k => k !== '1' && tempos[k] === 'F');
      if (!hasOtherF) {
        temposEfetivos['1'] = 'P';
      }
    }
    
    const statuses = Object.values(temposEfetivos);
    const temFalta = statuses.includes('F');
    const temJustificada = statuses.includes('J');
    
    const diaFalta = temFalta;
    const diaJustificado = !temFalta && temJustificada;
    
    return {
      presente: !diaFalta,
      justificativa: diaJustificado ? 'Justificada' : '',
      temposEfetivos
    };
  } else {
    if (tempos['1'] === 'F' && tempos['2'] === 'F') {
      Object.keys(temposEfetivos).forEach(k => {
        if (temposEfetivos[k] !== 'J') temposEfetivos[k] = 'F';
      });
    }
    const hasF = Object.values(temposEfetivos).includes('F');
    const hasJ = Object.values(temposEfetivos).includes('J');
    
    return {
      presente: !hasF,
      justificativa: (hasJ && !hasF) ? 'Justificada' : '',
      temposEfetivos
    };
  }
}

function getFirstPresentTempoIndex(arrivalMinutes, segment) {
  if (arrivalMinutes <= 7 * 60 + 15) return 0;
  if (arrivalMinutes <= 8 * 60 + 0) return 1;

  if (segment === 'Ensino Médio') {
    if (arrivalMinutes <= 9 * 60 + 5) return 2;
    if (arrivalMinutes <= 9 * 60 + 55) return 3;
    if (arrivalMinutes <= 11 * 60 + 0) return 4;
    return 5;
  }

  if (segment === 'Ensino Fundamental II') {
    if (arrivalMinutes <= 8 * 60 + 50) return 2;
    if (arrivalMinutes <= 10 * 60 + 0) return 3;
    return 4;
  }

  if (segment === 'Ensino Fundamental I') {
    if (arrivalMinutes <= 9 * 60 + 35) return 2;
    return 3;
  }

  if (segment === 'Educação Infantil') {
    if (arrivalMinutes <= 9 * 60 + 15) return 2;
    return 3;
  }

  if (arrivalMinutes <= 9 * 60 + 35) return 2;
  return 3;
}

// Request Helper
async function querySupabase(endpoint, options = {}) {
  const url = `${supabaseUrl}/rest/v1/${endpoint}`
  const headers = {
    'apikey': supabaseKey,
    'Authorization': `Bearer ${supabaseKey}`,
    'Content-Type': 'application/json',
    ...options.headers
  }
  const res = await fetch(url, { ...options, headers })
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Supabase query failed on ${endpoint}: ${res.status} - ${text}`)
  }
  const text = await res.text()
  if (!text) return {}
  try {
    return JSON.parse(text)
  } catch (e) {
    return { text }
  }
}

async function main() {
  const isDryRun = process.argv.includes('--apply') === false
  console.log(`🚀 [Sync Old Attendance] Starting... (Mode: ${isDryRun ? 'DRY-RUN - Preview only' : 'APPLY - Writing to DB'})`)

  // 1. Fetch Students
  console.log('Fetching active students...')
  const students = await querySupabase('alunos?select=id,nome,turma,turno&status=in.(matriculado,cursando,ativo,Cursando,Matriculado,Ativo)')
  console.log(`Fetched ${students.length} students.`)

  const studentMap = new Map()
  students.forEach(s => studentMap.set(s.id, s))

  // 2. Fetch Classes/Turmas
  console.log('Fetching turmas...')
  const turmas = await querySupabase('turmas?select=id,nome,dados')
  console.log(`Fetched ${turmas.length} turmas.`)

  const turmaMap = new Map()
  turmas.forEach(t => turmaMap.set(t.id, t))

  // 3. Fetch Success Entry Logs
  console.log('Fetching portaria entry events...')
  const events = await querySupabase('portaria_eventos?select=aluno_id,aluno_nome,data_hora&status=eq.sucesso&tipo=eq.entrada&order=data_hora.asc')
  console.log(`Fetched ${events.length} entry events.`)

  // Filter events that have valid aluno_id and where the student has a class (turma)
  const validEvents = events.filter(e => {
    if (!e.aluno_id) return false
    const student = studentMap.get(e.aluno_id)
    return !!student && !!student.turma
  })
  console.log(`Filtered to ${validEvents.length} events with resolved class structures.`)

  // 4. Group events by Student and Date (using UTC values to avoid double timezone offsets)
  const grouped = {} // key: `${aluno_id}_${date}` -> array of event dates
  const activeClassDays = new Set() // set of `turmaId_localDate`

  validEvents.forEach(e => {
    const student = studentMap.get(e.aluno_id)
    const dateObj = new Date(e.data_hora)
    
    const day = String(dateObj.getUTCDate()).padStart(2, '0')
    const month = String(dateObj.getUTCMonth() + 1).padStart(2, '0')
    const year = dateObj.getUTCFullYear()
    const localDate = `${year}-${month}-${day}`

    const key = `${e.aluno_id}_${localDate}`
    if (!grouped[key]) grouped[key] = []
    grouped[key].push(dateObj)

    activeClassDays.add(`${student.turma}_${localDate}`)
  })

  console.log(`Identified ${activeClassDays.size} active class-dates where the gate was used.`)

  // 5. Fetch existing frequencias to merge if needed
  console.log('Fetching existing frequencias...')
  const existingFreqs = await querySupabase('frequencias?select=id,dados,presente,justificativa')
  const existingFreqsMap = new Map()
  existingFreqs.forEach(f => existingFreqsMap.set(f.id, f))
  console.log(`Fetched ${existingFreqs.length} existing diary records.`)

  const rowsToUpsert = []

  // 6. Process every student in the active classes on the active dates
  for (const classDay of activeClassDays) {
    const [turmaId, localDate] = classDay.split('_')
    const turma = turmaMap.get(turmaId)
    if (!turma) continue

    const schedule = getTurmaSchedule(turma)

    // Find all students in this class
    const classStudents = students.filter(s => String(s.turma) === String(turmaId))

    for (const student of classStudents) {
      const key = `${student.id}_${localDate}`
      const dayEvents = grouped[key]

      const freqId = `FREQ-${student.id}-${localDate}`
      const existing = existingFreqsMap.get(freqId)

      let tempos = {}
      const existingTempos = existing?.dados?.tempos || existing?.tempos
      if (existingTempos && typeof existingTempos === 'object') {
        tempos = { ...existingTempos }
      }

      let localTimeStr = ''
      
      if (dayEvents && dayEvents.length > 0) {
        // Student entered through the gate!
        const earliestEvent = dayEvents.reduce((min, d) => d < min ? d : min, dayEvents[0])
        const localHour = earliestEvent.getUTCHours()
        const localMin = earliestEvent.getUTCMinutes()
        localTimeStr = `${String(localHour).padStart(2, '0')}:${String(localMin).padStart(2, '0')}:${String(earliestEvent.getUTCSeconds()).padStart(2, '0')}`
        const arrivalMinutes = localHour * 60 + localMin

        const firstPresentTempoIndex = getFirstPresentTempoIndex(arrivalMinutes, schedule.segmento)

        schedule.tempos.forEach((t, index) => {
          if (index >= firstPresentTempoIndex) {
            tempos[t.id] = 'P'
          } else {
            if (tempos[t.id] !== 'J') {
              tempos[t.id] = 'F'
            }
          }
        })
      } else {
        // Student DID NOT enter through the gate on an active day. Mark all non-justified as F!
        schedule.tempos.forEach(t => {
          if (tempos[t.id] !== 'J') {
            tempos[t.id] = 'F'
          }
        })
      }

      const calc = calcularFrequenciaDia(tempos, schedule.segmento)
      const currentYear = localDate.split('-')[0]
      const diarioId = `DIARIO-${student.turma}-${currentYear}`

      rowsToUpsert.push({
        id: freqId,
        aluno_id: student.id,
        turma_id: student.turma,
        data: localDate,
        presente: calc.presente,
        justificativa: calc.justificativa,
        dados: {
          tempos: calc.temposEfetivos,
          diarioId,
          anoLetivo: currentYear,
          registradoPor: 'Sincronização Histórica Catraca',
          horaRegistro: localTimeStr || null
        }
      })
    }
  }

  console.log(`Generated ${rowsToUpsert.length} update records (including absentees).`)

  if (isDryRun) {
    console.log('--- DRY RUN PREVIEW (First 10 records) ---')
    console.log(JSON.stringify(rowsToUpsert.slice(0, 10), null, 2))
    console.log('-----------------------------------------')
    console.log('💡 Run with `--apply` to commit these updates to the database.')
  } else {
    console.log('Sending updates to Supabase...')
    
    // Batch upsert in chunks of 100 to avoid request body size limitations
    const chunkSize = 100
    for (let i = 0; i < rowsToUpsert.length; i += chunkSize) {
      const chunk = rowsToUpsert.slice(i, i + chunkSize)
      await querySupabase('frequencias', {
        method: 'POST',
        headers: {
          'Prefer': 'resolution=merge-duplicates'
        },
        body: JSON.stringify(chunk)
      })
      console.log(`Upserted chunk ${Math.floor(i / chunkSize) + 1}/${Math.ceil(rowsToUpsert.length / chunkSize)} (${chunk.length} records).`)
    }
    console.log('✅ Synchronization completed successfully!')
  }
}

main().catch(err => {
  console.error('❌ Script failed:', err)
  process.exit(1)
})
