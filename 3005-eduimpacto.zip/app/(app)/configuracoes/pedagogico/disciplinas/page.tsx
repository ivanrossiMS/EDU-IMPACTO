'use client'
import { ConfigDisciplina, newId, useData } from '@/lib/dataContext'
import { useState, useMemo, useEffect } from 'react'
import { useApiQuery } from '@/hooks/useApi'
import { TableSkeleton } from '@/components/skeletons/TableSkeleton'
import { UpdatingIndicator } from '@/components/skeletons/States'
import { Plus, Edit2, Trash2, Check, BookOpen, Search, Download, Layers } from 'lucide-react'

const NIVEIS_OPTS = ['EI', 'EF1', 'EF2', 'EM', 'EJA']
const NIVEL_COLORS: Record<string, string> = { EI: '#ec4899', EF1: '#3b82f6', EF2: '#8b5cf6', EM: '#10b981', EJA: '#f59e0b' }
const TURNOS = ['Manhã', 'Tarde', 'Noite', 'Integral']

const BLANK: Omit<ConfigDisciplina, 'id' | 'createdAt'> = {
  codigo: '', nome: '', cargaHoraria: 2, niveisEnsino: ['EF1'], obrigatoria: true, situacao: 'ativa',
}

const PADROES_DISCIPLINAS = [
  { codigo: '1', nome: 'Língua Portuguesa', cargaHoraria: 4, niveisEnsino: ['EF1', 'EF2', 'EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '2', nome: 'Matemática', cargaHoraria: 4, niveisEnsino: ['EF1', 'EF2', 'EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '3', nome: 'História', cargaHoraria: 2, niveisEnsino: ['EF1', 'EF2', 'EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '4', nome: 'Geografia', cargaHoraria: 2, niveisEnsino: ['EF1', 'EF2', 'EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '5', nome: 'Ciências', cargaHoraria: 3, niveisEnsino: ['EF1', 'EF2', 'EI'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '6', nome: 'Biologia', cargaHoraria: 2, niveisEnsino: ['EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '7', nome: 'Física', cargaHoraria: 2, niveisEnsino: ['EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '8', nome: 'Química', cargaHoraria: 2, niveisEnsino: ['EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '9', nome: 'Educação Física', cargaHoraria: 2, niveisEnsino: ['EI', 'EF1', 'EF2', 'EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '10', nome: 'Artes', cargaHoraria: 1, niveisEnsino: ['EI', 'EF1', 'EF2', 'EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '11', nome: 'Língua Inglesa', cargaHoraria: 2, niveisEnsino: ['EF1', 'EF2', 'EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '12', nome: 'Ensino Religioso', cargaHoraria: 1, niveisEnsino: ['EF1', 'EF2'], obrigatoria: false, situacao: 'ativa' },
  { codigo: '13', nome: 'Filosofia', cargaHoraria: 1, niveisEnsino: ['EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '14', nome: 'Sociologia', cargaHoraria: 1, niveisEnsino: ['EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '15', nome: 'Redação', cargaHoraria: 1, niveisEnsino: ['EF2', 'EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '16', nome: 'Literatura', cargaHoraria: 1, niveisEnsino: ['EM', 'EJA'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '17', nome: 'Linguagens e Movimento', cargaHoraria: 4, niveisEnsino: ['EI'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '18', nome: 'Natureza e Sociedade', cargaHoraria: 4, niveisEnsino: ['EI'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '19', nome: 'Projeto de Vida', cargaHoraria: 1, niveisEnsino: ['EF2', 'EM'], obrigatoria: true, situacao: 'ativa' },
  { codigo: '20', nome: 'Empreendedorismo', cargaHoraria: 1, niveisEnsino: ['EM'], obrigatoria: false, situacao: 'ativa' },
  { codigo: '21', nome: 'Informática / Tecnologia', cargaHoraria: 1, niveisEnsino: ['EF1', 'EF2'], obrigatoria: false, situacao: 'ativa' },
  { codigo: '22', nome: 'Língua Espanhola', cargaHoraria: 1, niveisEnsino: ['EF2', 'EM'], obrigatoria: false, situacao: 'ativa' },
]

// Formatação auto-numérica para obedecer à regra do usuário
function gerarCodigoDisc(existentes: string[]): string {
  let i = 1
  let cod = String(i)
  while (existentes.includes(cod)) { i++; cod = String(i) }
  return cod
}

export default function DisciplinasPage() {
  const { data: rawConfig, isLoading: loadingDisc, isFetching } = useApiQuery<{ valor: ConfigDisciplina[] }>(['config-disciplinas'], '/api/configuracoes?chave=cfgDisciplinas')
  const { data: rawTurmas } = useApiQuery<{ data: any[] }>(['turmas'], '/api/turmas')
  
  const [cfgDisciplinas, setCfgDisciplinas] = useState<ConfigDisciplina[]>([])
  const turmas = rawTurmas?.data || []
  const isLoading = loadingDisc

  useEffect(() => {
    if (rawConfig?.valor) {
      setCfgDisciplinas(rawConfig.valor)
    }
  }, [rawConfig])

  const [search, setSearch] = useState('')
  const [filtroNivel, setFiltroNivel] = useState('todos')
  const [filtroSituacao, setFiltroSituacao] = useState<'todos' | 'ativa' | 'inativa'>('todos')
  const [filtroTipo, setFiltroTipo] = useState<'todos' | 'obrigatoria' | 'optativa'>('todos')
  const [filtroTurno, setFiltroTurno] = useState('todos')
  const [filtroTurma, setFiltroTurma] = useState('todos')
  const [form, setForm] = useState(BLANK)
  const [editId, setEditId] = useState<string | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [isProcessingBulk, setIsProcessingBulk] = useState(false)

  const codigosExistentes = cfgDisciplinas.map(d => d.codigo)
  const codigoPreview = editId ? form.codigo : gerarCodigoDisc(codigosExistentes)
  const turmasUnicas = useMemo(() => [...new Set(turmas.map(t => t.nome))].sort(), [turmas])

  const filtered = useMemo(() =>
    cfgDisciplinas.filter(d => {
      const matchSearch = search.trim().length < 3 || (d.nome.toLowerCase().includes(search.toLowerCase()) || d.codigo.includes(search.toUpperCase()))
      const matchNivel = filtroNivel === 'todos' || d.niveisEnsino.includes(filtroNivel)
      const matchSit = filtroSituacao === 'todos' || d.situacao === filtroSituacao
      const matchTipo = filtroTipo === 'todos' || (filtroTipo === 'obrigatoria' ? d.obrigatoria : !d.obrigatoria)
      return matchSearch && matchNivel && matchSit && matchTipo
    }), [cfgDisciplinas, search, filtroNivel, filtroSituacao, filtroTipo])

  const hasFilters = filtroNivel !== 'todos' || filtroSituacao !== 'todos' || filtroTipo !== 'todos' || filtroTurno !== 'todos' || filtroTurma !== 'todos' || !!search

  const ativas = cfgDisciplinas.filter(d => d.situacao === 'ativa').length
  const obrigatorias = cfgDisciplinas.filter(d => d.obrigatoria).length

  const openNew = () => { setEditId(null); setForm({ ...BLANK }); setShowForm(true) }
  const openEdit = (d: ConfigDisciplina) => { setEditId(d.id); setForm({ codigo: d.codigo, nome: d.nome, cargaHoraria: d.cargaHoraria, niveisEnsino: d.niveisEnsino, obrigatoria: d.obrigatoria, situacao: d.situacao }); setShowForm(true) }
  const handleDelete = (id: string) => {
    setCfgDisciplinas(prev => prev.filter(c => c.id !== id))
  }

  const toggleNivel = (n: string) =>
    setForm(prev => ({
      ...prev,
      niveisEnsino: prev.niveisEnsino.includes(n) ? prev.niveisEnsino.filter(x => x !== n) : [...prev.niveisEnsino, n]
    }))

  const handleSave = () => {
    if (!form.nome.trim()) return
    const codigo = editId ? form.codigo : gerarCodigoDisc(codigosExistentes)

    // Outer guard (uses closure state, works for normal clicks)
    if (!editId && cfgDisciplinas.some(d => d.nome.toLowerCase() === form.nome.trim().toLowerCase())) {
      alert('Já existe uma disciplina com este nome!')
      return
    }

    if (editId) {
      setCfgDisciplinas(prev => prev.map(c => c.id === editId ? { ...c, ...form, codigo } as ConfigDisciplina : c))
    } else {
      const novoId = newId('DS')
      setCfgDisciplinas(prev => {
        // Inner guard (uses real-time queued state, works against double-click race conditions)
        if (prev.some(d => d.nome.toLowerCase() === form.nome.trim().toLowerCase() || d.id === novoId)) return prev
        return [...prev, { ...form, id: novoId, codigo: gerarCodigoDisc(prev.map(p => p.codigo)), createdAt: new Date().toISOString() } as ConfigDisciplina]
      })
    }
    setShowForm(false)
  }

  const handleCarregarPadroes = async () => {
    setIsProcessingBulk(true)
    const existingCodes = new Set(cfgDisciplinas.map(p => p.codigo))
    const news = PADROES_DISCIPLINAS.filter(p => !existingCodes.has(p.codigo)).map(p => ({
      ...p, id: newId('DS'), createdAt: new Date().toISOString()
    } as ConfigDisciplina))

    if (news.length > 0) {
      // Pequeno timeout visual para dar impressao de processamento batch
      setTimeout(() => {
        setCfgDisciplinas(prev => [...prev, ...news])
        setIsProcessingBulk(false)
      }, 800)
    } else {
      setIsProcessingBulk(false)
    }
  }

  const handleClearAll = async () => {
    if (confirm('Tem certeza que deseja apagar TODAS as disciplinas? Isso afetará os quadros de horários já vinculados.')) {
      setIsProcessingBulk(true)
      setTimeout(() => {
        setCfgDisciplinas([])
        setIsProcessingBulk(false)
      }, 500)
    }
  }

  const limparFiltros = () => {
    setSearch(''); setFiltroNivel('todos'); setFiltroSituacao('todos')
    setFiltroTipo('todos'); setFiltroTurno('todos'); setFiltroTurma('todos')
  }

  return (
    <div suppressHydrationWarning>
      {(isLoading || isProcessingBulk) && (
        <div style={{ position:'absolute', top:0, left:0, width:'100%', height:'100%', background:'rgba(255,255,255,0.7)', zIndex:50, display:'flex', alignItems:'center', justifyContent:'center', backdropFilter:'blur(2px)' }}>
          <div style={{ textAlign:'center', color:'hsl(var(--text-muted))' }}>
            <div style={{ width: 40, height: 40, border: '3px solid rgba(59,130,246,0.2)', borderTopColor: '#3b82f6', borderRadius: '50%', animation: 'spin 1s linear infinite', margin: '0 auto 16px' }} />
            <div style={{ fontWeight:600 }}>{isProcessingBulk ? 'Sincronizando lote com banco de dados...' : 'Carregando disciplinas...'}</div>
          </div>
        </div>
      )}
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 className="page-title" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span>Disciplinas</span>
            {isFetching && <UpdatingIndicator />}
          </h1>
          <p className="page-subtitle">Cadastro global de disciplinas — {cfgDisciplinas.length} registradas</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-ghost btn-sm" onClick={handleClearAll} style={{ color: '#ef4444', backgroundColor: '#fef2f2', border: '1px solid #fca5a5' }} disabled={isProcessingBulk}>
            <Trash2 size={13} /> Limpar Tudo
          </button>
          <button className="btn btn-secondary btn-sm" onClick={handleCarregarPadroes} style={{ background: 'linear-gradient(135deg, #1e3a8a, #3b82f6)', color: 'white', border: 'none', boxShadow: '0 4px 12px rgba(59, 130, 246, 0.3)' }} disabled={isProcessingBulk}>
            <Layers size={13} /> Carregar Padrões
          </button>
          <button className="btn btn-primary btn-sm" onClick={openNew} disabled={isProcessingBulk}><Plus size={13} /> Nova Disciplina</button>
        </div>
      </div>

      {/* KPIs */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
        {[
          { label: 'Total', value: cfgDisciplinas.length, color: '#3b82f6' },
          { label: 'Ativas', value: ativas, color: '#10b981' },
          { label: 'Obrigatórias', value: obrigatorias, color: '#8b5cf6' },
          { label: 'Filtradas', value: filtered.length, color: '#f59e0b' },
        ].map(k => (
          <div key={k.label} className="kpi-card">
            <div style={{ fontSize: 28, fontWeight: 800, color: k.color, fontFamily: 'Outfit, sans-serif' }}>{k.value}</div>
            <div style={{ fontSize: 12, color: 'hsl(var(--text-muted))', marginTop: 4 }}>{k.label}</div>
          </div>
        ))}
      </div>

      {/* Filtros */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 12, flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
          <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'hsl(var(--text-muted))' }} />
          <input className="form-input" style={{ paddingLeft: 30 }} placeholder="Buscar disciplina ou código..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="form-input" style={{ width: 130 }} value={filtroTurno} onChange={e => setFiltroTurno(e.target.value)}>
          <option value="todos">🕐 Turno</option>
          {TURNOS.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        <select className="form-input" style={{ width: 150 }} value={filtroTurma} onChange={e => setFiltroTurma(e.target.value)}>
          <option value="todos">🏫 Turma</option>
          {turmasUnicas.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        {hasFilters && (
          <button className="btn btn-ghost btn-sm" style={{ fontSize: 11, color: '#f87171' }} onClick={limparFiltros}>✕ Limpar</button>
        )}
      </div>

      <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap' }}>
        {/* Nível */}
        <div className="tab-list">
          {['todos', ...NIVEIS_OPTS].map(n => (
            <button key={n} className={`tab-trigger ${filtroNivel === n ? 'active' : ''}`} onClick={() => setFiltroNivel(n)}
              style={filtroNivel === n && n !== 'todos' ? { color: NIVEL_COLORS[n], borderColor: `${NIVEL_COLORS[n]}60`, background: `${NIVEL_COLORS[n]}18` } : {}}>
              {n === 'todos' ? 'Todos os níveis' : n}
            </button>
          ))}
        </div>
        {/* Situação */}
        <div className="tab-list">
          {(['todos', 'ativa', 'inativa'] as const).map(s => (
            <button key={s} className={`tab-trigger ${filtroSituacao === s ? 'active' : ''}`} onClick={() => setFiltroSituacao(s)}>
              {s === 'todos' ? 'Situação' : s === 'ativa' ? '✓ Ativas' : '✗ Inativas'}
            </button>
          ))}
        </div>
        {/* Tipo */}
        <div className="tab-list">
          {(['todos', 'obrigatoria', 'optativa'] as const).map(t => (
            <button key={t} className={`tab-trigger ${filtroTipo === t ? 'active' : ''}`} onClick={() => setFiltroTipo(t)}>
              {t === 'todos' ? 'Tipo' : t === 'obrigatoria' ? 'Obrigatórias' : 'Optativas'}
            </button>
          ))}
        </div>
      </div>

      {/* Form */}
      {showForm && (
        <div className="card" style={{ padding: '20px', marginBottom: 16, border: '1px solid rgba(59,130,246,0.3)', background: 'rgba(59,130,246,0.02)' }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 14, color: '#60a5fa' }}>{editId ? '✏️ Editar Disciplina' : '➕ Nova Disciplina'}</div>
          <div style={{ display: 'grid', gridTemplateColumns: '110px 1fr 1fr', gap: 12, marginBottom: 12 }}>
            {/* Código auto-gerado — somente leitura */}
            <div>
              <label className="form-label">Código</label>
              <div style={{ display: 'flex', alignItems: 'center', height: 38, borderRadius: 8, border: '1px solid hsl(var(--border-subtle))', overflow: 'hidden', background: 'hsl(var(--bg-elevated))' }}>
                <span style={{ padding: '0 8px', fontSize: 10, color: 'hsl(var(--text-muted))', borderRight: '1px solid hsl(var(--border-subtle))', height: '100%', display: 'flex', alignItems: 'center', whiteSpace: 'nowrap' }}>AUTO</span>
                <span style={{ padding: '0 10px', fontWeight: 900, fontSize: 13, fontFamily: 'monospace', color: '#60a5fa', letterSpacing: '0.03em' }}>
                  {codigoPreview || '—'}
                </span>
              </div>
              <div style={{ fontSize: 10, color: 'hsl(var(--text-muted))', marginTop: 3 }}>Gerado das iniciais</div>
            </div>
            <div>
              <label className="form-label">Nome da Disciplina *</label>
              <input className="form-input" value={form.nome}
                onChange={e => setForm(p => ({ ...p, nome: e.target.value }))}
                placeholder="Ex: Matemática, Língua Portuguesa..." />
            </div>
            <div>
              <label className="form-label">Carga Horária (h/sem)</label>
              <input className="form-input" type="number" min={1} max={20} value={form.cargaHoraria} onChange={e => setForm(p => ({ ...p, cargaHoraria: +e.target.value }))} />
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 12 }}>
            <div>
              <label className="form-label">Níveis de Ensino aplicáveis</label>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 4 }}>
                {NIVEIS_OPTS.map(n => (
                  <button key={n} type="button" onClick={() => toggleNivel(n)}
                    style={{
                      padding: '4px 10px', borderRadius: 6, fontSize: 12, fontWeight: 700, cursor: 'pointer',
                      border: `1px solid ${form.niveisEnsino.includes(n) ? NIVEL_COLORS[n] : 'hsl(var(--border-default))'}`,
                      background: form.niveisEnsino.includes(n) ? `${NIVEL_COLORS[n]}22` : 'transparent',
                      color: form.niveisEnsino.includes(n) ? NIVEL_COLORS[n] : 'hsl(var(--text-muted))',
                    }}>{n}</button>
                ))}
              </div>
            </div>
            <div>
              <label className="form-label">Tipo</label>
              <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                <button type="button" onClick={() => setForm(p => ({ ...p, obrigatoria: true }))} className={`btn btn-sm ${form.obrigatoria ? 'btn-primary' : 'btn-secondary'}`}>✓ Obrigatória</button>
                <button type="button" onClick={() => setForm(p => ({ ...p, obrigatoria: false }))} className={`btn btn-sm ${!form.obrigatoria ? 'btn-primary' : 'btn-secondary'}`}>Optativa</button>
              </div>
            </div>
            <div>
              <label className="form-label">Situação</label>
              <select className="form-input" value={form.situacao} onChange={e => setForm(p => ({ ...p, situacao: e.target.value as 'ativa' | 'inativa' }))}>
                <option value="ativa">✓ Ativa</option>
                <option value="inativa">✗ Inativa</option>
              </select>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 14, justifyContent: 'flex-end' }}>
            <button className="btn btn-secondary btn-sm" onClick={() => setShowForm(false)}>Cancelar</button>
            <button className="btn btn-primary btn-sm" onClick={handleSave}><Check size={13} />{editId ? 'Salvar Alterações' : 'Cadastrar Disciplina'}</button>
          </div>
        </div>
      )}

      {/* Tabela */}
      {isLoading && cfgDisciplinas.length === 0 ? (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th style={{ width: 100 }}>Código</th>
                  <th>Nome</th>
                  <th>Níveis de Ensino</th>
                  <th style={{ textAlign: 'center' }}>Carga</th>
                  <th style={{ textAlign: 'center' }}>Tipo</th>
                  <th style={{ textAlign: 'center' }}>Situação</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                <TableSkeleton rows={10} cols={7} />
              </tbody>
            </table>
          </div>
        ) : cfgDisciplinas.length === 0 ? (
          <div className="card" style={{ padding: '56px', textAlign: 'center', color: 'hsl(var(--text-muted))' }}>
            <BookOpen size={48} style={{ margin: '0 auto 16px', opacity: 0.15 }} />
            <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 8 }}>Nenhuma disciplina cadastrada</div>
            <div style={{ fontSize: 13, marginBottom: 20 }}>Ex: Matemática, Português, Ciências...</div>
            <button className="btn btn-primary" onClick={openNew}><Plus size={14} />Cadastrar primeira disciplina</button>
          </div>
        ) : (
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th style={{ width: 100 }}>Código</th>
                <th>Nome</th>
                <th>Níveis de Ensino</th>
                <th style={{ textAlign: 'center' }}>Carga</th>
                <th style={{ textAlign: 'center' }}>Tipo</th>
                <th style={{ textAlign: 'center' }}>Situação</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(d => (
                <tr key={d.id}>
                  <td><code style={{ fontSize: 12, background: 'hsl(var(--bg-overlay))', padding: '2px 6px', borderRadius: 4, color: '#60a5fa', fontWeight: 800 }}>{d.codigo}</code></td>
                  <td style={{ fontWeight: 600, fontSize: 14 }}>{d.nome}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                      {d.niveisEnsino.map(n => (
                        <span key={n} style={{ fontSize: 10, padding: '2px 6px', borderRadius: 4, background: `${NIVEL_COLORS[n] ?? '#6b7280'}22`, color: NIVEL_COLORS[n] ?? '#6b7280', fontWeight: 700 }}>{n}</span>
                      ))}
                    </div>
                  </td>
                  <td style={{ textAlign: 'center', fontWeight: 700, fontSize: 13 }}>{d.cargaHoraria}h</td>
                  <td style={{ textAlign: 'center' }}>
                    <span className={`badge ${d.obrigatoria ? 'badge-primary' : 'badge-neutral'}`}>{d.obrigatoria ? 'Obrigatória' : 'Optativa'}</span>
                  </td>
                  <td style={{ textAlign: 'center' }}>
                    <span className={`badge ${d.situacao === 'ativa' ? 'badge-success' : 'badge-neutral'}`}>{d.situacao === 'ativa' ? '✓ Ativa' : '✗ Inativa'}</span>
                  </td>
                  <td>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button className="btn btn-ghost btn-icon btn-sm" onClick={() => openEdit(d)}><Edit2 size={13} /></button>
                      <button className="btn btn-ghost btn-icon btn-sm" style={{ color: '#f87171' }} onClick={() => handleDelete(d.id)}><Trash2 size={13} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div style={{ padding: '28px', textAlign: 'center', color: 'hsl(var(--text-muted))', fontSize: 13 }}>
              Nenhuma disciplina com esses filtros — <button className="btn btn-ghost btn-sm" style={{ fontSize: 11 }} onClick={limparFiltros}>limpar</button>
            </div>
          )}
          <div style={{ padding: '10px 16px', borderTop: '1px solid hsl(var(--border-subtle))', fontSize: 12, color: 'hsl(var(--text-muted))' }}>
            {filtered.length} de {cfgDisciplinas.length} disciplinas
          </div>
        </div>
      )}
    </div>
  )
}
