import { NextResponse } from 'next/server'
import { createProtectedClient } from '@/lib/server/supabaseAuthFactory'

export const dynamic = 'force-dynamic'
export const revalidate = 0

export async function GET(request: Request) {
  try {
    const supabase = await createProtectedClient()
    const { searchParams } = new URL(request.url)
    const slug = searchParams.get('slug')
    const responsavel_id = searchParams.get('responsavel_id')
    const isAlunoProfile = searchParams.get('is_aluno_profile') === 'true'

    if (!slug) {
      return NextResponse.json({ error: 'Slug do aluno é obrigatório' }, { status: 400 })
    }

    // 1. Buscar os dados essenciais do aluno
    const { data: aluno, error: errorAluno } = await supabase
      .from('alunos')
      .select('id, nome, foto, turma, turno, status, matricula')
      .eq('id', slug)
      .maybeSingle()

    if (errorAluno) {
      console.error('Erro buscando aluno:', errorAluno)
      return NextResponse.json({ error: 'Erro ao buscar aluno' }, { status: 500 })
    }

    if (!aluno) {
      return NextResponse.json({ error: 'Aluno não encontrado' }, { status: 404 })
    }

    // 1.5. Resolver nome e turno da Turma
    if (aluno.turma) {
       const { data: turmaData } = await supabase
         .from('turmas')
         .select('nome, turno')
         .or(`id.eq."${aluno.turma}",codigo.eq."${aluno.turma}",nome.eq."${aluno.turma}"`)
         .maybeSingle()
       
       if (turmaData) {
         if (turmaData.nome) (aluno as any).turma_nome = turmaData.nome
         if (turmaData.turno) (aluno as any).turno_nome = turmaData.turno
       } else {
         (aluno as any).turma_nome = aluno.turma
       }
    } else {
       (aluno as any).turma_nome = 'S/T'
    }

    // 2. Buscar vínculos do aluno
    let vinculo = null;
    let responsaveisDb: any[] = [];
    let meusAlunos: any[] = [];
    
    if (isAlunoProfile) {
       vinculo = {
         parentesco: 'Próprio Aluno',
         resp_financeiro: false,
         resp_pedagogico: false
       }
       meusAlunos = [aluno]
    } else if (responsavel_id) {
       const { data: links, error: linkError } = await supabase
         .from('aluno_responsavel')
         .select('parentesco, resp_financeiro, resp_pedagogico, responsaveis!fk_ar_responsavel(id, nome, email, rfid, dados)')
         .eq('aluno_id', slug)
         
       if (!linkError && links && links.length > 0) {
         const meuVinculo = links.find((l: any) => l.responsaveis?.id === responsavel_id || (Array.isArray(l.responsaveis) && l.responsaveis[0]?.id === responsavel_id));
         if (meuVinculo) {
           vinculo = {
             parentesco: meuVinculo.parentesco,
             resp_financeiro: meuVinculo.resp_financeiro,
             resp_pedagogico: meuVinculo.resp_pedagogico
           }
         }
         responsaveisDb = links.map((l: any) => ({
            id: l.responsaveis?.id || (Array.isArray(l.responsaveis) ? l.responsaveis[0]?.id : undefined),
            nome: l.responsaveis?.nome || (Array.isArray(l.responsaveis) ? l.responsaveis[0]?.nome : undefined),
            parentesco: l.parentesco,
            resp_financeiro: l.resp_financeiro,
            resp_pedagogico: l.resp_pedagogico
         }));
       }

       // 3. Buscar todos os alunos vinculados a esse responsável (para o Switcher)
       const { data: meusLinks } = await supabase
         .from('aluno_responsavel')
         .select('alunos(id, nome, turma)')
         .eq('responsavel_id', responsavel_id)
       
       if (meusLinks && meusLinks.length > 0) {
         meusAlunos = meusLinks.map((l: any) => l.alunos).filter(Boolean)
       }
    }

    return NextResponse.json({
      aluno: { ...aluno, responsaveis: responsaveisDb },
      vinculo: vinculo,
      meusAlunos: meusAlunos
    }, {
      headers: { 'Cache-Control': 'no-store, max-age=0' }
    })

  } catch (e: any) {
    console.error('Perfil Acesso API Error:', e)
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
